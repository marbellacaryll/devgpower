<?php

$conn=mysqli_connect("localhost","root","","mcmsdb");

//number error
if (mysqli_connect_errno()){
	die ("Database connection failed: " . mysqli_connect_errno() ." (". mysqli_connect_errno(). ")");
	
}
?>