<!DOCTYPE html>
<html>
<head>
  <title>PHO-MCMS</title>
  <link rel="stylesheet" type="text/css" href="../pho_mcms/css/w3.css">
  <link rel="stylesheet" type="text/css" href="../pho_mcms/css/now-ui-dashboard.css?v=1.2.0.css">
  <link href ="../pho_mcms/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="../pho_mcms/css/style.css">
  <link rel="stylesheet" type="text/css" href="../pho_mcms/css/bhw_header.css">
  <link rel="stylesheet" type="text/css" href="../pho_mcms/css/bhw_add_preschooler_css.css">
  <link rel="stylesheet" type="text/css" href="../pho_mcms/css/jquery-ui-1.10.1.custom.min.css">
  
  <script type="text/javascript" src="../pho_mcms/js/jquery.min.js"></script>
  <script type="text/javascript" src="../pho_mcms/js/dataTables.buttons.min.js"></script>
  <script type="text/javascript" src="../pho_mcms/js/datatables.min.js"></script>
  <script type="text/javascript" src="../pho_mcms/js/datatables-init.js"></script>
  <script type="text/javascript" src="../pho_mcms/js/sidebarmenu.js"></script>
</head>

<body>

<div class="w3-sidebar w3-bar-block w3-card" style="width: 205px; height: 900px;">
<ol class="align_sidebar">
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <hr>
  <a href="#" class="w3-bar-item w3-btn w3-hover-green w3-round-xxlarge" style="width: 172px; background-color: #aef359;"><i class="now-ui-icons shopping_shop"></i>&emsp;HOME</a>
   <br>
  <a href="nut_mun_index.php" class="w3-bar-item w3-button w3-hover-yellow w3-round-xxlarge" style="width: 172px;"><i class="now-ui-icons business_chart-bar-32"></i>&emsp;VIEW GRAPH REPORT</a>



  <br>
  <div class="w3-bar-item w3-button w3-hover-yellow w3-round-xxlarge" onclick="myAccFunc()" style="width: 172px; height: 33px;"><i class="now-ui-icons business_badge"></i>&emsp;APPROVE ACCOUNT &nbsp;<i class="now-ui-icons arrows-1_minimal-down w3-tiny"></i></div>
  <div id="demoAcc" class="w3-hide w3-white" style="width: 172px; margin-left: 25px;">
    <a href="sw_approve_account.php" class="w3-bar-item w3-button w3-round-xxlarge acc">Social Workers</a>
    <a href="bhw_approve_account.php" class="w3-bar-item w3-button w3-round-xxlarge acc">BHW</a>
  </div>
  <br>
  <a href="logout.php" class="w3-bar-item w3-button w3-hover-yellow w3-round-xxlarge" style="width: 172px;"><i class="now-ui-icons ui-1_settings-gear-63"></i>&emsp;LOGOUT</a>
  <p class="small" style="">Marbella | Guazon</p>
</ol>
</div>
<div class="card" style="width: 1200px; height: 100px; margin-left: 180px; margin-top: -16px;">
  <input type="text" class="w3-input w3-round-xxlarge w3-border w3-small searchbar" placeholder="&emsp;&emsp;&emsp;Search.."><i class="now-ui-icons users_single-02 search_icon"></i>
  
</div>
</body>
</html>

<script>
function myAccFunc() {
    var x = document.getElementById("demoAcc");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
        x.previousElementSibling.className += "";
    } else { 
        x.className = x.className.replace(" w3-show", "");
        x.previousElementSibling.className = 
        x.previousElementSibling.className.replace(" w3-green", "");
    }
}
</script>