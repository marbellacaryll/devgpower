<?php
include('header.php');
?>
<style type="text/css">
	.w3-container {
		margin-top: 30px;
		width: 980px;
		margin-left: 300px;
	}
</style>
<body>
	<div id="container" class="w3-container"></div>

	<script type="text/javascript">
		$(function () { 
    var myChart = Highcharts.chart('container', {
        chart: {
            type: 'bar'
        },
        title: {
            text: 'Severity of Malnourished Children in Albay'
        },
        xAxis: {
            categories: ['Camalig', 'Daraga', 'Legazpi']
        },
        yAxis: {
            title: {
                text: 'Preschooler Cases'
            }
        },
        series: [{
            name: 'Severly Underweight',
            data: [100, 30, 45]
        }, {
            name: 'Underweight',
            data: [50, 70, 31]
        }, {
           name: 'Obese',
           data: [300, 170, 390]
        }, {
        name: 'Normal',
        data: [50, 270, 211]
        }]
    });
});
	</script>
</body>
</html>