<?php
include("connection.php");
include("sw_header.php");
?>
<body>

<div class="w3-container" style="width: 1100px; margin-left: 236px; margin-top: -10px;">
		<div class="card">
			<div id="obese_list" class="card-body">
				<table id="myTable" class="w3-table w3-tiny table-bordered table-hover">
			<tr>
				<th>NAME</th>
				<th>Weight</th>
				<th>Height</th>
				<th>BMI</th>
				<th>Health Status</th>
				<th>Barangay</th>
				<th>EDIT</th>
				
			
			</tr>

			<?php
			//Approve Data from BHW
			if(isset($_GET['approve'])){
			$approve = $_GET['approve'];
			$query = mysqli_query($conn, "UPDATE sw_approval SET status = 1 WHERE bar_id='{$approve}'");
			}

		

				$bar_id = $_GET['bar_id'] AND $_GET['status'];
			 	$query = mysqli_query($conn, "SELECT * FROM sw_approval WHERE status = 0 AND bar_id='{$bar_id}'  ");
			 	while($req = mysqli_fetch_array($query)){


			 		$bar_id = $req['bar_id'];
					$x = mysqli_query($conn, "SELECT * FROM barangay WHERE bar_id='{$bar_id}' ");
					$cli = mysqli_fetch_array($x);


					$pre_id = $req['pre_id'];
					$xx = mysqli_query($conn, "SELECT * FROM preschooler WHERE pre_id='{$pre_id}'");
					$clii = mysqli_fetch_array($xx);

					$pre_id = $req['pre_id'];
					$xxs = mysqli_query($conn, "SELECT * FROM physical_info WHERE pre_id='{$pre_id}'");
					$hs = mysqli_fetch_array($xxs);
			 		
			 		echo "
			 			<tr>
			 				<td>".ucwords($clii['pre_fname'])."
			 				".ucwords($clii['pre_mname'])."
			 				".ucwords($clii['pre_lname'])."</td>
			 				<td>".$hs['weight']."</td>
			 				<td>".$hs['height']."</td>
			 				<td>".$hs['bmi']."</td>
			 				<td>".$hs['health_status']."</td>
							<td>".ucwords($cli['barangay_name'])."</td>
						

			 				";
			 			}
			 			$bar_id = $_GET['bar_id'] AND $_GET['status'];
			 			$query = mysqli_query($conn, "SELECT * FROM sw_approval WHERE bar_id='{$bar_id}' GROUP BY status  ");
			 			while($req = mysqli_fetch_array($query)){


			 				//Pending For Approval
						 	if($req['status']==0){
									echo "<a href = 'sw_view_barangay.php?approve=".$req['bar_id']."'><button class='btn btn-outline-dark'>Approve</button></a>";
								
									
							}
							
				 				echo "</td>
						 	</tr>

				 		"; 	
				 	}
				?>
		</table><br>
	</div>
</div>

<div class="col-lg-2">
	
</div>

</body>
</html>
<script src="js/jquery-1.11.1.js"></script>
<script src="js/bootstrap.min.js"></script>
