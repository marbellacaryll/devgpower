<head>
  <script type="text/javascript" src="../pho_mcms/js/highcharts.js"></script>
  <script type="text/javascript" src="../pho_mcms/js/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous"></script>
</head>

<?php
include('sw_header.php');
?>

<body>
  <div id="container" style="width: 80%; height: 400px; margin-left: 220px;">
  </div>
</body>

<script type="text/javascript">
$(document).ready(function(){
    var options ={
      chart: {
        renderTo:'container',
        type: 'column',
         zoomType: 'x'
      },
       title: {
            text: 'MUNICIPALITY OF BACACAY'
        },
      xAxis: {
    title: {
      text: 'NAME OF BARANGAY'
    }
  },
  yAxis: {
   
    title: {
      text: 'Count kung ilan so malnourished children'
    }
  },
      series:[{
         name: 'Severely Underweight'
         }, {
              name: 'Underweight',
          }, {
            name: 'Obese',
      }]
    };
    $.getJSON('sw_data_severely_underweight.php', function(data){
      options.series[0].data = data;
      var chart = new Highcharts.Chart(options);
    });
     $.getJSON('sw_data_underweight.php', function(data_underweight){
      options.series[1].data = data_underweight;
      var chart = new Highcharts.Chart(options);
    });
    $.getJSON('sw_data_obese.php', function(data_obese){
      options.series[2].data = data_obese;
      var chart1 = new Highcharts.Chart(options);
    });
      });
    
</script>