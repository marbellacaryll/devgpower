

<form name="bmi" method="GET" action="data.php">
  Mass in kilogram (kg):
  <input type="text" name="mass" id="mass" size="15">
  <br> 

  Height in meter (m):
  <input type="text" name="height" id="height" size="15">
  <br>

  <input type="submit" name="submit" id="submit" value="submit">
</form>

<?php
if ($_GET['submit']) { 
    $mass = $_GET['mass'];
    $height = $_GET['height'];

    function bmi($mass,$height) {
        $bmi = $mass/($height*$height);
        return $bmi;
    }   

    $bmi = bmi($mass,$height); //<--- this is critical

    if ($bmi <= 18.5) {
        $output = "UNDERWEIGHT";

        } else if ($bmi > 18.5 AND $bmi<=24.9 ) {
        $output = "NORMAL WEIGHT";

        } else if ($bmi > 24.9 AND $num<=29.9) {
        $output = "OVERWEIGHT";

        } else if ($bmi > 30.0) {
        $output = "OBESE";
    }
    echo "Your BMI value is  " . $bmi . "  and you are : "; 
    echo "$output";
}
?>