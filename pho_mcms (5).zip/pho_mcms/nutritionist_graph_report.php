<?php
include('connection.php');
include('nutritionist_header.php');
?>

<head>
  <script type="text/javascript" src="../pho_mcms/js/highcharts.js"></script>
  <script type="text/javascript" src="../pho_mcms/js/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous"></script>
</head>

<div id="container" style="width: 60%; height: 400px; margin-left: 380px;"></div>

<script type="text/javascript">
$(document).ready(function(){
    var options ={
      chart: {
        renderTo:'container',
        type: 'column',
         zoomType: 'x'
      },
       title: {
            text: 'PROVINCE OF ALBAY'
        },
      xAxis: {
    title: {
      text: 'NAME OF BARANGAY'
    }
  },
  yAxis: {
   
    title: {
      text: 'Count kung ilan so malnourished children'
    }
  },
      series:[{
         name: 'Severely Underweight'
         }, {
              name: 'Underweight',
          }, {
            name: 'Obese',
      }]
    };
    $.getJSON('nut_data_severly.php', function(data){
      options.series[0].data = data;
      var chart = new Highcharts.Chart(options);
    });
     $.getJSON('nut_data_underweight.php', function(data_underweight){
      options.series[1].data = data_underweight;
      var chart1 = new Highcharts.Chart(options);
    }); 
    $.getJSON('nut_data_obese.php', function(data_obese){
      options.series[2].data = data_obese;
      var chart2 = new Highcharts.Chart(options);
    }); 
      });
    
    
</script>