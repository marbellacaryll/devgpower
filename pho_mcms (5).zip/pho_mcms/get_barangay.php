<?php
require_once("connection.php");
if(!empty($_POST["mun_id"])) 
{
$query =mysqli_query($conn,"SELECT * FROM barangay WHERE mun_id = '" . $_POST["mun_id"] . "'");
?>
<option >Select Barangay</option>
<?php
while($row=mysqli_fetch_array($query))  
{
?>
<option value="<?php echo $row["bar_id"]; ?>"><?php echo $row["barangay_name"]; ?></option>
<?php
}
}
?>
