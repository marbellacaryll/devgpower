<?php
  $dbHost = "localhost";
  $dbDatabase = "mcmsdb";
  $dbUser = "root";
  $dbPasswrod = "";
  
  $conn = mysqli_connect($dbHost, $dbUser, $dbPasswrod, $dbDatabase);

?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Highcharts Example</title>

        <style type="text/css">

        </style>
    </head>
    <body>
<link href="../assets/css/highcharts.css" rel="stylesheet" />
<script type="text/javascript" src="../pho_mcms/js/highcharts.js"></script>
<script type="text/javascript" src="../pho_mcms/js/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous"></script>
<?php
$year = date('Y');
                ?>
    <h3 class="box-title">REPORT OF <!--<?php echo $year-1; ?> vs --><?php echo $year; ?></h3>

<div class="col-md-10">
<div class="content">
<div id="container" style="width:100%; height:400px; height: 400px; margin: 0 auto"></div>


<?php include('monthly_mal_scripts.php'); ?>
<script type="text/javascript">

Highcharts.chart('container', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Status of Children in ALBAY per MONTH'
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        categories: [
            'January',
            'February',
            'March',
            'April',
            'May',
            'June',
            'July',
            'August',
            'September',
            'October',
            'November',
            'December'
        ],
        crosshair: true
    },
    yAxis: {
        min: 0,
        title: {
            text: 'No. Of Children in ALBAY'
        }

   
    },
    series: [{
        name: 'OBESE',
        data: [<?php echo $objan; ?>,
                <?php echo $obfeb; ?>,
                <?php echo $obmar; ?>,
                <?php echo $obapr; ?>,
                <?php echo $obmay; ?>,
                <?php echo $objun; ?>,
                <?php echo $objul; ?>,
                <?php echo $obaug; ?>,
                <?php echo $obsep; ?>,
                <?php echo $oboct; ?>,
                <?php echo $obnov; ?>,
                <?php echo $obdec; ?> ]

    },  {
        name: 'SEVERELY UNDERWEIGHT',
        data: [<?php echo $serjan; ?>,
                <?php echo $serfeb; ?>,
                <?php echo $sermar; ?>,
                <?php echo $serapr; ?>,
                <?php echo $sermay; ?>,
                <?php echo $serjun; ?>,
                <?php echo $serjul; ?>,
                <?php echo $seraug; ?>,
                <?php echo $sersep; ?>,
                <?php echo $seroct; ?>,
                <?php echo $sernov; ?>,
                <?php echo $serdec; ?>]

    }, {
        name: 'UNDERWEIGHT',
        data: [<?php echo $undjan; ?>,
                <?php echo $undfeb; ?>,
                <?php echo $undmar; ?>,
                <?php echo $undapr; ?>,
                <?php echo $undmay; ?>,
                <?php echo $undjun; ?>,
                <?php echo $undjul; ?>,
                <?php echo $undaug; ?>,
                <?php echo $undsep; ?>,
                <?php echo $undoct; ?>,
                <?php echo $undnov; ?>,
                <?php echo $unddec; ?>]

    }]
});
        </script>
    </body>
</html>
