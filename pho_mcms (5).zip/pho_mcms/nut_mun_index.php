<?php
include 'nutritionist_header.php';
  $dbHost = "localhost";
  $dbDatabase = "mcmsdb";
  $dbUser = "root";
  $dbPasswrod = "";
  
  $conn = mysqli_connect($dbHost, $dbUser, $dbPasswrod, $dbDatabase);

 
  $res = "SELECT muncipality_name FROM municipality" ;
  $result2 = mysqli_query($conn, $res);
  $json1 = [];
    while($row1 = mysqli_fetch_assoc($result2)){
  $barangay=$row1['muncipality_name'];
   $json1[] =[$barangay];
     }

?>
<!DOCTYPE HTML>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Highcharts Example</title>

		<style type="text/css">

		</style>
	</head>
	<body>
<link href="../assets/css/highcharts.css" rel="stylesheet" />
<script type="text/javascript" src="../pho_mcms/js/highcharts.js"></script>
<script type="text/javascript" src="../pho_mcms/js/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous"></script>
<?php
$year = date('Y');
                ?>
    <h3 class="box-title">REPORT OF <!--<?php echo $year-1; ?> vs --><?php echo $year; ?></h3>
<div id="container" style="width: 1110px; margin-left: 220px;"></div>


<?php include('nut_mun_array.php'); ?>
<script type="text/javascript">

Highcharts.chart('container', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'REPORT OF HEALTH STATUS BY MUNICIPALITY'
    },
    subtitle: {
        text: ''
    },
    xAxis: {
          categories: <?php echo json_encode($json1); ?>
       
    },
    yAxis: {
        min: 0,
        title: {
            text: 'No. of Children Per Municipality'
        }
    },
    
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: [{
        name: 'SEVERELY UNDERWEIGHT',
        data: [<?php echo  $bac;  ?>,
                <?php echo $cam;  ?>,
                <?php echo $dar;  ?>,
                <?php echo $gbtn; ?>,
                <?php echo $jov;  ?>,
                <?php echo $leg;  ?>,
                <?php echo $lib;  ?>,
                <?php echo $lig;  ?>,
                <?php echo $maln; ?>,
                <?php echo $mant; ?>,
                <?php echo $oas;  ?>,
                <?php echo $pio;  ?>,
                <?php echo $pol;  ?>,
                <?php echo $rap;  ?>,
                <?php echo $sant; ?>,
                <?php echo $tab;  ?>,
                <?php echo $tiw;  ?>]

     }, {
        name: 'UNDERWEIGHT',
        data: [<?php echo  $bacun;  ?>,
                <?php echo $camun;  ?>,
                <?php echo $darun;  ?>,
                <?php echo $gbtnun; ?>,
                <?php echo $jovun;  ?>,
                <?php echo $legun;  ?>,
                <?php echo $libun;  ?>,
                <?php echo $ligun;  ?>,
                <?php echo $malnun; ?>,
                <?php echo $mantun; ?>,
                <?php echo $oasun;  ?>,
                <?php echo $pioun;  ?>,
                <?php echo $polun;  ?>,
                <?php echo $rapun;  ?>,
                <?php echo $santun; ?>,
                <?php echo $tabun;  ?>,
                <?php echo $tiwun;  ?>]
    }, {
        name: 'OBESE',
        data: [<?php echo  $bacob;  ?>,
                <?php echo $camob;  ?>,
                <?php echo $darob;  ?>,
                <?php echo $gbtnob; ?>,
                <?php echo $jovob;  ?>,
                <?php echo $legob;  ?>,
                <?php echo $libob;  ?>,
                <?php echo $ligob;  ?>,
                <?php echo $malnob; ?>,
                <?php echo $mantob; ?>,
                <?php echo $oasob;  ?>,
                <?php echo $pioob;  ?>,
                <?php echo $polob;  ?>,
                <?php echo $rapob;  ?>,
                <?php echo $santob; ?>,
                <?php echo $tabob;  ?>,
                <?php echo $tiwob;  ?>]

    }]
});
		</script>
	</body>
</html>
