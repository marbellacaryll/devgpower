<?php


  $dbHost = "localhost";
  $dbDatabase = "mcmsdb";
  $dbUser = "root";
  $dbPasswrod = "";
  


  $conn = mysqli_connect($dbHost, $dbUser, $dbPasswrod, $dbDatabase);
  
// populating graph by obese children
$query_for_underweight = "SELECT bar_id ,SUM( health_status = 'This is considered as  Underweight') AS children_underweight FROM  physical_info  GROUP BY bar_id";
$result_for_underweight = mysqli_query($conn, $query_for_underweight);
$json_underweight = [];
  while($row_underweight = mysqli_fetch_assoc($result_for_underweight))
       {
            $pre_id = $row_underweight['bar_id'];
            $bar_id = $row_underweight['children_underweight'];

           $json_underweight[] =[(int)$pre_id, (int)$bar_id];
        }
  
  echo json_encode($json_underweight);

?>




