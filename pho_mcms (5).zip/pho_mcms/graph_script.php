<?php
include('connection.php');

   //FOR GLOBE
    $gyear = date('Y');
    $gtotal=array();
    for ($gmonth = 1; $gmonth <= 12; $gmonth ++){
       $sql = "SELECT bar_id ,SUM( health_status = 'This is considered as  severly Underweight') AS children FROM  physical_info  GROUP BY bar_id";
        $query=$conn->query($sql);
        
$gtotal = [];
    while($row = mysqli_fetch_assoc($query))
         {
        $gtotal[]=$row['children'];
    }

    $tgjan = $gtotal[0];
    $tgfeb = $gtotal[1];
    $tgmar = $gtotal[2];
    $tgapr = $gtotal[3];
    $tgmay = $gtotal[4];
    $tgjun = $gtotal[5];
    $tgjul = $gtotal[6];
    $tgaug = $gtotal[7];
    $tgsep = $gtotal[8];
    $tgoct = $gtotal[9];
    $tgnov = $gtotal[10];
    $tgdec = $gtotal[11];
    //END FOR GLOBE

    //FOR SUN
    $sunyear = date('Y');
    $suntotal=array();
    for ($sunmonth = 1; $sunmonth <= 12; $sunmonth ++){
        $sql = "SELECT bar_id ,SUM( health_status = 'This is considered as  Obese') AS children_one FROM  physical_info  GROUP BY bar_id";
        $query=$conn->query($sql);
        $row=$query->FETCH(PDO::FETCH_ASSOC);

        $suntotal[]=$row['children_one'];
    }

    $tsunjan = $suntotal[0];
    $tsunfeb = $suntotal[1];
    $tsunmar = $suntotal[2];
    $tsunapr = $suntotal[3];
    $tsunmay = $suntotal[4];
    $tsunjun = $suntotal[5];
    $tsunjul = $suntotal[6];
    $tsunaug = $suntotal[7];
    $tsunsep = $suntotal[8];
    $tsunoct = $suntotal[9];
    $tsunnov = $suntotal[10];
    $tsundec = $suntotal[11];
    //END FOR SUN
    
    //set timezone
    //date_default_timezone_set('Asia/Manila');
    $glyear = date('Y');
    $glmonth = date('M');
    $globetotal=array();
        $sql="SELECT *, COUNT(rating) as total FROM cnp_ratings WHERE month(time)='$glmonth' and year(time)='$glyear' and cnpid = 1";
        $query=$conn->query($sql);
        $row=$query->FETCH(PDO::FETCH_ASSOC);

        $globetotal[]=$row['total'];

        echo $tglobe = $globetotal[0];
    
?>
<?php
}
?>