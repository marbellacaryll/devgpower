<head>
  <script type="text/javascript" src="../pho_mcms/js/highcharts.js"></script>
  <script type="text/javascript" src="../pho_mcms/js/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous"></script>
</head>

<?php
include('sw_header.php');
?>

<body>
  <div id="container" style="width: 80%; height: 400px; margin-left: 220px;">
  </div>
</body>

<?php include('graph_script.php'); ?>
<script type="text/javascript">

Highcharts.chart('container', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Monthly Average of Cellular Network Providers'
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        categories: [
            'January',
            'February',
            'March',
            'April',
            'May',
            'June',
            'July',
            'August',
            'September',
            'October',
            'November',
            'December'
        ],
        crosshair: true
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Total Average of Ratings'
        }
    },
    tooltip: {
        headerFormat: '<span style="font-size:14px">{point.key}</span><table>',
        pointFormat: '<tr style="font-size:12px"><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:.1f}</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: [{
        name: 'Globe',
        data: [<?php echo $tgjan; ?>,
                <?php echo $tgfeb; ?>,
                <?php echo $tgmar; ?>,
                <?php echo $tgapr; ?>,
                <?php echo $tgmay; ?>,
                <?php echo $tgjun; ?>,
                <?php echo $tgjul; ?>,
                <?php echo $tgaug; ?>,
                <?php echo $tgsep; ?>,
                <?php echo $tgoct; ?>,
                <?php echo $tgnov; ?>,
                <?php echo $tgdec; ?> ]

    }, {
        name: 'Sun',
        data: [<?php echo $tsunjan; ?>,
                <?php echo $tsunfeb; ?>,
                <?php echo $tsunmar; ?>,
                <?php echo $tsunapr; ?>,
                <?php echo $tsunmay; ?>,
                <?php echo $tsunjun; ?>,
                <?php echo $tsunjul; ?>,
                <?php echo $tsunaug; ?>,
                <?php echo $tsunsep; ?>,
                <?php echo $tsunoct; ?>,
                <?php echo $tsunnov; ?>,
                <?php echo $tsundec; ?>]

    }]
});
        </script>
    </body>
</html>
