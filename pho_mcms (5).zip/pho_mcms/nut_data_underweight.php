<?php


  $dbHost = "localhost";
  $dbDatabase = "mcmsdb";
  $dbUser = "root";
  $dbPasswrod = "";
  


  $conn = mysqli_connect($dbHost, $dbUser, $dbPasswrod, $dbDatabase);
  
// populating graph by obese children
$query2 = "SELECT physical_info.bar_id,SUM( health_status = 'This is considered as Underweight') AS children FROM physical_info JOIN sw_approval ON physical_info.bar_id = sw_approval.bar_id AND status=1 GROUP BY bar_id";
$result2 = mysqli_query($conn, $query2);
$json2 = [];
  while($row2 = mysqli_fetch_assoc($result2))
       {
            $bar_id = $row2['bar_id'];
            $children = $row2['children'];

           $json2[] =[(int)$bar_id, (int)$children];
        }
  
  echo json_encode($json2);

?>




