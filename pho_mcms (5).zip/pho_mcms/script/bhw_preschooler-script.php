<?php

session_start();
include("../pho_mcms/server/connection.php");
?>

<?php
$username=$_SESSION['username'];
$query=mysqli_query($conn, "SELECT * FROM user_access 
  WHERE username='{$username}'");
$row=mysqli_fetch_array($query);
$user_id=$row['user_id'];

//ADD PRESCHOOLER
if (isset($_REQUEST['addPreschooler'])) {
  
  //FOR PERSONAL INFORMATION
  $pre_fname=$_REQUEST['pre_fname'];
  $pre_mname=$_REQUEST['pre_mname'];
  $pre_lname=$_REQUEST['pre_lname'];
  $pre_bdate=$_REQUEST['pre_bdate'];
  $age_in_years=$_REQUEST['age_in_years'];
  $age_in_months=$_REQUEST['age_in_months'];
  $age_in_days=$_REQUEST['age_in_days'];
  $pre_gender=$_REQUEST['pre_gender'];
  $mun_id=$_REQUEST['mun_id'];
  $bar_id=$_REQUEST['bar_id'];
  $pre_nationality=$_REQUEST['pre_nationality'];
  $pre_religion=$_REQUEST['pre_religion'];

  //FOR PHYSICAL INFORMATION
  $weight=$_REQUEST['weight'];
  $height=$_REQUEST['height'];
  $bmi=$_REQUEST['bmi'];

  //FOR PARENTS INFORMATION
  $f_name=$_REQUEST['f_name'];
  $f_occupation=$_REQUEST['f_occupation'];
  $m_name=$_REQUEST['m_name'];
  $m_occupation=$_REQUEST['m_occupation'];
  $annual_income=$_REQUEST['annual_income'];

  
$conn="This is considered as ";
//to show the nutritional status of the child
if ($bmi<10.6 || $weight<=2.0  && $age_in_months=0 || $height<=0.435 && $age_in_months=0) {
  $health_status="$conn Severly Underweight";
  $weight_for_age="Severely Underweight";
  $height_for_age="Normal";
  $weight_for_height="Normal";
  echo '<script type="text/javascript">alert("'.$health_status.' '.$weight_for_age.' '.$height_for_age.' '.$weight_for_height.'");</script>';
  echo("<script>window.location='../bhw_preschooler-form.php';</script>");
}
elseif ($bmi>=11 && $bmi<11.2 || $weight>=2.1 && $weight<=2.3 && $age_in_months=0 || $height>=0.436 && $height<=0.453 && $age_in_months=0) {
  $health_status="$conn Underweight";
  $weight_for_age="Severely Stunted";
  $height_for_age="Stunted";
  $weight_for_height="Underweight";
  echo '<script type="text/javascript">alert("'.$health_status.' '.$weight_for_age.' '.$height_for_age.' '.$weight_for_height.'");</script>';
  echo("<script>window.location='../bhw_preschooler-form.php';</script>");
}
elseif ($bmi>=11.6&&$bmi<15 || $weight>=2.4 && $weight<=4.2 && $age_in_months=0 || $height>=0.454 && $height<=0.529 && $age_in_months=0) {
  $health_status="$conn Normal";
  $weight_for_age="Normal";
  $height_for_age="Normal";
  $weight_for_height="Normal";
  echo '<script type="text/javascript">alert("'.$health_status.' '.$weight_for_age.' '.$height_for_age.' '.$weight_for_height.'");</script>';
  echo("<script>window.location='../bhw_preschooler-form.php';</script>");
}
elseif ($bmi>=15.3&&$bmi<100 || $weight>=4.3 && $age_in_months=0 || $height>=0.53 && $age_in_months=0) {
  $health_status="$conn Obese";
  $weight_for_age="Obese";
  $height_for_age="Tall";
  $weight_for_height="Obese";
  echo '<script type="text/javascript">alert("'.$health_status.' '.$weight_for_age.' '.$height_for_age.' '.$weight_for_height.'");</script>';
  echo("<script>window.location='../bhw_preschooler-form.php';</script>");
}else{
  $_SESSION['error']= "You input Wrong value";
}

 preschooler (
  $pre_fname,
  $pre_mname,
  $pre_lname,
  $pre_bdate,
  $age_in_years, 
  $age_in_months, 
  $age_in_days, 
  $pre_gender,
  $mun_id,
  $bar_id,
  $pre_nationality,
  $pre_religion,
  $weight,
  $height,
  $bmi,
  $health_status, 
  $weight_for_age, 
  $height_for_age, 
  $weight_for_height, 
  $f_name,
  $f_occupation,
  $m_name,
  $m_occupation, 
  $annual_income, 
  $user_id);
}

function preschooler (
  $pre_fname,
  $pre_mname,
  $pre_lname,
  $pre_bdate,
  $age_in_years, 
  $age_in_months, 
  $age_in_days, 
  $pre_gender,
  $mun_id,
  $bar_id,
  $pre_nationality,
  $pre_religion,
  $weight,
  $height,
  $bmi,
  $health_status, 
  $weight_for_age, 
  $height_for_age, 
  $weight_for_height, 
  $f_name,
  $f_occupation,
  $m_name,
  $m_occupation, 
  $annual_income, 
  $user_id) {
  include('../pho_mcms/server/connection.php');

  $sql_preschooler=mysqli_query($conn,"INSERT INTO preschooler (pre_fname, pre_mname, pre_lname, pre_bdate, age_in_years, age_in_months, age_in_days, pre_gender, mun_id,bar_id, pre_nationality, pre_religion, user_id)
    VALUES('{$pre_fname}', '{$pre_mname}','{$pre_lname}', '{$pre_bdate}', '{$age_in_years}', '{$age_in_months}', '{$age_in_days}', '{$pre_gender}', '{$mun_id}','{$bar_id}', '{$pre_nationality}', '{$pre_religion}', '{$user_id}')");

  $x = mysqli_query($conn, "SELECT * FROM preschooler 
    ORDER BY pre_id 
    DESC");
          $preschooler = mysqli_fetch_array($x);
          $pre_id = $preschooler['pre_id'];

  $sql_preschooler=mysqli_query($conn,"INSERT INTO physical_info (pre_id, weight, height, bmi, health_status, weight_for_age, height_for_age, weight_for_height, bar_id, user_id)
    VALUES('{$pre_id}','{$weight}', '{$height}', '{$bmi}', '{$health_status}', '{$weight_for_age}', '{$height_for_age}', '{$weight_for_height}', '{$bar_id}', '{$user_id}')");


  $y = mysqli_query($conn, "SELECT * FROM preschooler 
    ORDER BY pre_id 
    DESC");
          $preschooler_parent = mysqli_fetch_array($y);
          $pre_id1 = $preschooler_parent['pre_id'];

  $sql_preschooler=mysqli_query($conn, "INSERT INTO parent_info (pre_id, f_name, f_occupation, m_name, m_occupation, user_id, annual_income)
    VALUES ('{$pre_id}','{$f_name}', '{$f_occupation}', '{$m_name}', '{$m_occupation}', '{$user_id}', '{$annual_income}')");

  if ($conn->query($sql_preschooler)===TRUE) {
    echo ". Your Body Mass Index is $bmi .";
}


//UPDATE PRESCHOOLER INFORMATION
if (isset($_POST['updatePreschooler'])) {
  $preschooler_id=$_GET['id'];

  $update_pre_fname=$_POST['update_pre_fname'];
  $update_pre_mname=$_POST['update_pre_mname'];
  $update_pre_lname=$_POST['update_pre_lname'];
  $update_pre_bdate=$_POST['update_pre_bdate'];

  $update_pre_gender=$_POST['update_pre_gender'];
  $update_pre_purok=$_POST['update_pre_purok'];
  $update_mun_id=$_POST['update_mun_id'];
  $update_bar_id=$_POST['update_bar_id'];
  $update_pre_nationality=$_POST['update_pre_nationality'];
  $update_pre_religion=$_POST['update_pre_religion'];


  $update_weight=$_POST['update_weight'];
  $update_height=$_POST['update_height'];
  $update_bmi=$_POST['update_bmi'];

  $update_fathers_name=$_POST['update_fathers_name'];
  $update_fathers_occupation=$_POST['update_fathers_occupation'];
  $update_mothers_name=$_POST['update_mothers_name'];
  $update_mothers_occupation=$_POST['update_mothers_occupation'];


  update_preschooler($preschooler_id, 
    $update_pre_fname, 
    $update_pre_mname, 
    $update_pre_lname, 
    $update_pre_bdate, 
    $update_pre_gender, 
    $update_pre_purok, 
    $update_mun_id, 
    $update_bar_id, 
    $update_pre_nationality, 
    $update_pre_religion, 
    $update_weight, 
    $update_height, 
    $update_bmi, 
    $update_fathers_name, 
    $update_fathers_occupation, 
    $update_mothers_name, 
    $update_mothers_occupation);
}

function update_preschooler (
  $preschooler_id, 
  $update_pre_fname, 
  $update_pre_mname, 
  $update_pre_lname, 
  $update_pre_bdate, 
  $update_pre_gender, 
  $update_pre_purok, 
  $update_mun_id, 
  $update_bar_id, 
  $update_pre_nationality, 
  $update_pre_religion, 
  $update_weight, 
  $update_height, 
  $update_bmi, 
  $update_fathers_name, 
  $update_fathers_occupation, 
  $update_mothers_name, 
  $update_mothers_occupation) {

  include('../pho_mcms/server/connection.php');
  
  $sql_update_preschooler="UPDATE preschooler 
  SET pre_fname='$update_pre_fname', 
  pre_mname='$update_pre_mname', 
  pre_lname='$update_pre_lname', 
  pre_bdate='$pre_bdate', 
  pre_gender='$update_pre_gender', 
  pre_purok='$update_pre_purok', 
  mun_id='$update_mun_id', 
  bar_id='$update_bar_id', 
  pre_nationality='$update_pre_nationality', 
  pre_religion='$update_pre_religion'
  WHERE pre_id=$preschooler_id";
  if ($conn->query($sql_update_preschooler) === TRUE) {
        header("Location:bhw_normal_list.php?msg='Successfully updated!'");

  $sql_update_preschooler="UPDATE physical_info 
  SET weight='$update_weight', 
  height='$update_height', 
  bmi='$update_bmi'
  WHERE pre_id='$preschooler_id'";
  if ($conn->query($sql_update_preschooler)===TRUE) {
    header("Location:bhw_normal_list.php?msg='Successfully updated!'");

  $sql_update_preschooler="UPDATE parent_info 
  SET f_name='$update_fathers_name', 
  f_occupation='$update_fathers_occupation', 
  m_name='$update_mothers_name', 
  m_occupation='$update_mothers_occupation'
  WHERE pre_id='$preschooler_id'";
  if ($conn->query($sql_update_preschooler)===TRUE) {
    header("Location:bhw_normal_list.php?msg='Successfully updated!'");

    return $sql_update_preschooler;
  }
  $query2=mysqli_query($conn, "SELECT * FROM preschooler 
    WHERE pre_id='{$pre_id}'");
  $pre=mysqli_fetch_array($query2);

  $query1=mysqli_query($conn, "SELECT * FROM physical_info 
    WHERE phy_id='{$pre_id}");
  $row=mysqli_fetch_array($query1);
  }
 }
}


 //insert into social worker approval
      $query = mysqli_query($conn, "INSERT INTO `sw_approval` 
      (pre_id,bar_id,mun_id , status)
      VALUES ('{$pre_id}','{$bar_id}','{$mun_id}',0)");

      $xx = mysqli_query($conn, "SELECT * FROM sw_approval 
        ORDER BY app_id 
        DESC");
      $approval = mysqli_fetch_array($xx);
      $app_id = $approval['app_id'];

}
?>