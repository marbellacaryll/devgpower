<?php

session_start();
include("connection.php");
?>

<?php
$username=$_SESSION['username'];
$query=mysqli_query($conn, "SELECT * FROM user_access WHERE username='{$username}'");
$row=mysqli_fetch_array($query);
$user_id=$row['user_id'];



if (isset($_REQUEST['addPreschooler'])) {
  
  $pre_fname=$_REQUEST['pre_fname'];
  $pre_mname=$_REQUEST['pre_mname'];
  $pre_lname=$_REQUEST['pre_lname'];
  $pre_bdate=$_REQUEST['pre_bdate'];
  $pre_age=$_REQUEST['pre_age'];
  $pre_gender=$_REQUEST['pre_gender'];
  $pre_address=$_REQUEST['pre_address'];
  $pre_nationality=$_REQUEST['pre_nationality'];
  $pre_religion=$_REQUEST['pre_religion'];

  $weight=$_REQUEST['weight'];
  $height=$_REQUEST['height'];
  $bmi=$_REQUEST['bmi'];

  $f_name=$_REQUEST['f_name'];
  $f_occupation=$_REQUEST['f_occupation'];
  $m_name=$_REQUEST['m_name'];
  $m_occupation=$_REQUEST['m_occupation'];

  $health_status="";

$conn="This is considered as ";
//to show the nutritional status of the child
if ($bmi<16.5) {
  echo $health_status="$conn severly Underweight";
//echo $health_status "<script type='text/javascript'>alert('$conn severly Underweight');</script>";

}
elseif ($bmi>=16.5 && $bmi<18.5) {
  echo $health_status="$conn Underweight";
}
elseif ($bmi>=18.5&&$bmi<25) {
  echo $health_status="$conn normal";
}
elseif ($bmi>=25&&$bmi<100) {
  echo $health_status="$conn obese";
}else{
  $_SESSION['error']= "$conn Wrong value";
}

//redirect page, if malnourished child or not
if ($health_status==="severly Underweight") {
  header("Location:bhw_severly_underweight_list.php");
}
elseif ($health_status==="Underweight") {
  header("Location:bhw_underweight_list.php");
}else{
  $_SESSION['error']="Cannot redirect";
}
 preschooler($pre_fname,$pre_mname,$pre_lname,$pre_bdate,$pre_age,$pre_gender,$pre_address,$pre_nationality,$pre_religion,$weight,$height,$bmi,$health_status,$f_name,$f_occupation,$m_name,$m_occupation,$user_id);
}

function preschooler($pre_fname,$pre_mname,$pre_lname,$pre_bdate,$pre_age,$pre_gender,$pre_address,$pre_nationality,$pre_religion,$weight,$height,$bmi,$health_status,$f_name,$f_occupation,$m_name,$m_occupation,$user_id){
  include('connection.php');

  $sql_preschooler=mysqli_query($conn,"INSERT INTO preschooler (pre_fname, pre_mname, pre_lname, pre_bdate, pre_age, pre_gender, pre_address, pre_nationality, pre_religion, user_id)
    VALUES('{$pre_fname}', '{$pre_mname}','{$pre_lname}', '{$pre_bdate}', '{$pre_age}', '{$pre_gender}', '{$pre_address}', '{$pre_nationality}', '{$pre_religion}', '{$user_id}')");

  $x = mysqli_query($conn, "SELECT * FROM preschooler ORDER BY pre_id DESC");
          $preschooler = mysqli_fetch_array($x);
          $pre_id = $preschooler['pre_id'];

  $sql_preschooler=mysqli_query($conn,"INSERT INTO physical_info (pre_id, weight, height, bmi, health_status, user_id)
    VALUES('{$pre_id}','{$weight}', '{$height}', '{$bmi}', '{$health_status}','{$user_id}')");


  $y = mysqli_query($conn, "SELECT * FROM preschooler ORDER BY pre_id DESC");
          $preschooler_parent = mysqli_fetch_array($y);
          $pre_id1 = $preschooler_parent['pre_id'];

  $sql_preschooler=mysqli_query($conn, "INSERT INTO parent_info (pre_id, f_name, f_occupation, m_name, m_occupation, user_id)
    VALUES ('{$pre_id}','{$f_name}', '{$f_occupation}', '{$m_name}', '{$m_occupation}', '{$user_id}')");

  if ($conn->query($sql_preschooler)===TRUE) {
    echo ". Your Body Mass Index is $bmi .";
}
}


//UPDATE PRESCHOOLER INFORMATION
if (isset($_POST['updatePreschooler'])) {
  $preschooler_id=$_GET['id'];

  $update_pre_fname=$_POST['update_pre_fname'];
  $update_pre_mname=$_POST['update_pre_mname'];

  $update_weight=$_POST['update_weight'];
  $update_height=$_POST['update_height'];


  update_preschooler($preschooler_id, $update_pre_fname, $update_pre_mname, $update_weight, $update_height);
}
function update_preschooler($preschooler_id, $update_pre_fname, $update_pre_mname, $update_weight, $update_height) {
  include('connection.php');
  
  $sql_update_preschooler="UPDATE preschooler 
  SET pre_fname='$update_pre_fname', pre_mname='$update_pre_mname'
  WHERE pre_id=$preschooler_id";
  if ($conn->query($sql_update_preschooler) === TRUE) {
        header("Location:preschooler.php?msg='Successfully updated!'");

  $sql_update_preschooler="UPDATE physical_info 
  SET weight='$update_weight', height='$update_height'
  WHERE pre_id='$preschooler_id'";

  if ($conn->query($sql_update_preschooler)===TRUE) {
    header("Location:preschooler.php?msg='Successfully updated!'");

    return $sql_update_preschooler;
  }
  $query2=mysqli_query($conn, "SELECT * FROM preschooler WHERE pre_id='{$pre_id}'");
  $pre=mysqli_fetch_array($query2);

  $query1=mysqli_query($conn, "SELECT * FROM physical_info WHERE phy_id='{$pre_id}");
  $row=mysqli_fetch_array($query1);
  }
 }
?>