
<head>
  <link rel="stylesheet" type="text/css" href="../pho_mcms/css/w3.css">
  <link rel="stylesheet" type="text/css" href="../pho_mcms/css/now-ui-dashboard.css?v=1.2.0.css">
  <link href ="../pho_mcms/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="../pho_mcms/css/style.css">
  <!--<link rel="stylesheet" type="text/css" href="../pho_mcms/css/bootstrap.min.css"><-->

  <script type="text/javascript" src="../pho_mcms/js/jquery.min.js"></script>
  <script type="text/javascript" src="../pho_mcms/js/dataTables.buttons.min.js"></script>
  <script type="text/javascript" src="../pho_mcms/js/datatables.min.js"></script>
  <script type="text/javascript" src="../pho_mcms/js/datatables-init.js"></script>
  <script type="text/javascript" src="../pho_mcms/js/sidebarmenu.js"></script>
</head>
<?php
include('connection.php');

?>

<body>
	<div class="w3-container">
		<div id="underweight_result" class="w3-tiny w3-card" style="padding: 30px; width: 998px; margin-left: 300px; margin-top: 90px;">
			<div class="w3-card" style="width: 1000px; margin-left: 295px; margin-top: 100px; padding: 20px; height: 500px;">
				<div class="w3-card-body">
					<table id="myTable" class="w3-table table-bordered w3-tiny table-hover">
						<thead class="w3-tiny">
							<th class="w3-tiny">ID</th>
							<th class="w3-tiny">Weight</th>
							<th class="w3-tiny">Height</th>
							<th class="w3-tiny">BMI</th>
							<th class="w3-tiny">Health Status</th>
						</thead>

						<?php
$query = mysqli_query($conn, "SELECT * FROM `physical_info` WHERE `health_status` = 'This is considered as Underweight' ORDER BY phy_id DESC");
				 	while($ser = mysqli_fetch_array($query)){

							echo "
							<tr>
							
							<td>".$ser['phy_id']."</td>
							<td>".$ser['weight']."</td>
							<td>".$ser['height']."</td>
							<td>".$ser['bmi']."</td>
							<td>".$ser['health_status']."</td>
							</tr>
							";
						}
						?>
					</table>
				</div>
			</div>
		</div>
	</div>
</body>


<script type="text/javascript">
	$(document).ready(function(){
		$('#underweight_result').keyup(function(){
			var searchVal = $.trim($(this).val());
			$.get('bhw_search.php?search_malnourish_children='+searchVal,function(returnData){
				$('#underweight_result').html(returnData)
			});
		}
	});
</script>