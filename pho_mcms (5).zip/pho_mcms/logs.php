<?php

session_start();
include("connection.php");
include('bhw_header.php');
?>

<?php
$username=$_SESSION['username'];
$query1=mysqli_query($conn, "SELECT * FROM user_access WHERE username='{$username}'");
$row1=mysqli_fetch_array($query1);
$user_id=$row1['user_id'];
$query=mysqli_query($conn, "SELECT * FROM physical_info WHERE user_id='$user_id' AND `health_status` = 'This is considered as  severly Underweight' ORDER BY phy_id DESC");

$rowcount=mysqli_num_rows($query);


?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<div class="w3-container" style="width: 1100px; margin-left: 236px; margin-top: -10px;">
		<div class="card">
			<div id="malnourish_children_result" class="card-body">
				<table id="myTable" class="w3-table w3-tiny table-bordered table-hover">
					<thead class="w3-tiny">
						<th>Username</th>
						<th>Logs</th>
						<th>Date and Time</th>
					</thead>
					<?php
					$query=mysqli_query($conn, "SELECT * FROM addpreschooler");
					while ($logs=mysqli_fetch_array($query)) {
						echo "
						<tr>
						<td>".$logs['username_log']."</td>
						<td>".$logs['action_performed']."</td>
						<td>".$logs['date']."</td>
						</tr>
						";
					}

					?>
				</table>
			</div>
		</div>
	</div>
</body>
</html>