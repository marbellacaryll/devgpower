
<!DOCTYPE html>
<!--[if lt IE 8]>
<html class="no-js nav theme-blue lt-ie10 lt-ie9 lt-ie8 " lang="en-us"> <![endif]-->
<!--[if IE 8]>
<html class="no-js nav theme-blue lt-ie10 lt-ie9 " lang="en-us"> <![endif]-->
<!--[if IE 9]>
<html class="no-js nav theme-blue lt-ie10 " lang="en-us"> <![endif]-->
<!--[if !IE]><!-->
<html class="no-js nav theme-blue " lang="en-us" > <!--<![endif]-->
<head>
	<meta charset="utf-8"/>
	<title>BMI Calculator Child and Teen | Healthy Weight | CDC</title>

	<meta name="description" content="This calculator provides BMI and the corresponding BMI-for-age percentile based on the CDC growth charts for children and teens (ages 2 through 19 years). "/>
	<meta name="keywords" content="bmi, bmi calculator, bmi calculator kg, calculate bmi, bmi for kids, child bmi calculator, pediatric bmi calculator, kids bmi calculator, bmi calculator for kids, bmi calculator for girls, bmi calculator for boys, bmi calculator for teens, bmi calculator for children, bmi for women, bmi for men"/>	<meta name="viewport" content="width=device-width, initial-scale=1"/>

			<meta property="og:title" content="BMI Calculator for Child and Teen">
		<meta property="og:description" content="This calculator provides BMI and the corresponding BMI-for-age percentile based on the CDC growth charts for children and teens (ages 2 - 19 years).">
		<meta property="fb:app_id" content="205691699516606">
				<meta property="og:url" content="https://www.cdc.gov/healthyweight/bmi/calculator.html">

					<meta property="og:image" content="https://www.cdc.gov/healthyweight/bmi/img/bmi-collage.jpg">
							<meta property="og:image:type" content="image/jpeg">
						<meta property="article:published_time" content="2019-01-03">
		<meta property="og:author" content="CDC">
		<meta property="article:author" content="CDC">
		<meta property="og:site_name" content="Centers for Disease Control and Prevention">
		<meta property="og:type" content="article">
			<meta name="twitter:card" content="summary_large_image">		<meta name="twitter:site" content="@CDCgov">
		<meta name="twitter:creator" content="@CDCgov">
					<meta name="twitter:title" content="BMI Calculator for Child and Teen">
			<meta name="twitter:description" content="This calculator provides BMI and the corresponding BMI-for-age percentile based on the CDC growth charts for children and teens (ages 2 - 19 years).">
							<meta name="twitter:domain" content="https://bit.ly/2O3ucri">
						<meta name="twitter:image:src" content="https://www.cdc.gov/healthyweight/bmi/img/bmi-collage.jpg">
				<link rel="apple-touch-icon" sizes="144x144" href="/TemplatePackage/3.0/images/cdc-touch-icon-144x144.png"/>
	<link rel="apple-touch-icon" sizes="114x114" href="/TemplatePackage/3.0/images/cdc-touch-icon-114x114.png"/>
	<link rel="apple-touch-icon" sizes="72x72" href="/TemplatePackage/3.0/images/cdc-touch-icon-72x72.png"/>
	<link rel="apple-touch-icon" href="/TemplatePackage/3.0/images/cdc-touch-icon-57x57.png"/>
	<link rel="shortcut icon" href="/TemplatePackage/3.0/images/favicon.ico"/>

	<meta name="robots" content="index, archive" />	<meta property="cdc:template_version" content="3.0"/>
	<meta property="cdc:content_id" content="2639" />
		
	<link rel="canonical" href="https://www.cdc.gov/healthyweight/bmi/calculator.html"/>
	<meta property="cdc:wcms_build" content="4.8.0.2 - b.1724" />

	
	<!-- include virtual="/TemplatePackage/3.0/includes/head.html" -->
		<link rel="stylesheet" href="../pho_mcms/css/bootstrap24.css" />
	<link rel="stylesheet" href="../pho_mcms/css/app.css?3.2.3.8" />
	<!--[if gt IE 9]><!--><!--<![endif]-->
	<!--[if IE 7]>
		<link rel="stylesheet" href="/TemplatePackage/3.0/css/lib/font-awesome-ie7.css" />
	<![endif]-->
	<!--[if lt IE 9]>
		<link rel="stylesheet" href="/TemplatePackage/3.0/css/ie.css" />
	<![endif]-->
	<link rel="stylesheet" media="print" href="../pho_mcms/css/print.css?3.2.3.8" />
	<script src="../pho_mcms/js/modernizr-latest.js"></script>
	<script>
		if(!Date.now){Date.now=function now(){return new Date().getTime()}}
		var page_timing = page_timing || {};
		page_timing.page_start = Date.now();
		function $$(e){if(window.$){e()}else{setTimeout(function(){$$(e)},50)}}
		// (function(){function e(e,t){var n=e.length;while(n--){if(e[n].indexOf(t)>-1){return e[n]}}return false}var t=e(document.getElementsByTagName("html")[0].className.split(" "),"theme-");if(t){var n=document.createElement("link");n.rel="stylesheet";n.type="text/css";n.media="screen";n.href="/TemplatePackage/3.0/css/themes/"+t+".css";document.getElementsByTagName("head")[0].appendChild(n)}})();

		var settings = {}, addthis = null;
	</script>

	
			</div>
</div>
									<div id="featureArea">
						
														<div class="span19">
																	</div>
													</div>
										<div class="breadcrumbs hidden-one span19">
			<div class="bread-crumb hidden-one">
</div>
		</div>
						<div class="span19 pagetitle">
					<div class="syndicate">									<h1>BMI Percentile Calculator for Child and Teen</h1>
													</div>				</div>
				<div id="share-bar" class="span19">
					<div class="socialmediabar">
						<div class="row">
							<div class="hidden-one pull-right">
																							</div>
							<div class="span8">
								<div id="socialMediaShareContainer">
	<div class="share_container noLinking">
	 	<a class="share_button_facebook" title="Facebook" href="#"><span class="tp-sr-only">Recommend on Facebook</span><span id="share_facebook" class="facebookRecommend"> </span></a>
	 	<a class="share_button_twitter" title="Twitter" href="#"><span class="tp-sr-only">Tweet</span><span id="share_twitter" class="twitterTweet"> </span></a>
		<a class="share_button" href="#socialMediaShareContainer" ><img src="/TemplatePackage/3.0/images/social/addthis-32.png" alt="Share" /><span class="shareButtonEn tp-sr-only" aria-label="Share">Share</span><span class="shareButtonEs tp-sr-only" aria-label="Compartir">Compartir</span></a>
	</div>
</div>

<!-- target anchor for return to top feature in VP1 -->
<a id="content-start" tabindex="-1"></a>
															</div>
						</div>
					</div>
				</div>
				<!-- body -->
				<div id="body" class="span19">
					<div id="contentArea" >
																		
						<div class="syndicate">
							
							<div class="row"><div class="span19"><p><select class="pull-right" onchange="window.location='./' + this.value"><option selected value="calculator.html">English</option><option value="../spanish/bmi/calculator.html">Espa&ntilde;ol (Spanish)</option></select>This calculator provides BMI and the corresponding BMI-for-age percentile based on the CDC growth charts for children and teens (ages 2 through 19 years). Because of possible rounding errors in age, weight, and height, the results from this calculator may differ slightly from BMI-for-age percentiles calculated by other programs.<br>
For adults 20 years old and older, use the <a href="/healthyweight/assessing/bmi/adult_BMI/english_bmi_calculator/bmi_calculator.html">Adult BMI Calculator</a>.</p>
<p><a href="/healthyweight/assessing/bmi/childrens_BMI/measuring_children.html">Measuring Height and Weight Accurately At Home</a></p>

</div>
</div><div class="row"><div class="span12">
	<div class="mb-3 wpb_raw_code wpb_content_element wpb_raw_html">
		<div class="wpb_wrapper">
			<script src="../pho_mcms/js/jquery.min.js"></script>
<script src="../pho_mcms/js/moment.min.js"></script>

<link rel="stylesheet" type="text/css" href="../pho_mcms/css/calculator.css">
<!-- ##############################################################################- -->




<!-- ############################################################################## -->

<div id="calculator_form_wrapper" class="module-typeA">

    <h3>BMI Calculator for Child and Teen</h3>


    <!-- ######################## FORM ######################## -->
    <div class="pull-right">

      <input checked type="radio" id="english" name="english_metric" value="english">
      <label for="english">English</label>&nbsp;&nbsp;

      <input type="radio" id="metric" name="english_metric" value="metric">
      <label for="metric">Metric</label>

    </div><br>

    <p class="form_err" id="all_form_check">&#10071; Please check the accuracy of the information you entered.</p>
    <p class="form_err_age_diff" id="age_under_2"><b>Birth Date</b> must be at least 2 years before <b>Date of Measurement</b>. If the child is under 2 years old, BMI cannot be calculated. Consult a healthcare provider for assessment.</p>
    <p class="form_err_age_diff" id="age_over_20">Based on the <b>Birth Date</b> and <b>Date of Measurement</b>, the calculated age is 20 years or older. This calculator can be used only if the calculated age is less than 20 years old. If the dates you entered are correct, use the <a href="/healthyweight/assessing/bmi/adult_BMI/english_bmi_calculator/bmi_calculator.html">Adult BMI Calculator</a>.</p>

    <div class="linebreak"></div>

    <div class="radio_buttons">
      <div class="inline_blk">
        <input checked type="radio" id="age_y_m" name="age_ym_or_do" value="age_y_m">
        <label for="age_y_m">Age: Years, Months</label>&nbsp;&nbsp;&nbsp;&nbsp;
      </div>
      <div class="inline_blk">
        <input type="radio" id="age_do" name="age_ym_or_do" value="age_do">
        <label for="age_do">Date of Birth, Date of Measurement</label>
      </div>
    </div>

    <div id="div_age_y_m">
    <p><b>Age:</b> <span class="form_err" id="age_check"> Select Age</span></p>

    <div class="inline_blk">
      <input type="text" pattern="[0-9]" maxlength="3" name="age_y_direct" id="age_y_direct">
      <label for="age_y_direct">years <small>(2 to 19)</small></label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    </div>

    <div class="inline_blk">
      <input type="text" pattern="[0-9]" maxlength="2" name="age_m_direct" id="age_m_direct">
      <label for="age_m_direct">months <small>(0 to 11)</small></label>
    </div>

    <p> or enter only the total number of months:</p>
    <input type="text" pattern="[0-9]" maxlength="3" name="age_m_only_direct" id="age_m_only_direct">
    <label for="age_m_only_direct">months <small>(24 to 239)</small></label>


  </div>

    <div id="div_dob_dom">

      <div id="div_dob">
        <p><b>Birth Date:</b> <span class="form_err" id="dob_check"> Select Date</span></p>

        <label for="dob_month" class="accessibleHide">Month:</label>
        <select name="dob_month" id="dob_month">
          <option selected value="0">Month</option>
          <option value="01">January</option>
          <option value="02">February</option>
          <option value="03">March</option>
          <option value="04">April</option>
          <option value="05">May</option>
          <option value="06">June</option>
          <option value="07">July</option>
          <option value="08">August</option>
          <option value="09">September</option>
          <option value="10">October</option>
          <option value="11">November</option>
          <option value="12">December</option>
        </select>&nbsp;&nbsp;&nbsp;

        <label for="dob_day" class="accessibleHide">Day:</label>
        <select name="dob_day" id="dob_day">
          <option value="0">Day</option>
          <option value="01">1</option>
          <option value="02">2</option>
          <option value="03">3</option>
          <option value="04">4</option>
          <option value="05">5</option>
          <option value="06">6</option>
          <option value="07">7</option>
          <option value="08">8</option>
          <option value="09">9</option>
          <option value="10">10</option>
          <option value="11">11</option>
          <option value="12">12</option>
          <option value="13">13</option>
          <option value="14">14</option>
          <option value="15">15</option>
          <option value="16">16</option>
          <option value="17">17</option>
          <option value="18">18</option>
          <option value="19">19</option>
          <option value="20">20</option>
          <option value="21">21</option>
          <option value="22">22</option>
          <option value="23">23</option>
          <option value="24">24</option>
          <option value="25">25</option>
          <option value="26">26</option>
          <option value="27">27</option>
          <option value="28">28</option>
          <option value="29">29</option>
          <option value="30">30</option>
          <option value="31">31</option>
        </select>&nbsp;&nbsp;&nbsp;

        <label for="dob_year" class="accessibleHide">Year:</label>
        <select name="dob_year" id="dob_year">
           <option value="0">Year</option>
           <option value="2017">2017</option>
           <option value="2016">2016</option>
           <option value="2015">2015</option>
           <option value="2014">2014</option>
           <option value="2013">2013</option>
           <option value="2012">2012</option>
           <option value="2011">2011</option>
           <option value="2010">2010</option>
           <option value="2009">2009</option>
           <option value="2008">2008</option>
           <option value="2007">2007</option>
           <option value="2006">2006</option>
           <option value="2005">2005</option>
           <option value="2004">2004</option>
           <option value="2003">2003</option>
           <option value="2002">2002</option>
           <option value="2001">2001</option>
           <option value="2000">2000</option>
           <option value="1999">1999</option>
           <option value="1998">1998</option>
        </select>&nbsp;&nbsp;&nbsp;
      </div>

      <div id="div_dom">
        <p><b>Date of Measurement:</b> <span class="form_err" id="dom_check"> Select Date</span></p>

        <label for="dom_month" class="accessibleHide">Month:</label>
        <select name="dom_month" id="dom_month">
          <option selected value="0">Month</option>
          <option value="01">January</option>
          <option value="02">February</option>
          <option value="03">March</option>
          <option value="04">April</option>
          <option value="05">May</option>
          <option value="06">June</option>
          <option value="07">July</option>
          <option value="08">August</option>
          <option value="09">September</option>
          <option value="10">October</option>
          <option value="11">November</option>
          <option value="12">December</option>
        </select>&nbsp;&nbsp;&nbsp;

        <label for="dom_day" class="accessibleHide">Day:</label>
        <select name="dom_day" id="dom_day">
          <option value="0">Day</option>
          <option value="01">1</option>
          <option value="02">2</option>
          <option value="03">3</option>
          <option value="04">4</option>
          <option value="05">5</option>
          <option value="06">6</option>
          <option value="07">7</option>
          <option value="08">8</option>
          <option value="09">9</option>
          <option value="10">10</option>
          <option value="11">11</option>
          <option value="12">12</option>
          <option value="13">13</option>
          <option value="14">14</option>
          <option value="15">15</option>
          <option value="16">16</option>
          <option value="17">17</option>
          <option value="18">18</option>
          <option value="19">19</option>
          <option value="20">20</option>
          <option value="21">21</option>
          <option value="22">22</option>
          <option value="23">23</option>
          <option value="24">24</option>
          <option value="25">25</option>
          <option value="26">26</option>
          <option value="27">27</option>
          <option value="28">28</option>
          <option value="29">29</option>
          <option value="30">30</option>
          <option value="31">31</option>
        </select>&nbsp;&nbsp;&nbsp;

        <label for="dom_year" class="accessibleHide">Year:</label>
        <select name="dom_year" id="dom_year">
         <option value="0">Year</option>
         <option value="2019">2019</option>
         <option value="2018">2018</option>
         <option value="2017">2017</option>
         <option value="2016">2016</option>
         <option value="2015">2015</option>
         <option value="2014">2014</option>
         <option value="2013">2013</option>
         <option value="2012">2012</option>
         <option value="2011">2011</option>
         <option value="2010">2010</option>
         <option value="2009">2009</option>
         <option value="2008">2008</option>
         <option value="2007">2007</option>
         <option value="2006">2006</option>
         <option value="2005">2005</option>
         <option value="2004">2004</option>
         <option value="2003">2003</option>
         <option value="2002">2002</option>
         <option value="2001">2001</option>
         <option value="2000">2000</option>
         <option value="1999">1999</option>
         <option value="1998">1998</option>
      </select>&nbsp;&nbsp;&nbsp;
      </div>

    </div>

    <div class="linebreak"></div>

    <div id="div_sex_m_f">
      <p><b>Sex:</b> <span class="form_err" id="sex_m_f_check"> Select Sex</span></p>

      <input type="radio" id="sex_m" name="sex_m_f" value="sex_m">
      <label for="sex_m">Boy</label>&nbsp;&nbsp;&nbsp;

      <input type="radio" id="sex_f" name="sex_m_f" value="sex_f">
      <label for="sex_f">Girl</label>

    </div>

    <div class="linebreak"></div>

    <div class="radio_buttons" id="radio_en_drop_or_direct">
      <div class="inline_blk">
        <input checked type="radio" id="height_eng_direct" name="height_eng_drop_or_direct" value="height_eng_direct">
        <label for="height_eng_direct">Height: Inches</label>&nbsp;&nbsp;&nbsp;&nbsp;
      </div>
      <div class="inline_blk">
        <input type="radio" id="height_eng_drop" name="height_eng_drop_or_direct" value="height_eng_drop">
        <label for="height_eng_drop">Height: Ft, Inch, Fraction</label>
      </div>
    </div>

    <div id="div_height_eng_direct">
      <p><b>Height</b> (decimal places allowed): <span class="form_err" id="height_check_eng_direct"> Select Height</span></p>

      <input type="text" pattern="[0-9]" maxlength="6" name="height_inch_direct" id="height_inch_direct">
      <label for="height_inch_direct">inches</label>
    </div>

    <div id="div_height_eng_drop">
      <p><b>Height</b>, to nearest 1/8 inch: <span class="form_err" id="height_check_eng"> Select Height</span></p>

      <label for="height_feet">Feet</label>
      <select name="height_feet" id="height_feet">
         <option value="0">0</option>
         <option value="1">1</option>
         <option value="2">2</option>
         <option value="3">3</option>
         <option value="4">4</option>
         <option value="5">5</option>
         <option value="6">6</option>
         <option value="7">7</option>
      </select>&nbsp;&nbsp;&nbsp;

      <label for="height_inches">Inches</label>
      <select name="height_inches" id="height_inches">
         <option value="0">0</option>
         <option value="1">1</option>
         <option value="2">2</option>
         <option value="3">3</option>
         <option value="4">4</option>
         <option value="5">5</option>
         <option value="6">6</option>
         <option value="7">7</option>
         <option value="8">8</option>
         <option value="9">9</option>
         <option value="10">10</option>
         <option value="11">11</option>
      </select>&nbsp;&nbsp;&nbsp;

      <label for="height_fraction_inches">Fractions of an inch</label>
      <select name="height_fraction_inches" id="height_fraction_inches">
         <option value="0">0</option>
         <option value="0.125">1/8</option>
         <option value="0.25">1/4</option>
         <option value="0.375">3/8</option>
         <option value="0.5">1/2</option>
         <option value="0.625">5/8</option>
         <option value="0.75">3/4</option>
         <option value="0.875">7/8</option>
      </select>

      <p>(12 inches = 1 foot; Example: 4 feet, 5 1/2 inches)</p>
    </div>



    <div id="linebreak_eng" class="linebreak"></div>

    <div class="radio_buttons" id="radio_en_weight_direct_or_drop">
      <div class="inline_blk">
        <input checked type="radio" id="weight_eng_direct" name="weight_eng_direct_or_drop" value="weight_eng_direct">
        <label for="weight_eng_direct">Weight: Lbs</label>&nbsp;&nbsp;&nbsp;&nbsp;
      </div>
      <div class="inline_blk">
        <input type="radio" id="weight_eng_drop" name="weight_eng_direct_or_drop" value="weight_eng_drop">
        <label for="weight_eng_drop">Weight: Lbs, Fraction</label>
      </div>
    </div>

    <div id="div_weight_eng_direct">
       <p><b>Weight</b> (decimal places allowed): <span class="form_err" id="weight_check_eng_direct"> Select Weight</span></p>
       <div class="inline_blk">
        <input type="text" pattern="[0-9]" maxlength="5" name="weight_lbs_direct" id="weight_lbs_direct">
        <label for="weight_lbs_direct">lbs</label>&nbsp;&nbsp;&nbsp;
      </div>
    </div>

    <div id="div_weight_eng">
      <p><b>Weight</b>, to nearest 1/4 (.25) pound: <span class="form_err" id="weight_check_eng"> Select Weight</span></p>

      <div class="inline_blk">
        <input type="text" pattern="[0-9]" maxlength="3" name="weight_pounds" id="weight_pounds">
        <label for="weight_pounds">pounds</label>&nbsp;&nbsp;&nbsp;
      </div>

      <div class="inline_blk">
        <select name="weight_fractions_pounds" id="weight_fractions_pounds">
         <option value="0">0</option>
         <option value="0.125">1/8</option>
         <option value="0.25">1/4</option>
         <option value="0.375">3/8</option>
         <option value="0.5">1/2</option>
         <option value="0.625">5/8</option>
         <option value="0.75">3/4</option>
         <option value="0.875">7/8</option>
        </select>
        <label for="weight_fractions_pounds">fractions of a pound</label>
      </div>
      <p>(8 ounces = 1/2 pounds; Example: 75 3/4 pounds)</p>
    </div>


    <!-- ######### METRIC ######### -->


    <div id="div_height_metr">
      <p><b>Height</b> (decimal places allowed): <span class="form_err" id="height_check_metr"> Select Height</span></p>

      <input type="text" pattern="[0-9]" maxlength="5" name="heght_cm" id="height_cm">
      <label for="height_cm">cm</label>

    </div>

    <div class="linebreak"></div>

    <div id="div_weight_metr">
      <p><b>Weight</b> (decimal places allowed): <span class="form_err" id="weight_check_metr"> Select Weight</span></p>

      <input type="text" pattern="[0-9]" maxlength="5" name="weight_kg" id="weight_kg">
      <label for="weight_kg">kg</label>
      <p></p>
    </div>

    <div>
      <button id="button_calculate" type="button" class="btn btn-primary">Calculate</button>
    </div>

    <!-- ######################## ./FORM ######################## -->

</div><!-- ./calculator_form_wrapper -->



<!-- p class="span12"><i>
Note: Please keep in mind that this BMI calculator is not meant to serve as a source of clinical guidance and is not intended to be a substitute for professional medical advice. Because BMI is based on weight and height, it is only an indicator of body fatness. Individuals with the same BMI may have different amounts of body fat. Persons may consider seeking advice from their healthcare providers on healthy weight status.
</i></p>
<p class="span12"><i>
Because of possible rounding errors in age, weight and height, the results from this calculator may differ slightly from BMI-for-age percentiles calculated by other programs.
</i></p -->


<!-- ############################################################################## -->



<script src="../pho_mcms/js/calculator.js"></script>

		</div>
	</div>

</div><div class="span7">			<a href="/nccdphp/dnpao/resources/child-teen-resources.html">
				<img class="pull-right margin-left-ten" alt="Child and Teen Healthy Weight and Obesity. Learn More at www.cdc.gov/nccdphp/dnpao/resources/child-teen-resources.html" src="/healthyweight/bmi/img/BMI-collage-button.jpg">
					</a>
			
</div>
</div><div class="row"><div class="span19"><p><em>Note: Please keep in mind that this BMI calculator is not meant to serve as a source of clinical guidance and is not intended to be a substitute for professional medical advice. Because BMI is based on weight and height, it is only an indicator of body fatness. Individuals with the same BMI may have different amounts of body fat. Persons may consider seeking advice from their healthcare providers on healthy weight status.</em></p>
<p>Because of possible rounding errors in age, weight and height, the results from this calculator may differ slightly from BMI-for-age percentiles calculated by other programs.</p>

</div>
</div>

							</div>
														<!-- Related Nav Area -->
		<div class="nav-related hidden-three hidden-four">
			<div class="module-typeG emailupdates">
 <span class="sprite-24-govd-icon"></span>
 <h4>Get Email Updates</h4>
 <p>To receive email updates about this page, enter your email address:</p>
 <form name="govdelivery" action="https://public.govdelivery.com/accounts/USCDC/subscribers/qualify">
  <fieldset>
   <input type="hidden" value="USCDC_219" name="topic_id" />
   <label><span class="hidden">Enter Email Address</span><input type="text" class="email" name="email" value="" onfocus="this.value=''" /></label>
   <a class="explain" href="http://www.cdc.gov/emailupdates/">What's this?</a>
   <a href="javascript:quicksubscribe();return false;" class="button">Submit</a>
   <noscript>
    <a class="explain" href="http://www.cdc.gov/emailupdates/">What's this?</a>
    <label><span class="hidden">Submit Button</span><input type="submit" class="button submit" name="commit" value="Submit" /></label>
   </noscript>
  </fieldset>
 </form>
</div>			<div class="module-typeH topicmedia no-link">
<h3><a href="/nccdphp/dnpao/index.html">Division of Nutrition, Physical Activity, and Obesity</a></h3>
			<a href="/nccdphp/dnpao/index.html">
				<img class="" alt="DNPAO logo" src="/nccdphp/dnpao/images/home/dnpao-links-logo_187px.png"></a>
		
<ul class="list-block">
<li><a href="/nccdphp/dnpao/index.html">About Us</a></li>
<li><a href="/nutrition/index.html">Nutrition</a></li>
<li><a href="/physicalactivity/index.html">Physical Activity</a></li>
<li><a href="/obesity/index.html">Overweight &amp; Obesity</a></li>
<li><a href="/healthyweight/index.html">Healthy Weight</a></li>
<li><a href="/breastfeeding/index.htm">Breastfeeding</a></li>
<li><a href="/immpact/index.html">Micronutrient Malnutrition</a></li>
<li class="last"><a href="/nccdphp/dnpao/state-local-programs/index.html">State and Local Programs</a></li>
</ul>
</div>
<div class="module-typeH topicmedia no-link">
<h3>Related Topics</h3>
<ul class="list-block">
<li><a href="/diabetes/">Diabetes</a></li>
<li><a href="/nutrition/index.html">Nutrition</a></li>
</ul>
</div>
		</div>
		<!-- /end Related Nav Area -->
															<!-- Persistent Content Area -->
							<div id="content-secondary">
															</div><!-- /end #content-secondary -->
											</div><!-- /end #contentArea -->
				</div><!-- /end #body -->
			</div>
						<div class="row">
				<div class="span24 visible-one">
														</div>
			</div>

			<div class="row">
				<div class="span24">
					<div id="plugin-legend" class="pluginOff">
	<h5>File Formats Help:</h5><span><a href="https://www.cdc.gov/Other/plugins/">How do I view different file formats (PDF, DOC, PPT, MPEG) on this site?</a></span>
	<ul>
		<li class="plugin-pdf"><a href="https://www.cdc.gov/Other/plugins/#pdf"><span class="sprite-16-pdf">Adobe PDF file</span></a></li>
		<li class="plugin-ppt"><a href="https://www.cdc.gov/Other/plugins/#ppt"><span class="sprite-16-ppt">Microsoft PowerPoint file</span></a></li>
		<li class="plugin-word"><a href="https://www.cdc.gov/Other/plugins/#doc"><span class="sprite-16-word">Microsoft Word file</span></a></li>
		<li class="plugin-excel"><a href="https://www.cdc.gov/Other/plugins/#xls"><span class="sprite-16-excel">Microsoft Excel file</span></a></li>
		<li class="plugin-wmv"><a href="https://www.cdc.gov/Other/plugins/#wmv"><span class="sprite-16-wmv">Audio/Video file</span></a></li>
		<li class="plugin-qt"><a href="https://www.cdc.gov/Other/plugins/#qt"><span class="sprite-16-qt">Apple Quicktime file</span></a></li>
		<li class="plugin-real"><a href="https://www.cdc.gov/Other/plugins/#ram"><span class="sprite-16-rp">RealPlayer file</span></a></li>
		<li class="plugin-text"><a href="https://www.cdc.gov/Other/plugins/#text"><span class="sprite-16-txt">Text file</span></a></li>
		<li class="plugin-zip"><a href="https://www.cdc.gov/Other/plugins/#zip"><span class="sprite-16-zip">Zip Archive file</span></a></li>
		<li class="plugin-sas"><a href="https://www.cdc.gov/Other/plugins/#sas"><span class="sprite-16-sas">SAS file</span></a></li>
		<li class="plugin-epub"><a href="https://www.cdc.gov/Other/plugins/#epub"><span class="sprite-16-ebook">ePub file</span></a></li>
		<li class="plugin-ris"><a href="https://www.cdc.gov/Other/plugins/#ris"><span class="sprite-16-ris">RIS file</span></a></li>
	</ul>
</div>
				</div>
			</div>

			<!-- date stamp -->
			<div id="datestamp" class="row" itemscope="itemscope" itemtype="http://schema.org/WebPage">
				<div class="span24">
					<ul>
						<li class="last-reviewed">Page last reviewed: <span itemprop="lastReviewed">January 3, 2019</span></li>						<li class="last-updated">Page last updated: <span itemprop="dateModified">January 3, 2019</span></li>						<li class="content-source">Content source:
							<ul>
<li itemprop="sourceOrganization" itemscope="itemscope" itemtype="http://schema.org/Organization"><a href="/nccdphp/dnpao/index.html">Division of Nutrition, Physical Activity, and Obesity</a>, <a href="http://www.cdc.gov/chronicdisease">National Center for Chronic Disease Prevention and Health Promotion</a></li>
</ul>
						</li>
											</ul>
									</div>
							</div>
		</div><!-- /end #content -->
	</div><!-- / end .container -->
			<!-- footer -->
	<footer id="footer" class="cdcSlimFooter">
	
 <!-- include eng footerSubSocialMedia.html -->
<div class="socialMedia">
	<div class="container">
		<nav class="followcdc">
			<ul>
				<li><a href="https://www.cdc.gov/Other/emailupdates"><span class="sprite-24-govd"></span><span class="tp-sr-only">Email</span></a></li>
				<li><a href="https://www.facebook.com/CDC" target="_blank"><span class="sprite-24-facebook"></span><span class="tp-sr-only">Recommend</span></a></li>
				<li><a href="https://twitter.com/CDCgov" target="_blank"><span class="sprite-24-twitter"></span><span class="tp-sr-only">Tweet</span></a></li>
				<li><a href="https://www.youtube.com/user/CDCstreamingHealth" target="_blank"><span class="sprite-24-youtube"></span><span class="tp-sr-only">YouTube</span></a></li>
				<li><a href="https://www.instagram.com/CDCgov/" target="_blank"><span class="sprite-24-instagram"></span><span class="tp-sr-only">Instagram</span></a></li>
			</ul>
		</nav>
		<nav class="cdcmedia">
			<ul>
				<li><a href="https://www2c.cdc.gov/podcasts"><span class="sprite-24-listen"></span><span class="tp-sr-only">Listen</span></a></li>
				<li><a href="https://www.cdc.gov/cdctv"><span class="sprite-24-watch"></span><span class="tp-sr-only">Watch</span></a></li>
				<li><a href="https://tools.cdc.gov/podcasts/rss.asp"><span class="sprite-24-rss"></span><span class="tp-sr-only">RSS</span></a></li>
			</ul>
		</nav>
	</div>
</div>
 <!-- /include eng footerSubSocialMedia.html -->

	<div class="container">
		<div class="cdcLinks">
			<div class="container">
				<ul>
					
<!-- include eng footerSubCdcLinks.html-->
<li>
	<nav>
		<h6 class="hidden-four hidden-three">ABOUT <span class="icon-plus visible-one pull-right"></span></h6>
		<ul class="hidden-one">
			<li><a href="https://www.cdc.gov/about/default.htm">About CDC</a></li>
			<li><a href="https://jobs.cdc.gov">Jobs</a></li>
			<li><a href="https://www.cdc.gov/funding">Funding</a></li>
		</ul>
	</nav>
</li>
<li>
	<nav>
		<h6 class="hidden-four hidden-three">LEGAL <span class="icon-plus visible-one pull-right"></span></h6>
		<ul class="hidden-one">
			<li><a href="https://www.cdc.gov/Other/policies.html">Policies</a></li>
			<li><a href="https://www.cdc.gov/Other/privacy.html">Privacy</a></li>
			<li><a href="https://www.cdc.gov/od/foia">FOIA</a></li>
			<li><a href="https://www.cdc.gov/eeo/nofearact/index.htm">No Fear Act</a></li>
			<li><a href="https://oig.hhs.gov" class="no-link">OIG</a></li>
		</ul>
	</nav>
</li>
<!--/ include eng footerSubCdcLinks.html-->

				</ul>
			</div>
		</div>
		<div class="cdcContact">
			<div class="container">
				<ul>
					<li class="local-contact">
						
 <!-- include eng footerSubGlobalContact1.html -->
<section>
	<address class="address" itemscope="itemscope" itemtype="https://schema.org/Organization">
		<span class="value" itemprop="address" itemscope="itemscope" itemtype="https://schema.org/PostalAddress">
			<span itemprop="streetAddress">1600 Clifton Road</span>
			<span itemprop="addressLocality">Atlanta</span>,
			<span itemprop="addressRegion">GA</span>
			<span itemprop="postalCode">30329-4027</span>
			<span itemprop="addressCountry">USA</span>
		</span><br />
		<span class="value" itemprop="telephone">800-CDC-INFO (800-232-4636)</span>,
		<span class="value" itemprop="telephone">TTY: 888-232-6348</span><br />
		<span class="value" itemprop="contactPoint" itemscope="itemscope" itemtype="https://schema.org/ContactPoint">
			<span itemprop="url"><a href="https://wwwn.cdc.gov/dcs/RequestForm.aspx" class=" default no-link">Email CDC-INFO</a></span>
		</span>
	</address>
</section>
 <!-- /include eng footerSubGlobalContact1.html -->

					</li>
					<li class="contact">
						
 <!-- include eng footerSubGlobalContact2.html -->
<section>
	<address class="address" itemscope="itemscope" itemtype="https://schema.org/Organization">
		<span class="value" itemprop="contactPoint" itemscope="itemscope" itemtype="https://schema.org/ContactPoint">
			<span itemprop="url"><a href="https://www.hhs.gov" class="no-link">U.S. Department of Health & Human Services</a></span>
		</span><br />
        <span class="value" itemprop="contactPoint" itemscope="itemscope" itemtype="https://schema.org/ContactPoint">
        	<span itemprop="url"><a href="https://www.hhs.gov/open" class="no-link">HHS/Open</a></span>
        </span><br />
        <span class="value" itemprop="contactPoint" itemscope="itemscope" itemtype="https://schema.org/ContactPoint">
			<span itemprop="url"><a href="https://www.usa.gov/" class="no-link">USA.gov</a></span>
		</span>
	</address>
</section>
 <!-- /include eng footerSubGlobalContact2.html -->

					</li>
				</ul>
			</div>
		</div>
	</div>
</footer>	<!-- /#footer -->
	<div id="totop" class="off visible-one">TOP</div>
	</div>

	<script>page_timing.libs_start = Date.now();</script><script src="../pho_mcms/js/libs.min.js?3.2.3.8"></script><script>page_timing.libs_end = Date.now();page_timing.core_start = Date.now();</script><script src="../pho_mcms/js/core.min.js?3.2.3.8"></script><script>page_timing.core_end = Date.now();</script>
	<script>
</script>
	<script>page_timing.app_start = Date.now();</script><script src="../pho_mcms/js/app.min.js?3.2.3.8"></script><script>page_timing.app_end = Date.now();</script>
	<!-- start wcmsrd-1929 -->
		<!-- end wcmsrd-1929 -->

	<!-- Begin Survey scripts -->
<script src="/JScript/foresee/foresee-trigger.js"></script>
<!-- End Survey scripts -->

	<script>if (typeof page_timing !== 'undefined') { page_timing.metrics_start = Date.now(); }</script>
<!-- xxxxxxxxxxxxxxxxxx METRICS code begins here xxxxxxxxxxxxxxxxxxxxxxxxxxx-->
<div id="metrics">

<!-- Begin Google DAP inclusion -->
<script id="_fed_an_ua_tag" src="../pho_mcms/js/Universal-Federated-Analytics-Min.js?agency=HHS&amp;subagency=CDC"></script>
<!-- End Google DAP inclusion -->

<!-- Begin Template Package Custom Interactions and Metrics Hierarchy/Levels Support -->
<script src="../pho_mcms/js/rd_custom_interactions.js"></script>
<script src="../pho_mcms/js/topic_levels.js"></script>
<!-- End Template Package Custom Interactions and Metrics Hierarchy/Levels Support -->

<!-- Adbobe Analytics code version: JS-2.0 -->
<script src="../pho_mcms/js/analytics_cdcgov.js"></script>
<script>

	if ('undefined' !== typeof enquire) {
		enquire.register(CDC.Global.selectors.vp1, function() {
			s.prop49 = 1;
		});
		enquire.register(CDC.Global.selectors.vp2, function() {
			s.prop49 = 2;
		});
		enquire.register(CDC.Global.selectors.vp3, function() {
			s.prop49 = 3;
		});
		enquire.register(CDC.Global.selectors.vp4, function() {
			s.prop49 = 4;
		});
	}

	    s.pageName=document.title
    s.channel="Healthy Weight"
    siteCatalyst.setLevel1("Chronic"); 
    siteCatalyst.setLevel2("Division of Nutrition, Physical Activity, and Obesity DNPAO"); 
    siteCatalyst.setLevel3("Healthy Weight"); 
    
    
	
	
	s.prop2=window.location.href.toLowerCase();
s.prop26=document.title;
s.prop30=document.title;
s.prop31=window.location.href.toLowerCase();
s.prop46=window.location.href.toLowerCase();
s.server=window.location.hostname;

// Simplified URL
s.prop73 = window.location.href.split('?')[0].split('#')[0].toLowerCase();
s.eVar73 = window.location.href.split('?')[0].split('#')[0].toLowerCase();

// Update the level variables here.
updateVariables(s);

// Set the referrer value if passed on the querystring from a CDC page-level redirect.
if ('undefined' !== typeof CDC && 'undefined' !== typeof CDC.qs && CDC.qs['CDC_AA_refVal']) {
  s.referrer = CDC.qs['CDC_AA_refVal'];
}

/************* DO NOT ALTER ANYTHING BELOW THIS LINE ! **************/
var s_code=s.t();
if(s_code) {document.write(s_code);}
</script>
<script type="text/javascript">
if(navigator.appVersion.indexOf('MSIE')>=0) { document.write(unescape('%3C')+'\!-'+'-'); }
</script>
<noscript><a href="https://cdc.112.2o7.net"><img src="https://cdc.112.2o7.net/b/ss/cdcgov/1/H.21--NS/01/H.21--NS/0" height="1" width="1" alt="Web Analytics" /></a></noscript><!--/DO NOT REMOVE/-->
<!-- End SiteCatalyst code version: H.21. -->
<!-- Begin Template Package DigitalGov Search Support -->
<script type="text/javascript" src="../pho_mcms/js/rd_search.js"></script>
<!-- End Template Package DigitalGov Search Support -->
</div>
<!-- xxxxxxxxxxxxxxxxxx METRICS code ends here xxxxxxxxxxxxxxxxxxxxxxxxxxx-->
<script>if (typeof page_timing !== 'undefined') { page_timing.metrics_end = Date.now(); }</script>


	<script>$(document).ready(function(){var cdcLeftNav = new CDC.LeftNav('nav-primary');
cdcLeftNav.render();
});</script>
	
	
	
	</body>
</html>

	