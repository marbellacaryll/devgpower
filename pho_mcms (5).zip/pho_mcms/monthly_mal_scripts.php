<?php
  $dbHost = "localhost";
  $dbDatabase = "mcmsdb";
  $dbUser = "root";
  $dbPasswrod = "";
  
  $conn = mysqli_connect($dbHost, $dbUser, $dbPasswrod, $dbDatabase);

	//set timezone
	//date_default_timezone_set('Asia/Manila');

   //FOR GLOBE
	$gyear = date('Y');
	$gtotal=array();
	for ($gmonth = 1; $gmonth <= 12; $gmonth ++){
		$sql="SELECT *, COUNT(bar_id) as total FROM physical_info WHERE month(time)='$gmonth' and year(time)='$gyear' and health_status = 'This is considered as  Obese'";
		$query=$conn->query($sql);
		$row = mysqli_fetch_assoc($query);

		$gtotal[]=$row['total'];
	}

	$objan = $gtotal[0];
	$obfeb = $gtotal[1];
	$obmar = $gtotal[2];
	$obapr = $gtotal[3];
	$obmay = $gtotal[4];
	$objun = $gtotal[5];
	$objul = $gtotal[6];
	$obaug = $gtotal[7];
	$obsep = $gtotal[8];
	$oboct = $gtotal[9];
	$obnov = $gtotal[10];
	$obdec = $gtotal[11];
	//END FOR GLOBE

	
	//FOR TM
	$tmyear = date('Y');
	$tmtotal=array();
	for ($tmmonth = 1; $tmmonth <= 12; $tmmonth ++){
		$sql="SELECT *, COUNT(bar_id) as total FROM physical_info WHERE month(time)='$tmmonth' and year(time)='$tmyear' and health_status = 'This is considered as  severly Underweight'";
		$query=$conn->query($sql);
		$row = mysqli_fetch_assoc($query);
		$tmtotal[]=$row['total'];
	}

	$serjan = $tmtotal[0];
	$serfeb = $tmtotal[1];
	$sermar = $tmtotal[2];
	$serapr = $tmtotal[3];
	$sermay = $tmtotal[4];
	$serjun = $tmtotal[5];
	$serjul = $tmtotal[6];
	$seraug = $tmtotal[7];
	$sersep = $tmtotal[8];
	$seroct = $tmtotal[9];
	$sernov = $tmtotal[10];
	$serdec = $tmtotal[11];
	//END FOR TM

	//FOR SUN
	$sunyear = date('Y');
	$suntotal=array();
	for ($sunmonth = 1; $sunmonth <= 12; $sunmonth ++){
		$sql="SELECT *, COUNT(bar_id) as total FROM physical_info WHERE month(time)='$sunmonth' and year(time)='$sunyear' and health_status = 'This is considered as Underweight'";
		$query=$conn->query($sql);
		$row = mysqli_fetch_assoc($query);
		$suntotal[]=$row['total'];
	}

	$undjan = $suntotal[0];
	$undfeb = $suntotal[1];
	$undmar = $suntotal[2];
	$undapr = $suntotal[3];
	$undmay = $suntotal[4];
	$undjun = $suntotal[5];
	$undjul = $suntotal[6];
	$undaug = $suntotal[7];
	$undsep = $suntotal[8];
	$undoct = $suntotal[9];
	$undnov = $suntotal[10];
	$unddec = $suntotal[11];
	//END FOR SUN
	
	//set timezone
	//date_default_timezone_set('Asia/Manila');
	
	
?>