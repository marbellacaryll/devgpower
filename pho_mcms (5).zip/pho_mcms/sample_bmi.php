<body>
<h1>BMI Calculator for Children and Teens</h1>
<div class="Questions" id="ChildBMICalc_Form">
<p class="Intro">Body mass index (BMI) is one way to estimate a person's body fat that takes into consideration the person's height. BMI is calculated using a person's weight 
and height. In children and teens, 
BMI is used to find out if a child or teen is underweight, of a healthy weight, overweight, or obese. A child's body fat 
changes with age. Also, girls and boys differ in their amount of body fat as they mature. This is why BMI for children, 
also known as BMI-for-age, includes gender and age.</p>
<p class="Intro">This calculator gives an approximate BMI for children from ages 5 to 18. It will tell you if a child is underweight, at an ideal weight, at risk of being overweight, 
or is now overweight.</p>
<div class="CalculatorBox" id="ChildBMICalc_Questions">
<h2>Enter Child's Information</h2>
<div class="Question" id="ChildBMICalc_q1">
<span class="QuestionText">Gender: </span>
<span class="Option">
<input id="ChildBMICalc_Gender_Male" name="ChildBMICalc_Gender" type="radio" value="m"/>
<span class="AnswerText">
<label for="ChildBMICalc_Gender_Male"> Male </label>
</span>
</span>
<span class="Option">
<input id="ChildBMICalc_Gender_Female" name="ChildBMICalc_Gender" type="radio" value="f"/>
<span class="AnswerText">
<label for="ChildBMICalc_Gender_Female"> Female</label>
</span>
</span>
</div>
<div class="Question" id="ChildBMICalc_q2">
<span class="QuestionText">
<label for="ChildBMICalc_Age_Years">Age: </label>
</span>
<span class="Option">
<select id="ChildBMICalc_Age_Years" name="ChildBMICalc_Age_Years">
<option value="-1"></option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
</select>
<span class="Unit">
<label for="ChildBMICalc_Age_Years"> years </label>
</span>
<select id="ChildBMICalc_Age_Months" name="ChildBMICalc_Age_Months">
<option value="-1"></option>
<option value="0">0</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
</select>
<span class="Unit">
<label for="ChildBMICalc_Age_Months"> months</label>
</span>
</span>
</div>
<div class="Question" id="ChildBMICalc_q3">
<span class="QuestionText">
<label for="ChildBMICalc_Height_Feet">Height: </label>
</span>
<span class="Option">
<input id="ChildBMICalc_Height_Feet" maxlength="2" name="ChildBMICalc_Height_Feet" style="WIDTH: 3em"/>
<span class="Unit">
<label for="ChildBMICalc_Height_Feet"> feet </label>
</span>
<input id="ChildBMICalc_Height_Inches" maxlength="2" name="ChildBMICalc_Height_Inches" style="WIDTH: 3em"/>
<span class="Unit">
<label for="ChildBMICalc_Height_Inches"> inches</label>
</span>
</span>
</div>
<div class="Question" id="ChildBMICalc_q4">
<span class="QuestionText">
<label for="ChildBMICalc_Weight">Weight: </label>
</span>
<span class="Option">
<input id="ChildBMICalc_Weight" maxlength="3" name="ChildBMICalc_Weight" style="WIDTH: 5em"/>
<span class="Unit">
<label for="ChildBMICalc_Weight"> lbs.</label>
</span>
</span>
</div>
<div class="Button" id="ChildBMICalc_submit">
<input id="ChildBMICalc_SubmitButton" name="ChildBMICalc_SubmitButton" onclick="ChildBMICalc_Submit();" type="button" value="Submit"/>
</div>
</div>
</div>
<style type="text/css">
    #BMIChart
    {
        background: url(http://ssov35.staywellsolutionsonline.com/317343.img) no-repeat;
        width: 99%;
        display: block;
        max-width: 675px;
        background-size: 100%;
        position: relative;
        filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(
        src='http://ssov35.staywellsolutionsonline.com/317343.img',
        sizingMethod='scale');

        -ms-filter: "progid:DXImageTransform.Microsoft.AlphaImageLoader(src='http://ssov35.staywellsolutionsonline.com/317343.img', sizingMethod='scale')";
    }
    #IncorrectInformation {
        display: none;
        color: red;
    }
    #IncorrectHeader {
        display: block;
        font-weight: bold;
        color: red;
    }
</style>
<div class="Results" id="ChildBMICalc_AboutYourResults" style="DISPLAY: none">
<a name="" target="_blank"></a>
<div class="Button" id="ChildBMICalc_reset">
<input class="resubmitbutton" id="ChildBMICalc_ResetButton" name="ChildBMICalc_ResetButton" onclick="ChildBMICalc_Reset();" type="button" value="Return to Calculator"/>
</div>
<h2>Your Results</h2>
<p id="IncorrectInformation">
<span id="IncorrectHeader"></span>
</p>
<p class="Answer" id="ChildBMICalc_AnswerBMI">
<STRONG>The information you provided gives a BMI of </STRONG>
</p>
<div class="Result" id="ChildBMICalc_AboutResults_Underweight" style="DISPLAY: none">
<p class="Explanation">This puts your child <span class="PercentileSpan"></span> percentile, which indicates your child is underweight. An ideal BMI for your child's gender and age is between <span id="ChildBMICalc_LowEndHealthyBMI_Underweight"></span> and <span id="ChildBMICalc_HighEndHealthyBMI_Underweight"></span>.</p>
<p class="Explanation">Your child may be naturally thin. Or, it's possible a medical problem could be causing your child to be underweight. Talk to your child's health care provider.</p>
</div>
<div class="Result" id="ChildBMICalc_AboutResults_Healthy" style="DISPLAY: none">
<p class="Explanation">This puts your child <span class="PercentileSpan"></span> percentile, which indicates your child is at an ideal weight. An ideal BMI for your child's gender and age is between <span id="ChildBMICalc_LowEndHealthyBMI_Healthy"></span> and <span id="ChildBMICalc_HighEndHealthyBMI_Healthy"></span>.</p>
<p class="Explanation">Having an ideal weight means the calories your child is getting from food are balanced out with his/her level of physical activity. Keep in mind, though, that some calories are nutritious and others aren't. Your child may eat the right amount of food for a healthy weight, but still not get all the nutrients needed for good overall health. That's why it's still important to encourage your child to eat nutritious foods and get plenty of exercise. Good habits learned now will last a lifetime.</p>
</div>
<div class="Result" id="ChildBMICalc_AboutResults_AtRisk" style="DISPLAY: none">
<p class="Explanation">This puts your child <span class="PercentileSpan"></span> percentile, which indicates your child is overweight. An ideal BMI for your child's gender and age is between <span id="ChildBMICalc_LowEndHealthyBMI_AtRisk"></span> and <span id="ChildBMICalc_HighEndHealthyBMI_AtRisk"></span>.</p>
<p class="Explanation">Overweight is a point at which your child's weight is no longer healthy. This is serious. Although your child isn't yet overweight, work with your health care provider—and your child—to prevent this from becoming a future problem. An overweight child may develop problems with self-esteem. And doctors have found that overweight children are developing serious health problems such as diabetes early in life that do not develop in children of normal weight.</p>
<p class="Explanation">Overweight children tend to become overweight adults. Being overweight as an adult increases the risk of serious diseases such as stroke, heart attack, diabetes, arthritis, and some forms of cancer. So now is the time to teach your child healthy habits that will last a lifetime.</p>
</div>
<div class="Result" id="ChildBMICalc_AboutResults_Overweight" style="DISPLAY: none">
<p class="Explanation">This puts your child <span class="PercentileSpan"></span> percentile, which indicates your child is obese. An ideal BMI for your child's gender and age is between <span id="ChildBMICalc_LowEndHealthyBMI_Overweight"></span> and <span id="ChildBMICalc_HighEndHealthyBMI_Overweight"></span>.</p>
<p class="Explanation">Overweight is a point at which your child's weight is no longer healthy. An overweight child may develop problems with self-esteem. And doctors have found that overweight children are developing health problems such as diabetes early in life that do not develop in children of normal weight.</p>
<p class="Explanation">Overweight children tend to become overweight adults. Being overweight as an adult increases the risk of serious diseases such as stroke, heart attack, diabetes, arthritis, and some forms of cancer. Now is the time to work with your healthcare provider—and your child—to develop healthy habits that will last a lifetime.</p>
</div>
<div id="ChartHeader" style="font-weight: bold">
<span class="PercentileSpan" style="text-transform:capitalize;"></span> percentile</div>
<div id="BMIChart">
<div id="BMIDot" style="background:url(http://ssov35.staywellsolutionsonline.com/317352.img) no-repeat left top; height: 20px; width: 100px;padding-left: 23px;">
<span id="BMISpan" style="font-weight:bold;"></span>
</div>
</div>
<p class="Disclaimer">
<i>This information is not intended as a substitute for professional health care. Always consult a health care provider for advice concerning your health. Only your health care provider can advise you about your child's health.</i>
</p>
</div>
<div class="Resources" id="ChildBMICalc_Resources">
<p>
<b>This calculator is not intended to replace the evaluation of a health care professional.</b>
</p>
</div>
<script language="javascript"><!--
	
    /****************/
    /* Generic code */
    /****************/

    // this code runs whenever the page loads
    var m_ThisCalculatorsName = "ChildBMICalc";
    var m_ExpectedNumberOfParameters = 6;

    var m_CurrentQueryString = location.search.substring(1);
    var m_PreCalculationQueryString = GetPreCalculationQueryString();
    var m_Parameters = []; // this will be initialized if and when appropriate values are present in the query string

    m_Parameters = ChildBMICalc_ParseQueryString();

    // run the calculator if all the values are present for it to work on
    if(m_Parameters.length == m_ExpectedNumberOfParameters)
    {
        try
        {
            // run the calculation code
            ChildBMICalc_Calculate();

            // Then display the results
            ChildBMICalc_DisplayResults();
        }
        catch(exc) {
            ChildBMICalc_Reset();
        }
    }


    function ChildBMICalc_ParseQueryString()
    {
        var calculatorPair;
        var isFound = false;		
        var FoundParams = [];
	
        //split the query and get out the params
        if(m_CurrentQueryString.indexOf(m_ThisCalculatorsName + "_Parameters=") >= 0) 
        {
            var queryPairs = m_CurrentQueryString.split("&");
		
            for(i = 0; i < queryPairs.length && !isFound; i++) 
            {
                if(queryPairs[i].indexOf(m_ThisCalculatorsName + "_Parameters=") >= 0) 
                {
                    isFound = true;
                    calculatorPair = queryPairs[i].split("=");
                    FoundParams = calculatorPair[1].split(",");
                }
            }
        }
        return FoundParams;
    }

    function GetPreCalculationQueryString()
    {
        m_PreCalculationQueryString = "";

        var tmpArray = m_CurrentQueryString.split("&"); //get the paired querysting parameters.

        // look for and retain all query string values extant prior to calculator being used
        for(x = 0; x < tmpArray.length; x++)
        {
            if(tmpArray[x].indexOf(m_ThisCalculatorsName + "_Parameters=") < 0) //if you dont find it, append to the newQuerystring
            {
                m_PreCalculationQueryString += tmpArray[x] + "&";
            }
        }
        // if there were any non-calculator query string values prior to running the calc, append those to this page's url
        return ((m_PreCalculationQueryString.length > 0) ? (m_PreCalculationQueryString.substring(0, m_PreCalculationQueryString.length-1)) : "");
    }

    function ChildBMICalc_Submit()
    {
        if(ChildBMICalc_Validate() == true)
        {
            // assemble query string to be used for calculation work
            ChildBMICalc_CreateQuerystring();
        }
    }

    function ChildBMICalc_Reset()
    {
        window.location.href = location.pathname + ((m_PreCalculationQueryString.length > 0) ? ("?" + m_PreCalculationQueryString) : "");
    }



    /***********************************/
    /* Functions specific to this tool */
    /***********************************/

    // Need: 
    //ChildBMICalc_Calculate
    //ChildBMICalc_DisplayResults
    //ChildBMICalc_Validate
    //ChildBMICalc_CreateQuerystring

    var Gender;
    var AgeInMonths;
    var HeightInInches;
    var Weight;

    var BMI;
    var Category;
    var LowerIdealBMI;
    var UpperIdealBMI;

    function ChildBMICalc_CreateQuerystring()
    {
        //gather the answers and put them in the querystring, repost to the same page
        var newQuerystring = m_ThisCalculatorsName + "_Parameters=";
	
        var elemGenderM = document.getElementById(m_ThisCalculatorsName + "_" + "Gender_Male");
        if(elemGenderM.checked)
            newQuerystring += elemGenderM.value +",";
	
        var elemGenderF = document.getElementById(m_ThisCalculatorsName + "_" + "Gender_Female");
        if(elemGenderF.checked)
            newQuerystring += elemGenderF.value + ",";

        var elemAgeYr = document.getElementById(m_ThisCalculatorsName + "_" + "Age_Years");
        newQuerystring +=elemAgeYr.value + ",";
	
        var elemAgeMonths = document.getElementById(m_ThisCalculatorsName + "_" + "Age_Months");
        newQuerystring += elemAgeMonths.value + ",";
	
        var elemHeightFt = document.getElementById(m_ThisCalculatorsName + "_" + "Height_Feet");
        newQuerystring += elemHeightFt.value + ",";
	
        var elemHeightIn = document.getElementById(m_ThisCalculatorsName + "_" + "Height_Inches");
        newQuerystring += elemHeightIn.value + ",";
	
        var elemWeight = document.getElementById(m_ThisCalculatorsName + "_" + "Weight");
        newQuerystring +=elemWeight.value;
        
        //newQuerystring += "#Results";
	
        if(m_PreCalculationQueryString.length > 0)
        {
            window.location.href = location.pathname + "?" + m_PreCalculationQueryString + "&" + newQuerystring;
        }
        else
        {
            window.location.href = location.pathname + "?" + newQuerystring;
        }	
    }

    function ChildBMICalc_Validate()
    {
        var strError = "The following information is missing:\r";
        var isError = false;
	
        //check the gender box
        var elemGenderM = document.getElementById(m_ThisCalculatorsName + "_" + "Gender_Male");
        var elemGenderF = document.getElementById(m_ThisCalculatorsName + "_" + "Gender_Female");

        if(!elemGenderM.checked && !elemGenderF.checked) {
            strError += " - Gender is required\r"
            isError = true;
        }

        //check the age_year		
        var elemAgeYr = document.getElementById(m_ThisCalculatorsName + "_" + "Age_Years");		
        if(elemAgeYr.value == "-1") {
            strError += " - Age: Years is required\r";
            isError = true;
        }

        //check the age_months
        var elemAgeM = document.getElementById(m_ThisCalculatorsName + "_" + "Age_Months");
        if(elemAgeM.value == "-1") {
            strError += " - Age: Months is required\r";
            isError = true;
        }

        //check the height_feet
        var elemHeightFt = document.getElementById(m_ThisCalculatorsName + "_" + "Height_Feet");
        if(elemHeightFt.value == "") {
            strError += " - Height: Feet is required\r";
            isError = true;
        }
        else {
            if(!ChildBMICalc_IsNumeric(elemHeightFt.value)) {
                strError += " - Height: Feet is not a valid number\r";
                isError = true;
            }
        }

        //check the height_ inches
        var elemHeightIn = document.getElementById(m_ThisCalculatorsName + "_" + "Height_Inches");
        if(elemHeightIn.value == "") {
            elemHeightIn.value = "0";
        }
        else {
            if(!ChildBMICalc_IsNumeric(elemHeightIn.value)) {
                strError += " - Height: Inches is not a valid number\r";
                isError = true;
            }
            else {
                if(elemHeightIn.value > 11) {
                    strError += " - Height: Inches must be less than 12\r"
                }
            }
        }

        //check the weight
        var elemWeight = document.getElementById(m_ThisCalculatorsName + "_" + "Weight");
        if(elemWeight.value == "") {
            strError += " - Weight is required\r";
            isError = true;
        }
        else {
            if(!ChildBMICalc_IsNumeric(elemWeight.value)) {
                strError += " - Weight is not a valid number\r";
                isError = true;
            }
        }

        //if there was an error, display alert, and return to form.
        if(isError)
        {
            alert(strError);
            return false;
        }
        else 
        {
            return true;
        }		
    }

    function ChildBMICalc_IsNumeric(sText)
    {
        var rxNumber = new RegExp("^[\\d\\.]+$", "g");
        return (rxNumber.exec(sText) != null);
    }

    function ChildBMICalc_Calculate()
    {
        var MagicNumber = 703.0;
        //Answers order: (0)Gender, (1)Age:Years, (2)Age:Months, (3)Height:feet, (4)Height:Inches, (5)Weight
        Gender = m_Parameters[0];
        AgeInMonths = (eval(m_Parameters[1]) * 12) + eval(m_Parameters[2]);
        HeightInInches = (eval(m_Parameters[3]) * 12) + eval(m_Parameters[4]);
        Weight = eval(m_Parameters[5]);
	
        BMI = (Weight/(HeightInInches*HeightInInches)) * MagicNumber;
        
        //male percentile arrays
        /*
        Explanation: these are the first array elem of each array because the origional list is based on .5 yr increaments starting at 24, then 24.5, then 25.5 etc.
        i removed the first numbers and assume the data starts on 24 months, sliding the numbers by .5 down each
        14.73731947,
        18.16219473,
        19.33801062,
        */
        var arrayM5P = Array(14.71929257,14.68360841,14.64843329,14.61378626,14.57968578,14.54614966,14.51319492,14.48083795,14.44909329,14.41797561,14.38749811,14.35767293,14.32851119,14.30002256,14.27221761,14.24510202,14.21868433,14.19297011,14.16796472,14.14367089,14.12009269,14.09723246,14.07508966,14.05366443,14.03295533,14.01295984,13.99367445,13.97509464,13.95721572,13.94002947,13.92353116,13.90771281,13.89256678,13.87808525,13.86425959,13.85108308,13.83854804,13.82664746,13.81537489,13.8047237,13.79469004,13.78526882,13.77645627,13.76824936,13.76064574,13.75364373,13.7472423,13.74144099,13.73623987,13.73163946,13.72764072,13.72424433,13.72145289,13.71926775,13.71769094,13.71672458,13.71637124,13.71663233,13.71751078,13.71900887,13.72112886,13.72387293,13.72724315,13.7312415,13.73586983,13.7411299,13.74702309,13.753551 ,13.7607148,13.76851558,13.77695423,13.78603145,13.79574779,13.80610355,13.81709878,13.82873375,13.84100784,13.85392068,13.86747174,13.88166013,13.89648454,13.91194439,13.92803786,13.94476358,13.9621189,13.98010297,13.99871328,14.01794738,14.03780282,14.0582769,14.07936677,14.10106937,14.1233815,14.14629977,14.16982063,14.19394037,14.21865508,14.24396081,14.26985313,14.29632789,14.32338048,14.35100623,14.37920031,14.40795771,14.43727329,14.46714175,14.49755765,14.52851537,14.56000917,14.59203313,14.62458122,14.65764722,14.69122381,14.72530601,14.75988661,14.79495883,14.83051578,14.86655039,14.90305549,14.94002374,14.97744768,15.01531973,15.05363215,15.09237707,15.13154651,15.17113234,15.2111263,15.25152001,15.29230496,15.33347251,15.37501389,15.41692023,15.4591825,15.50179159,15.54473823,15.58801305,15.63160658,15.67550919,15.71971118,15.7642027,15.80897382,15.85401448,15.89931451,15.94486363,15.99065148,16.03666757,16.0829013,16.129342 ,16.17597888,16.22280106,16.26979755,16.31695728,16.3642691,16.41172173,16.45930384,16.50700399,16.55481067,16.60271228,16.65069714,16.69875348,16.74686947,16.79503318,16.84323264,16.89145577,16.93969043,16.98792443,17.03614547,17.08434122,17.13249925,17.18060709,17.22865219,17.27662259,17.32450423,17.37228509,17.41995236,17.46749315,17.51489451,17.56214342,17.60922679,17.65613146,17.70284417,17.74935161,17.79564039,17.84169701,17.8875079,17.9330594,17.97833773,18.02332903,18.06801933,18.11239453,18.15644042,18.20014256,18.24348662,18.28645727,18.32904183,18.37122369,18.41298696,18.45431794,18.49520062,18.53561932,18.57555819,18.61500111,18.65393178,18.69233437,18.73019025,18.7674838,18.80419732,18.84031318,18.87581348,18.91067999,18.9448942,18.97843726,19.0112887,19.04343134,19.07484425,19.10550722,19.12055111);
        var arrayM85P = Array(18.11954923,18.03668013,17.95700228,17.88047101,17.80704259,17.73667414,17.66932346,17.6049486 ,17.54350898,17.48496295,17.42926933,17.37638677,17.32627356,17.27888795,17.23418554,17.19212545,17.15266201,17.11575098,17.08134677,17.04940504,17.0198786 ,16.99272087,16.96788739,16.94533215,16.92501028,16.90687779,16.89089179,16.87701073,16.86519374,16.85540483,16.8476049 ,16.84175987,16.8378366 ,16.83580365,16.83563223,16.83729272,16.84075838,16.84600319,16.85300198,16.86173124,16.87216519,16.88428085,16.89805459,16.91346275,16.93048153,16.94908693,16.96925461,16.99095993,17.01417786,17.03888299,17.06504953,17.09265223,17.12166319,17.15205629,17.18380454,17.21688072,17.25125697,17.28690708,17.32380254,17.3619157 ,17.40121891,17.44168456,17.48328513,17.52599317,17.56978138,17.61462266,17.66048985,17.70735632,17.75519541,17.80398077,17.85368626,17.90428602,17.95575444,18.00806622,18.06119653,18.1151201 ,18.16981303,18.22525119,18.28141055,18.33826774,18.39579999,18.45398355,18.51279647,18.57221621,18.63222223,18.69279128,18.75390266,18.81553565,18.87766958,18.94028419,19.00335954,19.06687603,19.13081436,19.19515554,19.25988094,19.3249722 ,19.3904113 ,19.45618042,19.52226247,19.58864006,19.65529649,19.72221531,19.78938034,19.85677572,19.92438591,19.99219565,20.06019002,20.12835437,20.19667437,20.265136  ,20.33372554,20.40242956,20.4712365 ,20.54013114,20.60910189,20.6781365 ,20.74722303,20.81634983,20.88550554,20.95467909,21.02385969,21.09303687,21.1622004 ,21.23134038,21.30044717,21.36951141,21.43852405,21.5074763 ,21.57635964,21.64516586,21.71388701,21.78251541,21.85104367,21.91946467,21.98777156,22.05595776,22.12401698,22.19194317,22.25973057,22.32737368,22.39486727,22.46220636,22.52938625,22.5964025 ,22.66325092,22.7299276 ,22.79642886,22.86275131,22.92889179,22.99484741,23.06061552,23.12619375,23.19157996,23.25677226,23.32176902,23.38656886,23.45117065,23.5155735 ,23.57977678,23.6437801 ,23.70758332,23.77118654,23.83459013,23.89779468,23.96080104,24.02361032,24.08622386,24.14864327,24.21087038,24.2729073 ,24.33475639,24.39641931,24.4579009 ,24.51920324,24.58032971,24.64128395,24.70206989,24.76269168,24.82315378,24.88346091,24.94361805,25.00363048,25.06350375,25.1232437 ,25.18285645,25.24234842,25.30172632,25.36099716,25.42016826,25.47924723,25.538242  ,25.59716095,25.65601244,25.71480629,25.77354888,25.83225207,25.89092687,25.94958116,26.00822631,26.06687321,26.1255331 ,26.18421759,26.24293861,26.30170723,26.36053932,26.41944523,26.47843912,26.53753478,26.59674639,26.65608851,26.71557609,26.77522448,26.83505132,26.89506944,26.95529697,27.01575092,27.04606818);
        var arrayM95P = Array(19.27889813,19.16465965,19.05567423,18.9518675 ,18.85316529,18.75949359,18.67077841,18.58694589,18.50792131,18.43363072,18.3639996 ,18.29895323,18.23841666,18.1823144 ,18.13057244,18.08311311,18.03986198,18.00074262,17.96567903,17.9345935 ,17.90741007,17.88405183,17.86443983,17.84849622,17.8361423 ,17.82729891,17.8218865 ,17.81982523,17.82103559,17.82543578,17.83294744,17.84349028,17.85698505,17.87335318,17.89251642,17.91439894,17.93892524,17.96602144,17.99561523,18.02763543,18.06201396,18.09868317,18.13757754,18.17863327,18.22178824,18.26698191,18.31415529,18.36325085,18.41421242,18.46698511,18.52151524,18.57774996,18.63563816,18.69512904,18.75617288,18.81872078,18.88272474,18.948137  ,19.01491107,19.08300081,19.15236073,19.22294589,19.29471191,19.36761493,19.44161165,19.51665894,19.59271539,19.6697383 ,19.74768666,19.82651963,19.90619689,19.98667859,20.06792538,20.1498984 ,20.23255928,20.31587026,20.39979379,20.48429323,20.56933216,20.6548748 ,20.74088584,20.82733059,20.9141748 ,21.00138483,21.08892746,21.17677023,21.26488107,21.3532285 ,21.44178165,21.53051015,21.61938426,21.70837477,21.79745308,21.88659115,21.97576153,22.06493737,22.15409238,22.24320091,22.33223786,22.42117875,22.5099997 ,22.59867744,22.68718928,22.77551316,22.86362762,22.95151182,23.03914551,23.12650908,23.21358351,23.30035043,23.38679204,23.4728912 ,23.55863129,23.64399652,23.72897155,23.81354171,23.89769296,23.98141187,24.06468566,24.14750216,24.22984982,24.31171774,24.39309562,24.47397382,24.55434332,24.63419572,24.71352325,24.79231881,24.87057587,24.9482886 ,25.02545175,25.10206075,25.17811163,25.25360108,25.32852641,25.4028856 ,25.47667722,25.54990054,25.62255542,25.6946424 ,25.76616263,25.83711794,25.90751079,25.97734428,26.04662217,26.11534887,26.18352944,26.25116959,26.31827569,26.38485476,26.45091448,26.51646321,26.58150994,26.64606434,26.71013675,26.77373817,26.83688026,26.89957537,26.96183652,27.02367739,27.08511234,27.14615643,27.20682538,27.2671356 ,27.32710417,27.38674888,27.4460882 ,27.50514126,27.56392793,27.62246873,27.68078489,27.73889854,27.79683185,27.85460837,27.91225209,27.96978771,28.02724061,28.08463689,28.1420033 ,28.19936732,28.25675709,28.31420146,28.37172995,28.42937274,28.48716074,28.54512548,28.60329919,28.66171476,28.72040572,28.77940629,28.8387513 ,28.89847621,28.9586172 ,29.0192108 ,29.08029503,29.14190734,29.20408599,29.26687079,29.33030127,29.39441777,29.45926122,29.52487306,29.59129532,29.65857091,29.72674204,29.79585303,29.86594782,29.93707103,30.00926778,30.08258369,30.15706484,30.23275779,30.30970901,30.387967  ,30.46757924,30.54859414,30.58964285);
	
        //Female percentile arrays
        /*
        Explanation: these are the first array elem of each array because the origional list is based on .5 yr increaments starting at 24, then 24.5, then 25.5 etc.
        i removed the first numbers and assume the data starts on 24 months, sliding the numbers by .5 down each
        14.39787089,
        18.01820579,
        19.10623522,
        */
        var arrayF5P = Array(14.3801866,14.34527262,14.31096806,14.27727686,14.24420303,14.21174909,14.17991775,14.14871111,14.11813062,14.08817793,14.0588539,14.03015932,14.00209476,13.97466073,13.94785767,13.92168608,13.89614655,13.87123981,13.84696678,13.82332865,13.80032682,13.77796299,13.75623885,13.73515717,13.71472021,13.6949307,13.67579162,13.65730608,13.63947739,13.62230894,13.60580421,13.58996673,13.57480002,13.56030761,13.54649295,13.53335941,13.52091027,13.50914853,13.4980774,13.48769977,13.47801782,13.4690344,13.46075175,13.45317191,13.44629667,13.44012761,13.43466608,13.42991321,13.42587042,13.42253788,13.41991629,13.41800595,13.41680692,13.41631905,13.41654198,13.41747514,13.41911775,13.42146884,13.42452722,13.42829152,13.43276016,13.43793139,13.44380325,13.45037362,13.45764018,13.46560044,13.47425174,13.48359125,13.49361598,13.50432278,13.51570835,13.52776922,13.54050176,13.55390172,13.56796556,13.58268918,13.59806788,13.61409768,13.63077388,13.6480912,13.6660455,13.68463148,13.70384401,13.72367745,13.74412656,13.7651862,13.78684956,13.80911155,13.83196589,13.85540667,13.87942647,13.90402053,13.92918106,13.95490163,13.98117536,14.00799522,14.03535405,14.06324456,14.0916593,14.12059071,14.15003106,14.17997251,14.21040706,14.2413266,14.27272286,14.30458743,14.33691178,14.36968723,14.40290497,14.43655605,14.47063181,14.50512237,14.54001862,14.57531107,14.61099007,14.64704584,14.68346846,14.72024789,14.75737391,14.7948362,14.83262428,14.87072753,14.90913518,14.94783635,14.98681999,15.0260749,15.06558978,15.10535314,15.14535337,15.18557871,15.22601726,15.26665697,15.30748565,15.34849095,15.38966039,15.43098133,15.47244099,15.51402643,15.55572457,15.59752218,15.63940588,15.68136213,15.72337724,15.76543738,15.80752854,15.84963659,15.89174721,15.93384595,15.97591819,16.01794916,16.05992392,16.10182739,16.14364432,16.1853593,16.22695676,16.26842096,16.30973602,16.35088587,16.3918543,16.43262492,16.47318119,16.5135064,16.55358366,16.59339594,16.63292602,16.67215653,16.71106993,16.74964852,16.78787442,16.82572959,16.86319583,16.90025476,16.93688787,16.97307644,17.00880162,17.04404492,17.07878553,17.11300574,17.14668547,17.17980508,17.21234472,17.24428517,17.27560407,17.30628297,17.33630159,17.36563825,17.39427286,17.42218439,17.44935184,17.47575509,17.50136974,17.52617667,17.55015468,17.57328018,17.59553468,17.61689275,17.63733356,17.6568349,17.67537444,17.69292976,17.70947829,17.72499741,17.73946435,17.75285625,17.76515018,17.77632308,17.78635182,17.79521318,17.80288385,17.80934044,17.81455755,17.81851675,17.82119134,17.82255737,17.8225906,17.82126653,17.82009046);
        var arrayF85P = Array(17.97371413,17.88748812,17.80489051,17.72586396,17.65035137,17.57829774,17.50964839,17.44434994,17.38235043,17.32359846,17.26804436,17.21563951,17.16633643,17.12008872,17.07685104,17.03657894,16.99922885,16.96475788,16.93312378,16.90428477,16.87819947,16.85482681,16.83412628,16.81605638,16.80057671,16.78764654,16.77722512,16.76927159,16.76374505,16.76060449,16.75980884,16.76131695,16.76508763,16.77107966,16.77925184,16.78956298,16.80197195,16.81643792,16.83291965,16.85137625,16.87176785,16.89405345,16.91819285,16.94414613,16.97187362,17.00133593,17.03249399,17.065309,17.09974172,17.13575468,17.17330968,17.21236911,17.25289572,17.29485256,17.33820304,17.38291092,17.42894029,17.4762556,17.52482162,17.57460349,17.6255667,17.67767708,17.7309008,17.78520438,17.8405547,17.89691898,17.95426475,18.01255992,18.07177271,18.13187166,18.19282565,18.25460388,18.31717594,18.38051241,18.44458291,18.50935798,18.57480931,18.6409074,18.70762408,18.77493214,18.84280276,18.91120897,18.98012366,19.04952063,19.11937316,19.18965453,19.26034062,19.33140487,19.4028226,19.47456869,19.54662051,19.6189515,19.69153965,19.7643612,19.83739314,19.91061278,19.98399779,20.05752615,20.13117619,20.20492657,20.27875629,20.35264468,20.42657139,20.50051644,20.57446015,20.64838321,20.72226661,20.79609169,20.86984014,20.94349396,21.01703489,21.09044653,21.16371155,21.2368133,21.30973548,21.38246211,21.45497756,21.52726655,21.5993141,21.6711056,21.74262677,21.81386368,21.88480271,21.95543061,22.02573445,22.09570166,22.16531999,22.23457754,22.30346276,22.37196443,22.44007167,22.50777397,22.57506113,22.6419233,22.70835101,22.77433508,22.83986672,22.90493747,22.96953922,23.03366421,23.09730502,23.16045458,23.2231062,23.28525349,23.34689045,23.40801143,23.46861112,23.52868458,23.5882272,23.64723476,23.70570337,23.76362952,23.82101004,23.87784214,23.93412338,23.98985168,24.04502533,24.09964299,24.15370368,24.20720678,24.26015204,24.3125396,24.36436993,24.41564391,24.46636278,24.51652812,24.56614194,24.61520657,24.66372475,24.71169957,24.75913451,24.80603342,24.85240053,24.89824041,24.94355805,24.98835785,25.03264836,25.07643282,25.11971866,25.16251271,25.20482218,25.24665348,25.28801794,25.32892108,25.3693713,25.40937929,25.44895346,25.48810377,25.52684029,25.56517184,25.603114,25.64067435,25.67786376,25.714697,25.75118107,25.7873338,25.82316611,25.85869115,25.89392241,25.92887369,25.96355908,25.99799301,26.03219019,26.06616563,26.09993465,26.13351285,26.16691611,26.20016061,26.23326279,26.26623937,26.29911039,26.33188509,26.36458581,26.39723077,26.42983873,26.4624291,26.47871966);
        var arrayF95P = Array(19.05823845,18.9659499,18.87853388,18.79590999,18.71799839,18.64471845,18.5759903,18.51173402,18.45186978,18.39631848,18.34500099,18.29783876,18.25475381,18.21566879,18.18050711,18.14919304,18.12165176,18.09780945,18.07759336,18.06093184,18.04775438,18.03799161,18.03157513,18.02843822,18.02851473,18.03173977,18.03804946,18.04738091,18.05967216,18.0748621,18.09289045,18.11369768,18.13722499,18.16341422,18.19220786,18.22354893,18.25738105,18.29364826,18.33229525,18.37326713,18.41650918,18.46196754,18.50958858,18.55931907,18.6111062,18.6648976,18.72064127,18.77828567,18.83777954,18.89907229,18.96211354,19.02685341,19.09324243,19.16123158,19.23077228,19.30181639,19.37431624,19.44822461,19.52349477,19.60008044,19.67793583,19.75701564,19.83727506,19.91866977,20.00115598,20.08469037,20.16923016,20.25473307,20.34115737,20.42846182,20.51660573,20.60554896,20.69525186,20.78567525,20.87678068,20.96853014,21.06088607,21.15381165,21.24727049,21.34122666,21.43564505,21.5304909,21.62573005,21.72132885,21.8172543,21.91347402,22.00995586,22.10666864,22.20358151,22.30066429,22.39788709,22.49522108,22.59263755,22.69010855,22.78760665,22.88510501,22.98257733,23.07999788,23.17734149,23.27458358,23.3717001,23.46866758,23.56546313,23.6620644,23.7584496,23.85459754,23.95048756,24.04609957,24.14141407,24.23641208,24.33107526,24.4253857,24.51932616,24.61287993,24.70603086,24.79876336,24.89106241,24.98291353,25.07430281,25.16521691,25.25564304,25.34556897,25.43498301,25.52387405,25.61223153,25.70004544,25.78730634,25.87400532,25.96013405,26.04568474,26.13065016,26.21502362,26.298799,26.38197072,26.46453376,26.54648363,26.62781643,26.70852876,26.78861781,26.8680813,26.94691749,27.02512521,27.10270382,27.17965324,27.25597392,27.33166687,27.40673363,27.4811763,27.55499753,27.62820049,27.70078892,27.77276709,27.84413981,27.91491246,27.98509093,28.05468167,28.12369169,28.19212851,28.26000023,28.32731547,28.3940834,28.46031375,28.52601678,28.59120331,28.6558847,28.72007286,28.78378025,28.84701989,28.90980533,28.97215071,29.03407069,29.0955805,29.15669594,29.21743336,29.27780966,29.33784232,29.39754939,29.45694948,29.51606178,29.57490604,29.63350259,29.69187236,29.75003682,29.80801808,29.8658388,29.92352223,29.98109225,30.03857329,30.09599042,30.15336926,30.21073618,30.26811799,30.32554216,30.38303689,30.44063073,30.49835324,30.55623433,30.61430463,30.67259539,30.73113849,30.78996648,30.84911253,30.90861047,30.96849476,31.02880054,31.08956357,31.1508203,31.21260782,31.27496389,31.33792691,31.40153631,31.46583097,31.53085181,31.59663995,31.66323724,31.73068625,31.76474311);
	
        //since the lookup tables start with 24 months as the 0 element, ajust the AgeInMonths by 24 months
        var i = AgeInMonths - 24;		

        //now there should be 3 comparisons to see where the user fits in the table for each gender
        if("m" == Gender)
        {
            if(BMI < arrayM5P[i])
                Category = "Underweight";
            else if(BMI < arrayM85P[i])
                Category = "Healthy";
            else if(BMI < arrayM95P[i])
                Category = "AtRisk";
            else if(BMI >= arrayM95P[i])
                Category = "Overweight";
            LowerIdealBMI = arrayM5P[i];
            UpperIdealBMI = arrayM85P[i];
        }
        else if("f" == Gender)
        {	
            if(BMI < arrayF5P[i])
                Category = "Underweight";
            else if(BMI < arrayF85P[i])
                Category = "Healthy";
            else if(BMI < arrayF95P[i])
                Category = "AtRisk";
            else if(BMI >= arrayF95P[i])
                Category = "Overweight";
            LowerIdealBMI = arrayF5P[i];
            UpperIdealBMI = arrayF85P[i];
        }
        
        ChildBMICalc_GetPercentile(BMI, AgeInMonths, Gender);

    }

    function ChildBMICalc_GetPercentile(currentBMI, currentAgeInMonths, currentGender) {
        var lVal;
        var mVal;
        var sVal;
        var zScore;
        var myPercentile;
        var myPercentileRounded;

        var jsonValues = [
            { "Sex": "m", "Agemos": "24", "L": "-2.01118107", "M": "16.575027675", "S": "0.080592465" },
            { "Sex": "m", "Agemos": "24.5", "L": "-1.982373595", "M": "16.547774867", "S": "0.0801274288" },
            { "Sex": "m", "Agemos": "25.5", "L": "-1.924100169", "M": "16.494427632", "S": "0.0792339937" },
            { "Sex": "m", "Agemos": "26.5", "L": "-1.86549793", "M": "16.442595522", "S": "0.0783893561" },
            { "Sex": "m", "Agemos": "27.5", "L": "-1.807261899", "M": "16.392243398", "S": "0.0775935012" },
            { "Sex": "m", "Agemos": "28.5", "L": "-1.750118905", "M": "16.343336543", "S": "0.0768464622" },
            { "Sex": "m", "Agemos": "29.5", "L": "-1.69481584", "M": "16.295840971", "S": "0.0761483079" },
            { "Sex": "m", "Agemos": "30.5", "L": "-1.642106779", "M": "16.249723714", "S": "0.0754991255" },
            { "Sex": "m", "Agemos": "31.5", "L": "-1.592744414", "M": "16.204952678", "S": "0.0748989935" },
            { "Sex": "m", "Agemos": "32.5", "L": "-1.547442391", "M": "16.161498714", "S": "0.0743479966" },
            { "Sex": "m", "Agemos": "33.5", "L": "-1.506902601", "M": "16.119332582", "S": "0.0738461386" },
            { "Sex": "m", "Agemos": "34.5", "L": "-1.471770047", "M": "16.078427579", "S": "0.0733933698" },
            { "Sex": "m", "Agemos": "35.5", "L": "-1.442628957", "M": "16.038758958", "S": "0.0729895508" },
            { "Sex": "m", "Agemos": "36.5", "L": "-1.419991255", "M": "16.000304012", "S": "0.0726344323" },
            { "Sex": "m", "Agemos": "37.5", "L": "-1.404277619", "M": "15.963042771", "S": "0.072327649" },
            { "Sex": "m", "Agemos": "38.5", "L": "-1.39586317", "M": "15.926954175", "S": "0.0720686401" },
            { "Sex": "m", "Agemos": "39.5", "L": "-1.394935252", "M": "15.892025816", "S": "0.0718568052" },
            { "Sex": "m", "Agemos": "40.5", "L": "-1.401671596", "M": "15.858240929", "S": "0.071691278" },
            { "Sex": "m", "Agemos": "41.5", "L": "-1.416100312", "M": "15.825588223", "S": "0.0715710933" },
            { "Sex": "m", "Agemos": "42.5", "L": "-1.438164899", "M": "15.794057282", "S": "0.0714951131" },
            { "Sex": "m", "Agemos": "43.5", "L": "-1.467669032", "M": "15.763642549", "S": "0.0714621062" },
            { "Sex": "m", "Agemos": "44.5", "L": "-1.504376347", "M": "15.734336684", "S": "0.0714706462" },
            { "Sex": "m", "Agemos": "45.5", "L": "-1.547942838", "M": "15.706135657", "S": "0.0715192177" },
            { "Sex": "m", "Agemos": "46.5", "L": "-1.597896397", "M": "15.679040623", "S": "0.0716062769" },
            { "Sex": "m", "Agemos": "47.5", "L": "-1.653732283", "M": "15.653051916", "S": "0.071730167" },
            { "Sex": "m", "Agemos": "48.5", "L": "-1.714869347", "M": "15.628172692", "S": "0.0718892136" },
            { "Sex": "m", "Agemos": "49.5", "L": "-1.780673181", "M": "15.604407997", "S": "0.0720817373" },
            { "Sex": "m", "Agemos": "50.5", "L": "-1.850468473", "M": "15.58176458", "S": "0.0723060813" },
            { "Sex": "m", "Agemos": "51.5", "L": "-1.923551865", "M": "15.560250666", "S": "0.0725606369" },
            { "Sex": "m", "Agemos": "52.5", "L": "-1.999220429", "M": "15.539874597", "S": "0.0728438397" },
            { "Sex": "m", "Agemos": "53.5", "L": "-2.076707178", "M": "15.520649927", "S": "0.0731543235" },
            { "Sex": "m", "Agemos": "54.5", "L": "-2.155348017", "M": "15.502584267", "S": "0.0734906668" },
            { "Sex": "m", "Agemos": "55.5", "L": "-2.234438552", "M": "15.485689732", "S": "0.0738516716" },
            { "Sex": "m", "Agemos": "56.5", "L": "-2.313321723", "M": "15.469977177", "S": "0.0742362346" },
            { "Sex": "m", "Agemos": "57.5", "L": "-2.391381273", "M": "15.455456916", "S": "0.0746433738" },
            { "Sex": "m", "Agemos": "58.5", "L": "-2.468032491", "M": "15.442139608", "S": "0.0750722636" },
            { "Sex": "m", "Agemos": "59.5", "L": "-2.542781541", "M": "15.430032072", "S": "0.0755221037" },
            { "Sex": "m", "Agemos": "60.5", "L": "-2.61516595", "M": "15.419141631", "S": "0.0759922501" },
            { "Sex": "m", "Agemos": "61.5", "L": "-2.684789516", "M": "15.409473561", "S": "0.0764821284" },
            { "Sex": "m", "Agemos": "62.5", "L": "-2.751316949", "M": "15.401031388", "S": "0.0769912324" },
            { "Sex": "m", "Agemos": "63.5", "L": "-2.81445945", "M": "15.393817852", "S": "0.0775191487" },
            { "Sex": "m", "Agemos": "64.5", "L": "-2.87402476", "M": "15.387830936", "S": "0.0780653898" },
            { "Sex": "m", "Agemos": "65.5", "L": "-2.92984048", "M": "15.383069448", "S": "0.0786295919" },
            { "Sex": "m", "Agemos": "66.5", "L": "-2.981796828", "M": "15.37952958", "S": "0.0792113694" },
            { "Sex": "m", "Agemos": "67.5", "L": "-3.029831343", "M": "15.37720582", "S": "0.0798103341" },
            { "Sex": "m", "Agemos": "68.5", "L": "-3.073924224", "M": "15.376091068", "S": "0.0804260861" },
            { "Sex": "m", "Agemos": "69.5", "L": "-3.114093476", "M": "15.376176765", "S": "0.0810582059" },
            { "Sex": "m", "Agemos": "70.5", "L": "-3.15039004", "M": "15.37745304", "S": "0.0817062489" },
            { "Sex": "m", "Agemos": "71.5", "L": "-3.182893018", "M": "15.379908859", "S": "0.0823697413" },
            { "Sex": "m", "Agemos": "72.5", "L": "-3.21170511", "M": "15.383532169", "S": "0.0830481778" },
            { "Sex": "m", "Agemos": "73.5", "L": "-3.23694834", "M": "15.388310046", "S": "0.0837410207" },
            { "Sex": "m", "Agemos": "74.5", "L": "-3.25876011", "M": "15.39422883", "S": "0.0844476998" },
            { "Sex": "m", "Agemos": "75.5", "L": "-3.277281546", "M": "15.40127496", "S": "0.0851676514" },
            { "Sex": "m", "Agemos": "76.5", "L": "-3.292683774", "M": "15.40943252", "S": "0.0859001836" },
            { "Sex": "m", "Agemos": "77.5", "L": "-3.305124073", "M": "15.418686911", "S": "0.0866446671" },
            { "Sex": "m", "Agemos": "78.5", "L": "-3.314768951", "M": "15.429022732", "S": "0.0874004212" },
            { "Sex": "m", "Agemos": "79.5", "L": "-3.321785992", "M": "15.440424387", "S": "0.0881667444" },
            { "Sex": "m", "Agemos": "80.5", "L": "-3.326345795", "M": "15.452875806", "S": "0.088942897" },
            { "Sex": "m", "Agemos": "81.5", "L": "-3.328602731", "M": "15.466362178", "S": "0.0897282019" },
            { "Sex": "m", "Agemos": "82.5", "L": "-3.328725277", "M": "15.480867041", "S": "0.0905218748" },
            { "Sex": "m", "Agemos": "83.5", "L": "-3.32687018", "M": "15.496374654", "S": "0.0913231621" },
            { "Sex": "m", "Agemos": "84.5", "L": "-3.323188896", "M": "15.512869363", "S": "0.0921313054" },
            { "Sex": "m", "Agemos": "85.5", "L": "-3.317827016", "M": "15.530335632", "S": "0.0929455443" },
            { "Sex": "m", "Agemos": "86.5", "L": "-3.310923871", "M": "15.548758065", "S": "0.0937651184" },
            { "Sex": "m", "Agemos": "87.5", "L": "-3.302612272", "M": "15.568121426", "S": "0.0945892702" },
            { "Sex": "m", "Agemos": "88.5", "L": "-3.293018361", "M": "15.588410651", "S": "0.0954172465" },
            { "Sex": "m", "Agemos": "89.5", "L": "-3.282260813", "M": "15.60961101", "S": "0.0962483005" },
            { "Sex": "m", "Agemos": "90.5", "L": "-3.270454609", "M": "15.63170735", "S": "0.0970816941" },
            { "Sex": "m", "Agemos": "91.5", "L": "-3.257703616", "M": "15.654685628", "S": "0.0979166976" },
            { "Sex": "m", "Agemos": "92.5", "L": "-3.244108214", "M": "15.678531387", "S": "0.0987525931" },
            { "Sex": "m", "Agemos": "93.5", "L": "-3.229761713", "M": "15.703230518", "S": "0.0995886749" },
            { "Sex": "m", "Agemos": "94.5", "L": "-3.214751287", "M": "15.728769113", "S": "0.1004242507" },
            { "Sex": "m", "Agemos": "95.5", "L": "-3.199158184", "M": "15.755133465", "S": "0.1012586429" },
            { "Sex": "m", "Agemos": "96.5", "L": "-3.18305795", "M": "15.782310065", "S": "0.1020911894" },
            { "Sex": "m", "Agemos": "97.5", "L": "-3.166520664", "M": "15.810285603", "S": "0.1029212448" },
            { "Sex": "m", "Agemos": "98.5", "L": "-3.1496103", "M": "15.839047084", "S": "0.1037481885" },
            { "Sex": "m", "Agemos": "99.5", "L": "-3.132389637", "M": "15.868581229", "S": "0.1045713862" },
            { "Sex": "m", "Agemos": "100.5", "L": "-3.114911153", "M": "15.898875618", "S": "0.1053902685" },
            { "Sex": "m", "Agemos": "101.5", "L": "-3.097226399", "M": "15.929917651", "S": "0.1062042575" },
            { "Sex": "m", "Agemos": "102.5", "L": "-3.079383079", "M": "15.961694805", "S": "0.1070127883" },
            { "Sex": "m", "Agemos": "103.5", "L": "-3.061423765", "M": "15.994194894", "S": "0.1078153274" },
            { "Sex": "m", "Agemos": "104.5", "L": "-3.043386071", "M": "16.027406071", "S": "0.1086113736" },
            { "Sex": "m", "Agemos": "105.5", "L": "-3.025310003", "M": "16.061315897", "S": "0.1094003876" },
            { "Sex": "m", "Agemos": "106.5", "L": "-3.007225737", "M": "16.095912922", "S": "0.1101819146" },
            { "Sex": "m", "Agemos": "107.5", "L": "-2.989164598", "M": "16.131185315", "S": "0.1109554781" },
            { "Sex": "m", "Agemos": "108.5", "L": "-2.971148225", "M": "16.167122344", "S": "0.1117206908" },
            { "Sex": "m", "Agemos": "109.5", "L": "-2.953208047", "M": "16.203711677", "S": "0.1124770587" },
            { "Sex": "m", "Agemos": "110.5", "L": "-2.935363951", "M": "16.240942388", "S": "0.1132241995" },
            { "Sex": "m", "Agemos": "111.5", "L": "-2.917635157", "M": "16.278803458", "S": "0.1139617339" },
            { "Sex": "m", "Agemos": "112.5", "L": "-2.900039803", "M": "16.317283847", "S": "0.1146892914" },
            { "Sex": "m", "Agemos": "113.5", "L": "-2.882593796", "M": "16.356372672", "S": "0.1154065227" },
            { "Sex": "m", "Agemos": "114.5", "L": "-2.865311266", "M": "16.396059161", "S": "0.1161130971" },
            { "Sex": "m", "Agemos": "115.5", "L": "-2.848204697", "M": "16.436332645", "S": "0.1168087018" },
            { "Sex": "m", "Agemos": "116.5", "L": "-2.831285052", "M": "16.477182556", "S": "0.1174930418" },
            { "Sex": "m", "Agemos": "117.5", "L": "-2.81456189", "M": "16.518598425", "S": "0.1181658396" },
            { "Sex": "m", "Agemos": "118.5", "L": "-2.79804347", "M": "16.560569873", "S": "0.1188268351" },
            { "Sex": "m", "Agemos": "119.5", "L": "-2.781736856", "M": "16.603086612", "S": "0.1194757852" },
            { "Sex": "m", "Agemos": "120.5", "L": "-2.765648008", "M": "16.646138439", "S": "0.1201124636" },
            { "Sex": "m", "Agemos": "121.5", "L": "-2.749782197", "M": "16.689715178", "S": "0.1207366562" },
            { "Sex": "m", "Agemos": "122.5", "L": "-2.734142443", "M": "16.733806953", "S": "0.1213481813" },
            { "Sex": "m", "Agemos": "123.5", "L": "-2.718732873", "M": "16.778403632", "S": "0.121946849" },
            { "Sex": "m", "Agemos": "124.5", "L": "-2.703555506", "M": "16.82349538", "S": "0.1225325012" },
            { "Sex": "m", "Agemos": "125.5", "L": "-2.688611957", "M": "16.869072375", "S": "0.1231049908" },
            { "Sex": "m", "Agemos": "126.5", "L": "-2.673903164", "M": "16.915124866", "S": "0.1236641859" },
            { "Sex": "m", "Agemos": "127.5", "L": "-2.659429443", "M": "16.961643168", "S": "0.1242099694" },
            { "Sex": "m", "Agemos": "128.5", "L": "-2.645190534", "M": "17.00861766", "S": "0.1247422387" },
            { "Sex": "m", "Agemos": "129.5", "L": "-2.631185649", "M": "17.056038787", "S": "0.1252609054" },
            { "Sex": "m", "Agemos": "130.5", "L": "-2.617413511", "M": "17.103897052", "S": "0.125765895" },
            { "Sex": "m", "Agemos": "131.5", "L": "-2.603872392", "M": "17.152183022", "S": "0.1262571467" },
            { "Sex": "m", "Agemos": "132.5", "L": "-2.590560148", "M": "17.200887318", "S": "0.1267346133" },
            { "Sex": "m", "Agemos": "133.5", "L": "-2.577474253", "M": "17.250000623", "S": "0.1271982604" },
            { "Sex": "m", "Agemos": "134.5", "L": "-2.564611831", "M": "17.299513673", "S": "0.1276480666" },
            { "Sex": "m", "Agemos": "135.5", "L": "-2.551969684", "M": "17.349417258", "S": "0.128084023" },
            { "Sex": "m", "Agemos": "136.5", "L": "-2.539539972", "M": "17.399703081", "S": "0.1285061919" },
            { "Sex": "m", "Agemos": "137.5", "L": "-2.527325681", "M": "17.450360715", "S": "0.1289144974" },
            { "Sex": "m", "Agemos": "138.5", "L": "-2.515320235", "M": "17.501381606", "S": "0.1293090012" },
            { "Sex": "m", "Agemos": "139.5", "L": "-2.503519447", "M": "17.552756739", "S": "0.1296897408" },
            { "Sex": "m", "Agemos": "140.5", "L": "-2.491918934", "M": "17.604477144", "S": "0.1300567649" },
            { "Sex": "m", "Agemos": "141.5", "L": "-2.480514136", "M": "17.656533895", "S": "0.1304101325" },
            { "Sex": "m", "Agemos": "142.5", "L": "-2.469300331", "M": "17.708918107", "S": "0.1307499132" },
            { "Sex": "m", "Agemos": "143.5", "L": "-2.458272656", "M": "17.761620938", "S": "0.1310761867" },
            { "Sex": "m", "Agemos": "144.5", "L": "-2.447426113", "M": "17.814633586", "S": "0.1313890423" },
            { "Sex": "m", "Agemos": "145.5", "L": "-2.436755595", "M": "17.867947289", "S": "0.1316885791" },
            { "Sex": "m", "Agemos": "146.5", "L": "-2.426255887", "M": "17.92155332", "S": "0.1319749052" },
            { "Sex": "m", "Agemos": "147.5", "L": "-2.415921689", "M": "17.975442992", "S": "0.1322481377" },
            { "Sex": "m", "Agemos": "148.5", "L": "-2.405747619", "M": "18.029607653", "S": "0.1325084026" },
            { "Sex": "m", "Agemos": "149.5", "L": "-2.395728233", "M": "18.084038684", "S": "0.1327558343" },
            { "Sex": "m", "Agemos": "150.5", "L": "-2.385858029", "M": "18.138727501", "S": "0.1329905752" },
            { "Sex": "m", "Agemos": "151.5", "L": "-2.376131459", "M": "18.193665552", "S": "0.133212776" },
            { "Sex": "m", "Agemos": "152.5", "L": "-2.366542942", "M": "18.248844314", "S": "0.1334225948" },
            { "Sex": "m", "Agemos": "153.5", "L": "-2.357086871", "M": "18.304255296", "S": "0.1336201973" },
            { "Sex": "m", "Agemos": "154.5", "L": "-2.347757625", "M": "18.359890034", "S": "0.1338057563" },
            { "Sex": "m", "Agemos": "155.5", "L": "-2.338549576", "M": "18.415740092", "S": "0.1339794518" },
            { "Sex": "m", "Agemos": "156.5", "L": "-2.3294571", "M": "18.471797059", "S": "0.1341414703" },
            { "Sex": "m", "Agemos": "157.5", "L": "-2.320474586", "M": "18.528052549", "S": "0.1342920051" },
            { "Sex": "m", "Agemos": "158.5", "L": "-2.311596446", "M": "18.584498199", "S": "0.1344312555" },
            { "Sex": "m", "Agemos": "159.5", "L": "-2.302817124", "M": "18.641125665", "S": "0.134559427" },
            { "Sex": "m", "Agemos": "160.5", "L": "-2.294131107", "M": "18.697926627", "S": "0.1346767311" },
            { "Sex": "m", "Agemos": "161.5", "L": "-2.285532933", "M": "18.754892781", "S": "0.1347833849" },
            { "Sex": "m", "Agemos": "162.5", "L": "-2.277017201", "M": "18.812015839", "S": "0.1348796107" },
            { "Sex": "m", "Agemos": "163.5", "L": "-2.268578584", "M": "18.869287528", "S": "0.1349656365" },
            { "Sex": "m", "Agemos": "164.5", "L": "-2.260211837", "M": "18.92669959", "S": "0.1350416951" },
            { "Sex": "m", "Agemos": "165.5", "L": "-2.251911809", "M": "18.984243775", "S": "0.1351080243" },
            { "Sex": "m", "Agemos": "166.5", "L": "-2.243673453", "M": "19.041911845", "S": "0.1351648666" },
            { "Sex": "m", "Agemos": "167.5", "L": "-2.235491842", "M": "19.099695568", "S": "0.1352124688" },
            { "Sex": "m", "Agemos": "168.5", "L": "-2.227362173", "M": "19.157586716", "S": "0.1352510825" },
            { "Sex": "m", "Agemos": "169.5", "L": "-2.21927979", "M": "19.215577065", "S": "0.1352809633" },
            { "Sex": "m", "Agemos": "170.5", "L": "-2.211240187", "M": "19.27365839", "S": "0.1353023707" },
            { "Sex": "m", "Agemos": "171.5", "L": "-2.203239029", "M": "19.331822466", "S": "0.1353155684" },
            { "Sex": "m", "Agemos": "172.5", "L": "-2.195272161", "M": "19.390061061", "S": "0.1353208237" },
            { "Sex": "m", "Agemos": "173.5", "L": "-2.187335625", "M": "19.448365938", "S": "0.1353184074" },
            { "Sex": "m", "Agemos": "174.5", "L": "-2.179425674", "M": "19.506728848", "S": "0.1353085942" },
            { "Sex": "m", "Agemos": "175.5", "L": "-2.171538789", "M": "19.565141532", "S": "0.1352916617" },
            { "Sex": "m", "Agemos": "176.5", "L": "-2.163671689", "M": "19.623595714", "S": "0.1352678911" },
            { "Sex": "m", "Agemos": "177.5", "L": "-2.155821357", "M": "19.682083101", "S": "0.1352375667" },
            { "Sex": "m", "Agemos": "178.5", "L": "-2.147985046", "M": "19.740595376", "S": "0.1352009759" },
            { "Sex": "m", "Agemos": "179.5", "L": "-2.140160305", "M": "19.799124201", "S": "0.1351584088" },
            { "Sex": "m", "Agemos": "180.5", "L": "-2.132344989", "M": "19.857661209", "S": "0.1351101588" },
            { "Sex": "m", "Agemos": "181.5", "L": "-2.124537282", "M": "19.916198004", "S": "0.1350565219" },
            { "Sex": "m", "Agemos": "182.5", "L": "-2.116735712", "M": "19.974726154", "S": "0.1349977968" },
            { "Sex": "m", "Agemos": "183.5", "L": "-2.108939167", "M": "20.033237194", "S": "0.134934285" },
            { "Sex": "m", "Agemos": "184.5", "L": "-2.10114692", "M": "20.091722615", "S": "0.1348662908" },
            { "Sex": "m", "Agemos": "185.5", "L": "-2.093358637", "M": "20.15017387", "S": "0.1347941208" },
            { "Sex": "m", "Agemos": "186.5", "L": "-2.085574403", "M": "20.208582361", "S": "0.1347180845" },
            { "Sex": "m", "Agemos": "187.5", "L": "-2.077794735", "M": "20.266939444", "S": "0.1346384938" },
            { "Sex": "m", "Agemos": "188.5", "L": "-2.070020599", "M": "20.325236424", "S": "0.1345556632" },
            { "Sex": "m", "Agemos": "189.5", "L": "-2.062253431", "M": "20.383464548", "S": "0.1344699098" },
            { "Sex": "m", "Agemos": "190.5", "L": "-2.054495145", "M": "20.441615008", "S": "0.1343815533" },
            { "Sex": "m", "Agemos": "191.5", "L": "-2.046748156", "M": "20.499678935", "S": "0.1342909159" },
            { "Sex": "m", "Agemos": "192.5", "L": "-2.039015385", "M": "20.557647399", "S": "0.1341983225" },
            { "Sex": "m", "Agemos": "193.5", "L": "-2.031300282", "M": "20.615511404", "S": "0.1341041006" },
            { "Sex": "m", "Agemos": "194.5", "L": "-2.023606828", "M": "20.673261889", "S": "0.1340085806" },
            { "Sex": "m", "Agemos": "195.5", "L": "-2.015942013", "M": "20.730889051", "S": "0.1339120657" },
            { "Sex": "m", "Agemos": "196.5", "L": "-2.008305745", "M": "20.788385102", "S": "0.1338149542" },
            { "Sex": "m", "Agemos": "197.5", "L": "-2.000706389", "M": "20.845740029", "S": "0.1337175518" },
            { "Sex": "m", "Agemos": "198.5", "L": "-1.993150137", "M": "20.902944494", "S": "0.1336202002" },
            { "Sex": "m", "Agemos": "199.5", "L": "-1.985643741", "M": "20.959989088", "S": "0.1335232441" },
            { "Sex": "m", "Agemos": "200.5", "L": "-1.97819451", "M": "21.01686433", "S": "0.1334270316" },
            { "Sex": "m", "Agemos": "201.5", "L": "-1.970810308", "M": "21.073560674", "S": "0.1333319137" },
            { "Sex": "m", "Agemos": "202.5", "L": "-1.96349954", "M": "21.130068501", "S": "0.1332382449" },
            { "Sex": "m", "Agemos": "203.5", "L": "-1.956271141", "M": "21.186378131", "S": "0.1331463832" },
            { "Sex": "m", "Agemos": "204.5", "L": "-1.949134561", "M": "21.242479819", "S": "0.1330566901" },
            { "Sex": "m", "Agemos": "205.5", "L": "-1.942099744", "M": "21.298363759", "S": "0.1329695305" },
            { "Sex": "m", "Agemos": "206.5", "L": "-1.935177101", "M": "21.354020094", "S": "0.1328852735" },
            { "Sex": "m", "Agemos": "207.5", "L": "-1.92837748", "M": "21.409438911", "S": "0.1328042916" },
            { "Sex": "m", "Agemos": "208.5", "L": "-1.921712136", "M": "21.464610257", "S": "0.1327269615" },
            { "Sex": "m", "Agemos": "209.5", "L": "-1.915192685", "M": "21.519524136", "S": "0.1326536641" },
            { "Sex": "m", "Agemos": "210.5", "L": "-1.908831065", "M": "21.574170525", "S": "0.1325847841" },
            { "Sex": "m", "Agemos": "211.5", "L": "-1.902639482", "M": "21.628539373", "S": "0.1325207109" },
            { "Sex": "m", "Agemos": "212.5", "L": "-1.896630358", "M": "21.682620618", "S": "0.1324618378" },
            { "Sex": "m", "Agemos": "213.5", "L": "-1.890816268", "M": "21.736404191", "S": "0.1324085629" },
            { "Sex": "m", "Agemos": "214.5", "L": "-1.885209876", "M": "21.789880029", "S": "0.1323612888" },
            { "Sex": "m", "Agemos": "215.5", "L": "-1.879823505", "M": "21.843038191", "S": "0.1323204265" },
            { "Sex": "m", "Agemos": "216.5", "L": "-1.874670324", "M": "21.895868501", "S": "0.1322863818" },
            { "Sex": "m", "Agemos": "217.5", "L": "-1.869760299", "M": "21.948361684", "S": "0.1322595999" },
            { "Sex": "m", "Agemos": "218.5", "L": "-1.865113245", "M": "22.00050569", "S": "0.1322404176" },
            { "Sex": "m", "Agemos": "219.5", "L": "-1.860734944", "M": "22.052292423", "S": "0.1322293301" },
            { "Sex": "m", "Agemos": "220.5", "L": "-1.85663384", "M": "22.103713048", "S": "0.132226801" },
            { "Sex": "m", "Agemos": "221.5", "L": "-1.852827186", "M": "22.154756029", "S": "0.1322332005" },
            { "Sex": "m", "Agemos": "222.5", "L": "-1.849323204", "M": "22.205412485", "S": "0.1322489931" },
            { "Sex": "m", "Agemos": "223.5", "L": "-1.846131607", "M": "22.255673", "S": "0.1322746254" },
            { "Sex": "m", "Agemos": "224.5", "L": "-1.843261294", "M": "22.305528306", "S": "0.132310549" },
            { "Sex": "m", "Agemos": "225.5", "L": "-1.840720248", "M": "22.354969299", "S": "0.1323572208" },
            { "Sex": "m", "Agemos": "226.5", "L": "-1.83851544", "M": "22.403987057", "S": "0.132415103" },
            { "Sex": "m", "Agemos": "227.5", "L": "-1.83665586", "M": "22.452571818", "S": "0.132484631" },
            { "Sex": "m", "Agemos": "228.5", "L": "-1.835138046", "M": "22.500717781", "S": "0.1325663592" },
            { "Sex": "m", "Agemos": "229.5", "L": "-1.833972004", "M": "22.548414372", "S": "0.132660699" },
            { "Sex": "m", "Agemos": "230.5", "L": "-1.833157751", "M": "22.595654215", "S": "0.1327681527" },
            { "Sex": "m", "Agemos": "231.5", "L": "-1.83269562", "M": "22.642429557", "S": "0.1328892105" },
            { "Sex": "m", "Agemos": "232.5", "L": "-1.832584342", "M": "22.688732921", "S": "0.1330243684" },
            { "Sex": "m", "Agemos": "233.5", "L": "-1.832820974", "M": "22.734557126", "S": "0.1331741285" },
            { "Sex": "m", "Agemos": "234.5", "L": "-1.833400825", "M": "22.779895295", "S": "0.1333389994" },
            { "Sex": "m", "Agemos": "235.5", "L": "-1.834317405", "M": "22.824740868", "S": "0.1335194959" },
            { "Sex": "m", "Agemos": "236.5", "L": "-1.83555752", "M": "22.869089116", "S": "0.1337161923" },
            { "Sex": "m", "Agemos": "237.5", "L": "-1.837119466", "M": "22.912931508", "S": "0.1339295249" },
            { "Sex": "m", "Agemos": "238.5", "L": "-1.838987063", "M": "22.956263733", "S": "0.1341600729" },
            { "Sex": "m", "Agemos": "239.5", "L": "-1.841146139", "M": "22.999080616", "S": "0.1344083809" },
            { "Sex": "m", "Agemos": "240", "L": "-1.84233016", "M": "23.020294238", "S": "0.134539365" },
            { "Sex": "m", "Agemos": "240.5", "L": "-1.843580575", "M": "23.041377338", "S": "0.1346750014" },
            { "Sex": "f", "Agemos": "24", "L": "-0.98660853", "M": "16.423396643", "S": "0.085451785" },
            { "Sex": "f", "Agemos": "24.5", "L": "-1.024496827", "M": "16.388040561", "S": "0.085025838" },
            { "Sex": "f", "Agemos": "25.5", "L": "-1.102698353", "M": "16.318971901", "S": "0.0842140522" },
            { "Sex": "f", "Agemos": "26.5", "L": "-1.18396635", "M": "16.252079845", "S": "0.083455124" },
            { "Sex": "f", "Agemos": "27.5", "L": "-1.268071036", "M": "16.187346686", "S": "0.0827482842" },
            { "Sex": "f", "Agemos": "28.5", "L": "-1.354751525", "M": "16.124754481", "S": "0.0820927371" },
            { "Sex": "f", "Agemos": "29.5", "L": "-1.443689692", "M": "16.064287623", "S": "0.0814877172" },
            { "Sex": "f", "Agemos": "30.5", "L": "-1.53454192", "M": "16.005930007", "S": "0.0809324482" },
            { "Sex": "f", "Agemos": "31.5", "L": "-1.626928093", "M": "15.94966631", "S": "0.0804261754" },
            { "Sex": "f", "Agemos": "32.5", "L": "-1.720434829", "M": "15.895481969", "S": "0.0799681758" },
            { "Sex": "f", "Agemos": "33.5", "L": "-1.814635262", "M": "15.843361791", "S": "0.0795577348" },
            { "Sex": "f", "Agemos": "34.5", "L": "-1.909076262", "M": "15.793291456", "S": "0.0791941867" },
            { "Sex": "f", "Agemos": "35.5", "L": "-2.003296102", "M": "15.7452564", "S": "0.0788768946" },
            { "Sex": "f", "Agemos": "36.5", "L": "-2.096828937", "M": "15.699241878", "S": "0.0786052551" },
            { "Sex": "f", "Agemos": "37.5", "L": "-2.189211877", "M": "15.655232823", "S": "0.0783786964" },
            { "Sex": "f", "Agemos": "38.5", "L": "-2.279991982", "M": "15.613213709", "S": "0.0781966743" },
            { "Sex": "f", "Agemos": "39.5", "L": "-2.368732949", "M": "15.573168427", "S": "0.078058667" },
            { "Sex": "f", "Agemos": "40.5", "L": "-2.455021314", "M": "15.53508019", "S": "0.077964169" },
            { "Sex": "f", "Agemos": "41.5", "L": "-2.538471972", "M": "15.498931449", "S": "0.0779126837" },
            { "Sex": "f", "Agemos": "42.5", "L": "-2.618732901", "M": "15.464703844", "S": "0.0779037156" },
            { "Sex": "f", "Agemos": "43.5", "L": "-2.695488973", "M": "15.432378168", "S": "0.0779367628" },
            { "Sex": "f", "Agemos": "44.5", "L": "-2.768464816", "M": "15.401934364", "S": "0.078011309" },
            { "Sex": "f", "Agemos": "45.5", "L": "-2.837426693", "M": "15.373351541", "S": "0.0781268172" },
            { "Sex": "f", "Agemos": "46.5", "L": "-2.902178205", "M": "15.346608415", "S": "0.0782827393" },
            { "Sex": "f", "Agemos": "47.5", "L": "-2.962580386", "M": "15.321681814", "S": "0.0784784485" },
            { "Sex": "f", "Agemos": "48.5", "L": "-3.018521987", "M": "15.298548972", "S": "0.0787133246" },
            { "Sex": "f", "Agemos": "49.5", "L": "-3.069936555", "M": "15.277186179", "S": "0.0789866938" },
            { "Sex": "f", "Agemos": "50.5", "L": "-3.116795864", "M": "15.257569204", "S": "0.0792978405" },
            { "Sex": "f", "Agemos": "51.5", "L": "-3.159107331", "M": "15.239673384", "S": "0.079646006" },
            { "Sex": "f", "Agemos": "52.5", "L": "-3.196911083", "M": "15.22347371", "S": "0.0800303887" },
            { "Sex": "f", "Agemos": "53.5", "L": "-3.230276759", "M": "15.208944907", "S": "0.0804501449" },
            { "Sex": "f", "Agemos": "54.5", "L": "-3.259300182", "M": "15.19606152", "S": "0.0809043905" },
            { "Sex": "f", "Agemos": "55.5", "L": "-3.284099963", "M": "15.184797987", "S": "0.0813922027" },
            { "Sex": "f", "Agemos": "56.5", "L": "-3.30481415", "M": "15.175128708", "S": "0.0819126232" },
            { "Sex": "f", "Agemos": "57.5", "L": "-3.321596954", "M": "15.167028107", "S": "0.0824646608" },
            { "Sex": "f", "Agemos": "58.5", "L": "-3.334615646", "M": "15.160470684", "S": "0.0830472946" },
            { "Sex": "f", "Agemos": "59.5", "L": "-3.344047622", "M": "15.155431067", "S": "0.0836594775" },
            { "Sex": "f", "Agemos": "60.5", "L": "-3.35007771", "M": "15.15188405", "S": "0.0843001394" },
            { "Sex": "f", "Agemos": "61.5", "L": "-3.352893805", "M": "15.149804788", "S": "0.0849681996" },
            { "Sex": "f", "Agemos": "62.5", "L": "-3.352691376", "M": "15.14916825", "S": "0.085662539" },
            { "Sex": "f", "Agemos": "63.5", "L": "-3.34966438", "M": "15.149949835", "S": "0.086382035" },
            { "Sex": "f", "Agemos": "64.5", "L": "-3.343998803", "M": "15.152125852", "S": "0.0871255909" },
            { "Sex": "f", "Agemos": "65.5", "L": "-3.335889574", "M": "15.155671862", "S": "0.0878920466" },
            { "Sex": "f", "Agemos": "66.5", "L": "-3.325522491", "M": "15.160564192", "S": "0.0886802643" },
            { "Sex": "f", "Agemos": "67.5", "L": "-3.31307846", "M": "15.166779473", "S": "0.0894891056" },
            { "Sex": "f", "Agemos": "68.5", "L": "-3.298732648", "M": "15.174294641", "S": "0.090317434" },
            { "Sex": "f", "Agemos": "69.5", "L": "-3.282653831", "M": "15.183086936", "S": "0.0911641168" },
            { "Sex": "f", "Agemos": "70.5", "L": "-3.265003896", "M": "15.193133896", "S": "0.0920280276" },
            { "Sex": "f", "Agemos": "71.5", "L": "-3.245937506", "M": "15.204413348", "S": "0.0929080476" },
            { "Sex": "f", "Agemos": "72.5", "L": "-3.225606516", "M": "15.216902957", "S": "0.0938030328" },
            { "Sex": "f", "Agemos": "73.5", "L": "-3.204146115", "M": "15.230581504", "S": "0.0947119161" },
            { "Sex": "f", "Agemos": "74.5", "L": "-3.181690237", "M": "15.245427448", "S": "0.0956335947" },
            { "Sex": "f", "Agemos": "75.5", "L": "-3.158363475", "M": "15.261419664", "S": "0.096566992" },
            { "Sex": "f", "Agemos": "76.5", "L": "-3.134282833", "M": "15.278537278", "S": "0.0975110459" },
            { "Sex": "f", "Agemos": "77.5", "L": "-3.109557879", "M": "15.296759667", "S": "0.0984647101" },
            { "Sex": "f", "Agemos": "78.5", "L": "-3.084290931", "M": "15.316066442", "S": "0.0994269552" },
            { "Sex": "f", "Agemos": "79.5", "L": "-3.058577292", "M": "15.336437447", "S": "0.1003967693" },
            { "Sex": "f", "Agemos": "80.5", "L": "-3.032505499", "M": "15.357852744", "S": "0.1013731591" },
            { "Sex": "f", "Agemos": "81.5", "L": "-3.0061576", "M": "15.380292613", "S": "0.1023551503" },
            { "Sex": "f", "Agemos": "82.5", "L": "-2.979609448", "M": "15.403737535", "S": "0.1033417884" },
            { "Sex": "f", "Agemos": "83.5", "L": "-2.952930993", "M": "15.428168191", "S": "0.1043321392" },
            { "Sex": "f", "Agemos": "84.5", "L": "-2.926186592", "M": "15.453565452", "S": "0.1053252892" },
            { "Sex": "f", "Agemos": "85.5", "L": "-2.899435307", "M": "15.479910374", "S": "0.1063203463" },
            { "Sex": "f", "Agemos": "86.5", "L": "-2.872731211", "M": "15.507184187", "S": "0.1073164399" },
            { "Sex": "f", "Agemos": "87.5", "L": "-2.846123683", "M": "15.535368293", "S": "0.1083127212" },
            { "Sex": "f", "Agemos": "88.5", "L": "-2.819657704", "M": "15.564444257", "S": "0.1093083637" },
            { "Sex": "f", "Agemos": "89.5", "L": "-2.793374145", "M": "15.594393802", "S": "0.1103025629" },
            { "Sex": "f", "Agemos": "90.5", "L": "-2.767310047", "M": "15.625198798", "S": "0.111294537" },
            { "Sex": "f", "Agemos": "91.5", "L": "-2.741498897", "M": "15.656841259", "S": "0.1122835261" },
            { "Sex": "f", "Agemos": "92.5", "L": "-2.715970894", "M": "15.689303334", "S": "0.113268793" },
            { "Sex": "f", "Agemos": "93.5", "L": "-2.690753197", "M": "15.722567299", "S": "0.1142496222" },
            { "Sex": "f", "Agemos": "94.5", "L": "-2.665870146", "M": "15.756615553", "S": "0.1152253207" },
            { "Sex": "f", "Agemos": "95.5", "L": "-2.641343436", "M": "15.791430622", "S": "0.1161952181" },
            { "Sex": "f", "Agemos": "96.5", "L": "-2.617192204", "M": "15.826995169", "S": "0.1171586674" },
            { "Sex": "f", "Agemos": "97.5", "L": "-2.593430614", "M": "15.863292407", "S": "0.1181150731" },
            { "Sex": "f", "Agemos": "98.5", "L": "-2.570076037", "M": "15.900304841", "S": "0.1190638073" },
            { "Sex": "f", "Agemos": "99.5", "L": "-2.547141473", "M": "15.938015446", "S": "0.1200042898" },
            { "Sex": "f", "Agemos": "100.5", "L": "-2.524635245", "M": "15.976407871", "S": "0.1209359936" },
            { "Sex": "f", "Agemos": "101.5", "L": "-2.502569666", "M": "16.015464834", "S": "0.1218583548" },
            { "Sex": "f", "Agemos": "102.5", "L": "-2.48095189", "M": "16.055169844", "S": "0.1227708703" },
            { "Sex": "f", "Agemos": "103.5", "L": "-2.459785573", "M": "16.09550688", "S": "0.1236730846" },
            { "Sex": "f", "Agemos": "104.5", "L": "-2.439080117", "M": "16.136458809", "S": "0.1245644841" },
            { "Sex": "f", "Agemos": "105.5", "L": "-2.418838304", "M": "16.178009551", "S": "0.125444639" },
            { "Sex": "f", "Agemos": "106.5", "L": "-2.399063683", "M": "16.220142813", "S": "0.1263131206" },
            { "Sex": "f", "Agemos": "107.5", "L": "-2.379756861", "M": "16.262842771", "S": "0.1271695453" },
            { "Sex": "f", "Agemos": "108.5", "L": "-2.360920527", "M": "16.306093162", "S": "0.1280135154" },
            { "Sex": "f", "Agemos": "109.5", "L": "-2.342557728", "M": "16.349877586", "S": "0.1288446388" },
            { "Sex": "f", "Agemos": "110.5", "L": "-2.324663326", "M": "16.39418118", "S": "0.1296626372" },
            { "Sex": "f", "Agemos": "111.5", "L": "-2.307240716", "M": "16.438987413", "S": "0.1304671382" },
            { "Sex": "f", "Agemos": "112.5", "L": "-2.290287663", "M": "16.484280823", "S": "0.1312578524" },
            { "Sex": "f", "Agemos": "113.5", "L": "-2.273803847", "M": "16.530045538", "S": "0.1320344789" },
            { "Sex": "f", "Agemos": "114.5", "L": "-2.257782149", "M": "16.57626713", "S": "0.132796819" },
            { "Sex": "f", "Agemos": "115.5", "L": "-2.242227723", "M": "16.62292864", "S": "0.1335445247" },
            { "Sex": "f", "Agemos": "116.5", "L": "-2.227132805", "M": "16.670015716", "S": "0.1342774356" },
            { "Sex": "f", "Agemos": "117.5", "L": "-2.212495585", "M": "16.717512877", "S": "0.1349953236" },
            { "Sex": "f", "Agemos": "118.5", "L": "-2.19831275", "M": "16.765404961", "S": "0.1356979956" },
            { "Sex": "f", "Agemos": "119.5", "L": "-2.184580762", "M": "16.813676886", "S": "0.1363852755" },
            { "Sex": "f", "Agemos": "120.5", "L": "-2.171295888", "M": "16.862313656", "S": "0.1370570042" },
            { "Sex": "f", "Agemos": "121.5", "L": "-2.158454232", "M": "16.911300357", "S": "0.1377130391" },
            { "Sex": "f", "Agemos": "122.5", "L": "-2.146051754", "M": "16.960622156", "S": "0.1383532537" },
            { "Sex": "f", "Agemos": "123.5", "L": "-2.134084303", "M": "17.010264304", "S": "0.1389775374" },
            { "Sex": "f", "Agemos": "124.5", "L": "-2.122547629", "M": "17.060212133", "S": "0.1395857952" },
            { "Sex": "f", "Agemos": "125.5", "L": "-2.111437411", "M": "17.110451055", "S": "0.1401779469" },
            { "Sex": "f", "Agemos": "126.5", "L": "-2.100749266", "M": "17.160966564", "S": "0.1407539274" },
            { "Sex": "f", "Agemos": "127.5", "L": "-2.090478774", "M": "17.211744236", "S": "0.1413136859" },
            { "Sex": "f", "Agemos": "128.5", "L": "-2.080621484", "M": "17.262769728", "S": "0.1418571858" },
            { "Sex": "f", "Agemos": "129.5", "L": "-2.071172932", "M": "17.314028776", "S": "0.1423844043" },
            { "Sex": "f", "Agemos": "130.5", "L": "-2.062128649", "M": "17.365507199", "S": "0.1428953318" },
            { "Sex": "f", "Agemos": "131.5", "L": "-2.053484173", "M": "17.417190895", "S": "0.143389972" },
            { "Sex": "f", "Agemos": "132.5", "L": "-2.045235058", "M": "17.469065845", "S": "0.1438683412" },
            { "Sex": "f", "Agemos": "133.5", "L": "-2.03737688", "M": "17.52111811", "S": "0.1443304685" },
            { "Sex": "f", "Agemos": "134.5", "L": "-2.029906684", "M": "17.573333469", "S": "0.1447763715" },
            { "Sex": "f", "Agemos": "135.5", "L": "-2.022817914", "M": "17.625698688", "S": "0.1452061381" },
            { "Sex": "f", "Agemos": "136.5", "L": "-2.016107084", "M": "17.678199868", "S": "0.1456198193" },
            { "Sex": "f", "Agemos": "137.5", "L": "-2.009769905", "M": "17.730823397", "S": "0.1460174906" },
            { "Sex": "f", "Agemos": "138.5", "L": "-2.003802134", "M": "17.783555746", "S": "0.1463992386" },
            { "Sex": "f", "Agemos": "139.5", "L": "-1.998199572", "M": "17.836383471", "S": "0.1467651605" },
            { "Sex": "f", "Agemos": "140.5", "L": "-1.992958064", "M": "17.889293209", "S": "0.1471153639" },
            { "Sex": "f", "Agemos": "141.5", "L": "-1.988073505", "M": "17.942271684", "S": "0.1474499668" },
            { "Sex": "f", "Agemos": "142.5", "L": "-1.983541835", "M": "17.995305704", "S": "0.1477690965" },
            { "Sex": "f", "Agemos": "143.5", "L": "-1.979359041", "M": "18.048382162", "S": "0.1480728906" },
            { "Sex": "f", "Agemos": "144.5", "L": "-1.975521156", "M": "18.101488036", "S": "0.1483614954" },
            { "Sex": "f", "Agemos": "145.5", "L": "-1.972024258", "M": "18.154610394", "S": "0.1486350668" },
            { "Sex": "f", "Agemos": "146.5", "L": "-1.968864465", "M": "18.207736386", "S": "0.1488937694" },
            { "Sex": "f", "Agemos": "147.5", "L": "-1.966037938", "M": "18.260853253", "S": "0.1491377764" },
            { "Sex": "f", "Agemos": "148.5", "L": "-1.963540872", "M": "18.313948324", "S": "0.1493672695" },
            { "Sex": "f", "Agemos": "149.5", "L": "-1.961369499", "M": "18.367009017", "S": "0.1495824386" },
            { "Sex": "f", "Agemos": "150.5", "L": "-1.959520079", "M": "18.420022839", "S": "0.1497834816" },
            { "Sex": "f", "Agemos": "151.5", "L": "-1.9579889", "M": "18.472977388", "S": "0.1499706043" },
            { "Sex": "f", "Agemos": "152.5", "L": "-1.956772271", "M": "18.525860352", "S": "0.1501440201" },
            { "Sex": "f", "Agemos": "153.5", "L": "-1.95586652", "M": "18.578659513", "S": "0.1503039498" },
            { "Sex": "f", "Agemos": "154.5", "L": "-1.955267984", "M": "18.631362745", "S": "0.1504506214" },
            { "Sex": "f", "Agemos": "155.5", "L": "-1.954973011", "M": "18.683958013", "S": "0.1505842702" },
            { "Sex": "f", "Agemos": "156.5", "L": "-1.954977947", "M": "18.736433381", "S": "0.1507051384" },
            { "Sex": "f", "Agemos": "157.5", "L": "-1.955279136", "M": "18.788777004", "S": "0.1508134748" },
            { "Sex": "f", "Agemos": "158.5", "L": "-1.955872909", "M": "18.840977134", "S": "0.1509095352" },
            { "Sex": "f", "Agemos": "159.5", "L": "-1.956755579", "M": "18.893022121", "S": "0.1509935818" },
            { "Sex": "f", "Agemos": "160.5", "L": "-1.957923436", "M": "18.944900411", "S": "0.1510658829" },
            { "Sex": "f", "Agemos": "161.5", "L": "-1.959372737", "M": "18.996600549", "S": "0.1511267136" },
            { "Sex": "f", "Agemos": "162.5", "L": "-1.9610997", "M": "19.048111179", "S": "0.1511763547" },
            { "Sex": "f", "Agemos": "163.5", "L": "-1.963100496", "M": "19.099421046", "S": "0.1512150935" },
            { "Sex": "f", "Agemos": "164.5", "L": "-1.96537124", "M": "19.150518994", "S": "0.1512432229" },
            { "Sex": "f", "Agemos": "165.5", "L": "-1.967907983", "M": "19.201393971", "S": "0.1512610419" },
            { "Sex": "f", "Agemos": "166.5", "L": "-1.970706706", "M": "19.252035026", "S": "0.1512688553" },
            { "Sex": "f", "Agemos": "167.5", "L": "-1.973763307", "M": "19.302431312", "S": "0.1512669735" },
            { "Sex": "f", "Agemos": "168.5", "L": "-1.977073595", "M": "19.352572085", "S": "0.1512557127" },
            { "Sex": "f", "Agemos": "169.5", "L": "-1.980633277", "M": "19.402446707", "S": "0.1512353947" },
            { "Sex": "f", "Agemos": "170.5", "L": "-1.984437954", "M": "19.452044646", "S": "0.1512063468" },
            { "Sex": "f", "Agemos": "171.5", "L": "-1.988483106", "M": "19.501355476", "S": "0.1511689019" },
            { "Sex": "f", "Agemos": "172.5", "L": "-1.992764085", "M": "19.550368876", "S": "0.1511233983" },
            { "Sex": "f", "Agemos": "173.5", "L": "-1.997276103", "M": "19.599074637", "S": "0.1510701797" },
            { "Sex": "f", "Agemos": "174.5", "L": "-2.002014224", "M": "19.647462655", "S": "0.1510095954" },
            { "Sex": "f", "Agemos": "175.5", "L": "-2.00697335", "M": "19.695522937", "S": "0.1509419999" },
            { "Sex": "f", "Agemos": "176.5", "L": "-2.012148213", "M": "19.743245597", "S": "0.1508677534" },
            { "Sex": "f", "Agemos": "177.5", "L": "-2.017533363", "M": "19.790620862", "S": "0.1507872211" },
            { "Sex": "f", "Agemos": "178.5", "L": "-2.023123159", "M": "19.837639068", "S": "0.1507007738" },
            { "Sex": "f", "Agemos": "179.5", "L": "-2.028911755", "M": "19.884290662", "S": "0.1506087878" },
            { "Sex": "f", "Agemos": "180.5", "L": "-2.034893091", "M": "19.930566203", "S": "0.1505116446" },
            { "Sex": "f", "Agemos": "181.5", "L": "-2.041060881", "M": "19.976456361", "S": "0.1504097312" },
            { "Sex": "f", "Agemos": "182.5", "L": "-2.047408604", "M": "20.021951917", "S": "0.1503034402" },
            { "Sex": "f", "Agemos": "183.5", "L": "-2.05392949", "M": "20.067043765", "S": "0.1501931693" },
            { "Sex": "f", "Agemos": "184.5", "L": "-2.060616513", "M": "20.11172291", "S": "0.1500793222" },
            { "Sex": "f", "Agemos": "185.5", "L": "-2.067462375", "M": "20.155980469", "S": "0.1499623077" },
            { "Sex": "f", "Agemos": "186.5", "L": "-2.074459502", "M": "20.199807672", "S": "0.1498425404" },
            { "Sex": "f", "Agemos": "187.5", "L": "-2.081600029", "M": "20.243195857", "S": "0.1497204407" },
            { "Sex": "f", "Agemos": "188.5", "L": "-2.088875793", "M": "20.286136477", "S": "0.1495964342" },
            { "Sex": "f", "Agemos": "189.5", "L": "-2.096278323", "M": "20.328621093", "S": "0.1494709526" },
            { "Sex": "f", "Agemos": "190.5", "L": "-2.103798828", "M": "20.370641376", "S": "0.1493444333" },
            { "Sex": "f", "Agemos": "191.5", "L": "-2.111428194", "M": "20.412189106", "S": "0.1492173194" },
            { "Sex": "f", "Agemos": "192.5", "L": "-2.119156972", "M": "20.453256172", "S": "0.14909006" },
            { "Sex": "f", "Agemos": "193.5", "L": "-2.126975375", "M": "20.49383457", "S": "0.1489631101" },
            { "Sex": "f", "Agemos": "194.5", "L": "-2.134873266", "M": "20.5339164", "S": "0.1488369306" },
            { "Sex": "f", "Agemos": "195.5", "L": "-2.142840157", "M": "20.573493869", "S": "0.1487119885" },
            { "Sex": "f", "Agemos": "196.5", "L": "-2.150865204", "M": "20.612559285", "S": "0.1485887569" },
            { "Sex": "f", "Agemos": "197.5", "L": "-2.158937201", "M": "20.651105058", "S": "0.1484677151" },
            { "Sex": "f", "Agemos": "198.5", "L": "-2.167044578", "M": "20.689123698", "S": "0.1483493484" },
            { "Sex": "f", "Agemos": "199.5", "L": "-2.175176987", "M": "20.726607282", "S": "0.1482341202" },
            { "Sex": "f", "Agemos": "200.5", "L": "-2.183317362", "M": "20.763550105", "S": "0.148122614" },
            { "Sex": "f", "Agemos": "201.5", "L": "-2.191457792", "M": "20.799943374", "S": "0.1480152488" },
            { "Sex": "f", "Agemos": "202.5", "L": "-2.199583649", "M": "20.83578051", "S": "0.1479125643" },
            { "Sex": "f", "Agemos": "203.5", "L": "-2.207681525", "M": "20.871054493", "S": "0.1478150781" },
            { "Sex": "f", "Agemos": "204.5", "L": "-2.215737645", "M": "20.905758394", "S": "0.1477233147" },
            { "Sex": "f", "Agemos": "205.5", "L": "-2.223739902", "M": "20.939884769", "S": "0.1476377678" },
            { "Sex": "f", "Agemos": "206.5", "L": "-2.231667995", "M": "20.973428578", "S": "0.1475590832" },
            { "Sex": "f", "Agemos": "207.5", "L": "-2.239511942", "M": "21.006381705", "S": "0.1474877162" },
            { "Sex": "f", "Agemos": "208.5", "L": "-2.247257081", "M": "21.038737402", "S": "0.1474242097" },
            { "Sex": "f", "Agemos": "209.5", "L": "-2.254885145", "M": "21.070489959", "S": "0.1473691743" },
            { "Sex": "f", "Agemos": "210.5", "L": "-2.26238209", "M": "21.101632407", "S": "0.147323144" },
            { "Sex": "f", "Agemos": "211.5", "L": "-2.269731517", "M": "21.132158447", "S": "0.1472866982" },
            { "Sex": "f", "Agemos": "212.5", "L": "-2.276917229", "M": "21.162061708", "S": "0.1472604146" },
            { "Sex": "f", "Agemos": "213.5", "L": "-2.283925442", "M": "21.191335097", "S": "0.1472448281" },
            { "Sex": "f", "Agemos": "214.5", "L": "-2.290731442", "M": "21.219974716", "S": "0.1472406828" },
            { "Sex": "f", "Agemos": "215.5", "L": "-2.29732427", "M": "21.247972623", "S": "0.147248467" },
            { "Sex": "f", "Agemos": "216.5", "L": "-2.303687802", "M": "21.275322389", "S": "0.1472687698" },
            { "Sex": "f", "Agemos": "217.5", "L": "-2.309799971", "M": "21.302019325", "S": "0.1473022986" },
            { "Sex": "f", "Agemos": "218.5", "L": "-2.315651874", "M": "21.328054894", "S": "0.1473495144" },
            { "Sex": "f", "Agemos": "219.5", "L": "-2.32121731", "M": "21.353425629", "S": "0.1474112153" },
            { "Sex": "f", "Agemos": "220.5", "L": "-2.326481911", "M": "21.378124616", "S": "0.1474879793" },
            { "Sex": "f", "Agemos": "221.5", "L": "-2.331428139", "M": "21.402145892", "S": "0.1475804525" },
            { "Sex": "f", "Agemos": "222.5", "L": "-2.336038473", "M": "21.425483514", "S": "0.1476892889" },
            { "Sex": "f", "Agemos": "223.5", "L": "-2.34029545", "M": "21.448131558", "S": "0.1478151501" },
            { "Sex": "f", "Agemos": "224.5", "L": "-2.344181703", "M": "21.470084116", "S": "0.1479587057" },
            { "Sex": "f", "Agemos": "225.5", "L": "-2.34768", "M": "21.491335286", "S": "0.1481206332" },
            { "Sex": "f", "Agemos": "226.5", "L": "-2.350773286", "M": "21.511879176", "S": "0.1483016185" },
            { "Sex": "f", "Agemos": "227.5", "L": "-2.353444725", "M": "21.531709894", "S": "0.1485023554" },
            { "Sex": "f", "Agemos": "228.5", "L": "-2.355677743", "M": "21.550821547", "S": "0.1487235462" },
            { "Sex": "f", "Agemos": "229.5", "L": "-2.35745607", "M": "21.569208237", "S": "0.1489659018" },
            { "Sex": "f", "Agemos": "230.5", "L": "-2.358763788", "M": "21.586864057", "S": "0.1492301415" },
            { "Sex": "f", "Agemos": "231.5", "L": "-2.359585369", "M": "21.603783087", "S": "0.1495169936" },
            { "Sex": "f", "Agemos": "232.5", "L": "-2.359905726", "M": "21.619959388", "S": "0.1498271951" },
            { "Sex": "f", "Agemos": "233.5", "L": "-2.359710258", "M": "21.635387002", "S": "0.1501614923" },
            { "Sex": "f", "Agemos": "234.5", "L": "-2.358980464", "M": "21.650061262", "S": "0.150520734" },
            { "Sex": "f", "Agemos": "235.5", "L": "-2.357714508", "M": "21.663972695", "S": "0.1509054394" },
            { "Sex": "f", "Agemos": "236.5", "L": "-2.355892424", "M": "21.677117355", "S": "0.1513165313" },
            { "Sex": "f", "Agemos": "237.5", "L": "-2.353501353", "M": "21.689489352", "S": "0.1517548077" },
            { "Sex": "f", "Agemos": "238.5", "L": "-2.350528726", "M": "21.701082884", "S": "0.1522210861" },
            { "Sex": "f", "Agemos": "239.5", "L": "-2.346962247", "M": "21.711892252", "S": "0.1527162055" },
            { "Sex": "f", "Agemos": "240", "L": "-2.34495843", "M": "21.716999342", "S": "0.152974718" },
            { "Sex": "f", "Agemos": "240.5", "L": "-2.342796948", "M": "21.721909734", "S": "0.1532408716" }
        ];
        
        for (var item in jsonValues) {
            if (jsonValues[item].Sex == currentGender && jsonValues[item].Agemos == currentAgeInMonths + ".5") {
                lVal = jsonValues[item].L;
                mVal = jsonValues[item].M;
                sVal = jsonValues[item].S;

                //zScore Calc
                zScore = (Math.pow(currentBMI / mVal, lVal) - 1) / (lVal * sVal);
                
                //Percentile Calc
                //myPercentile = normal(zScore, 0, 1);
                myPercentile = GetNormSDist(zScore) * 100;
                myPercentileRounded = Math.round(myPercentile);
                myPercentileRounded = AddNumberExtension(myPercentileRounded.toString());
            }
        }
        
        if (myPercentile > 99.0) {
            document.getElementById("IncorrectHeader").innerHTML = "Please check the accuracy of the information you entered.<br />";
            document.getElementById("IncorrectInformation").innerHTML += "Based on the information entered, the calculated BMI is above the range of expected values and cannot be displayed on a BMI-for-age percentile growth chart.<br />If the entries are accurate, this child is obese and further assessment by a healthcare provider is recommended.";
            document.getElementById("IncorrectInformation").style.display = "block";
            document.getElementById("ChartHeader").style.color = "red";
        }
        if (myPercentile < 1.0) {
            document.getElementById("IncorrectHeader").innerHTML = "Please check the accuracy of the information you entered.<br />";
            document.getElementById("IncorrectInformation").innerHTML += "Based on the information entered, the calculated BMI is below the range of expected values and cannot be displayed on a BMI-for-age percentile growth chart.<br />If the entries are accurate, this child is underweight and further assessment by a healthcare provider is recommended.";
            document.getElementById("IncorrectInformation").style.display = "block";
            document.getElementById("ChartHeader").style.color = "red";
            myPercentileRounded = "1st";
        }
        
        var percentileSpans = document.querySelectorAll(".PercentileSpan");

        for (var i = 0; i < percentileSpans.length; i++) {
            if (i == (percentileSpans.length - 1)) {
                if (myPercentile < 1.0) {
                    percentileSpans[i].innerHTML = "Below " + myPercentileRounded;
                } else {
                    percentileSpans[i].innerHTML = myPercentileRounded;
                }
            } else {
                if (myPercentile < 1.0) {
                    percentileSpans[i].innerHTML = "below the " + myPercentileRounded;
                } else {
                    percentileSpans[i].innerHTML = "in the " + myPercentileRounded;
                }
            }
        }
        
        if (currentBMI > 10 && currentBMI < 35) {
            if (currentAgeInMonths / 12 > 16) {
                document.getElementById("BMISpan").style.position = "absolute";
                document.getElementById("BMISpan").style.top = "23px";
                document.getElementById("BMISpan").style.left = "-23px";
                
            }
            

        } else {
            document.getElementById("BMIDot").style.display = "none";
        }
    }

    function ChildBMICalc_DisplayResults()
    {
        ChildBMICalc_RePopulateCalculator();
	
        //start the display process
        document.getElementById("ChildBMICalc_Form").style.display = "none";
        document.getElementById("ChildBMICalc_AboutYourResults").style.display = "";
        document.getElementById("ChildBMICalc_AnswerBMI").innerHTML += RoundToTenth(BMI) + ".";
        document.getElementById("ChildBMICalc_AboutResults_" + Category).style.display = "";
        document.getElementById("ChildBMICalc_LowEndHealthyBMI_" + Category).innerHTML += " " + RoundToTenth(LowerIdealBMI) + " ";
        document.getElementById("ChildBMICalc_HighEndHealthyBMI_" + Category).innerHTML += " " + RoundToTenth(UpperIdealBMI);
    }

    function RoundToTenth(input)
    {
        return Math.round(input*10.0)/10.0;
    }

    function ChildBMICalc_RePopulateCalculator()
    {
        var elem;
	
        if(m_Parameters[0] == "m")
        {
            elem = document.getElementById(m_ThisCalculatorsName + "_Gender_Male");
            elem.checked = true;
        }
        else
        {
            elem = document.getElementById(m_ThisCalculatorsName + "_Gender_Female");
            elem.checked = true;
        }

        for(var i = 0; i < document.getElementById(m_ThisCalculatorsName + "_Age_Years").length; i++)
        {
            if(document.getElementById(m_ThisCalculatorsName + "_Age_Years").options[i].value == m_Parameters[1])
            {
                document.getElementById(m_ThisCalculatorsName + "_Age_Years").selectedIndex = i;
            }
        }
        for(var i = 0; i < document.getElementById(m_ThisCalculatorsName + "_Age_Months").length; i++)
        {
            if(document.getElementById(m_ThisCalculatorsName + "_Age_Months").options[i].value == m_Parameters[2])
            {
                document.getElementById(m_ThisCalculatorsName + "_Age_Months").selectedIndex = i;
            }
        }

        elem = document.getElementById(m_ThisCalculatorsName + "_Height_Feet");
        elem.value = m_Parameters[3];

        elem = document.getElementById(m_ThisCalculatorsName + "_Height_Inches");
        elem.value = m_Parameters[4];

        elem = document.getElementById(m_ThisCalculatorsName + "_Weight");
        elem.value = m_Parameters[5];	
    }
    
    /**
 * @dependencies:
 * Math.abs
 * Math.SQRT2
 * Math.erf
 * 
 * http://www.codeproject.com/Articles/408214/Excel-Function-NORMSDIST-z
 */
    function GetNormSDist(z) {
        var sign,ret;
        if (z < 0) {
            sign = -1;
        } else {
            sign = 1;
        }
        ret = Math.abs(z);
        ret /= Math.SQRT2;
        ret = GetERF(ret);
        ret *= sign;
        ret += 1;
        ret /= 2;
        return ret;
    }
        
    /**
 * @dependencies
 * Math.abs
 * Math.exp
 * 
 * http://www.codeproject.com/Articles/408214/Excel-Function-NORMSDIST-z
 */

    function GetERF(x) {
        var a1,
                a2,
                a3,
                a4,
                a5,
                p;
        a1 = 0.254829592;
        a2 = -0.284496736;
        a3 = 1.421413741;
        a4 = -1.453152027;
        a5 = 1.061405429;
        p = 0.3275911;
        var t,
            ret;
        x = Math.abs(x);
        t = 1 / (1 + p * x);
        ret = a5;
        ret *= t;
        ret += a4;
        ret *= t;
        ret += a3;
        ret *= t;
        ret += a2;
        ret *= t;
        ret += a1;
        ret *= t;
        ret *= Math.exp(-1 * x * x);
        ret = 1 - ret;
        return ret;
    }

    function AddNumberExtension(number) {
        var lastNumber = number.slice(-1);
        var suffix;
        var newNumber;
        if (lastNumber == 1 && number != 11) {
            suffix = "st";
        }
        else if (lastNumber == 2 && number != 12) {
            suffix = "nd";
        }
        else if (lastNumber == 3 && number != 13) {
            suffix = "rd";
        }
        else {
            suffix = "th";
        }
        newNumber = number + suffix;
        return newNumber;
    }

    function SetDotPosition() {
        var chartWidth = document.getElementById("BMIChart").offsetWidth;
        document.getElementById("BMIChart").style.height = (chartWidth * .939).toString() + "px";
        var chartHeight = document.getElementById("BMIChart").offsetHeight;
        
        //set dot position based on BMIChart width
        var bmiDotLeftPosition = (((20 / 675) * 100) + ((AgeInMonths / 12 * 24) / 675) * 100).toString() + "%";
        var bmiDotBottomPosition = (((50 / 634) * 100) + (((BMI - 10) * 21) / 634) * 100).toString() + "%";

        document.getElementById("BMIDot").style.position = "absolute";
        document.getElementById("BMIDot").style.left = bmiDotLeftPosition;
        document.getElementById("BMIDot").style.bottom = bmiDotBottomPosition;
        document.getElementById("BMISpan").innerHTML = "BMI: " + BMI.toString().substr(0, 4);
    }
    window.onload = function () {
        SetDotPosition();
    };
    window.onresize = function () {
        SetDotPosition();
    };
    --></script>
</body>
