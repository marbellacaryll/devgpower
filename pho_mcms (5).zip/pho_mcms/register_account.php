<?php
include('connection.php');
include('bhw_header.php');
?>
<body>
<form action="create_account.php" method="POST">
		<div class="w3-container">
			<div class="card" style="width: 860px; margin-left: 240px; margin-top: 60px;">
				<div class="card-body">
					<div class="w3-row-padding">
						<center><h3>REGISTER ACCOUNT</h3></center>
			<div class="w3-third">
				<p class="w3-small">FIRSTNAME:
				<input type="text" name="firstname" class="w3-input w3-small w3-border" placeholder="Enter your fullname..." required>
			</p>
			</div>
			<div class="w3-third">
						<p class="w3-small">MIDDLE NAME:
							<input type="text" name="middlename" class="w3-input w3-small w3-border" placeholder="Enter your middlename..." required>
						</p>
					</div>
					<div class="w3-third">
						<p class="w3-small">LAST NAME:
							<input type="text" name="lastname" class="w3-input w3-small w3-border" placeholder="Enter your lastname..." required>
						</p>
					</div>
					<div class="w3-third">
	                  <p class="w3-small">BIRTHDATE:
	                    <input type="date" name="bdate" id="date" class="w3-input w3-border w3-tiny" placeholder="Enter your bdate...">
	                  </p>
	                </div>
	                <div class="w3-third">
	                  <p class="w3-small">AGE:
	                    <input type="text" name="age" id="age" class="w3-input w3-border w3-tiny" placeholder="Enter your age...">
	                  </p>
	                </div>
	                <div class="w3-third">
	                  <p class="w3-small">GENDER:
	                    <select class="w3-select w3-input w3-border w3-tiny" name="gender">
	                      <option style="background-color: gray;">Choose</option>
	                      <option value="male">Male</option>
	                      <option value="female">Female</option>
	                    </select>
	                  </p>
	                </div>
	                <div class="w3-third">
	                	<p class="w3-small">CONTACT NUMBER:
	                		<input type="text" name="contact_number" class="w3-input w3-border w3-tiny" placeholder="Enter your contact number...">
	                	</p>
	                </div>
			<div class="w3-third">
				<p class="w3-small">POSITION:
				<select name="position" class="w3-select w3-small w3-border" class="w3-select w3-border w3-small" required>
				<option>Choose</option>
				<?php
						$query3 = mysqli_query($conn, "SELECT* FROM userposition_id");
						while($position = mysqli_fetch_array($query3)){
							echo "<option value='".$position['level']."'>".ucwords($position['positions'])."</option>";
						}
					?>		
				</select>
			</p>
			</div>
          <div class="w3-third">
            <p class="w3-small">Municipal:
              <select onChange="getbarangay(this.value);"  name="municipality" id="municipality" class="w3-select w3-border w3-small">
                <option>Choose</option>
                 <?php
                 $query3 = mysqli_query($conn, "SELECT * FROM municipality");
                   while($municipality = mysqli_fetch_array($query3)){
                   echo "<option value='".$municipality['mun_id']."'>".ucwords($municipality["muncipality_name"])."</option>";
                } 
              ?>    
             </select>
           </p>
          </div>
           <div class="w3-third">
             <p class="w3-small">Barangay:
              <select name="bar_id" id="district-list" class="w3-select w3-border w3-small">
                <option value ="bar_id">Choose</option>
              </select>
            </p>
          </div>
			<div class="w3-third">
				<p class="w3-small">EMAIL:
				<input type="email" name="email" class="w3-input w3-small w3-border" placeholder="Enter your email..." required>
			</p>
			</div>
			<div class="w3-third">
				<p class="w3-small">USERNAME:
				<input type="text" name="username" class="w3-input w3-small w3-border" placeholder="Enter your username..." required>
			</p>
			</div>
			<div class="w3-third">
				<p class="w3-small">PASSWORD:
				<input type="password" name="password" id="pass" class="w3-input w3-small w3-border" placeholder="Enter your password..." onkeyup='check();' />
				<br>
				<br>
			</p>
			</div>
			<div class="w3-third">
				<p class="w3-small">CONFIRM PASSWORD:
				<input type="password" name="confirm_password" id="confirm_password" class="w3-input w3-small w3-border" placeholder="Enter your password..." onkeyup='check();' /> 
  				<span id='message'></span>
				<br>
				<br>
			</p>
			</div>
			</div>
			<a href="index.php" button type="back" class="w3-button w3-gray w3-small w3-round-xxlarge" style="width: 150px; margin-left: 490px;" >BACK</a>
			<input type="submit" name="addAccount" class="w3-button w3-blue w3-small w3-round-xxlarge" style="width: 150px; margin-left: 20px;"  value="SUBMIT">
		
					</div>
				</div>
			</div>
		</div>
	</form>
</body>
<script type="text/javascript" src="../pho_mcms/js/jquery.min.js"></script>
<script>
function getbarangay(val) {
  $.ajax({
  type: "POST",
  url: "get_barangay.php",
  data:'mun_id='+val,
  success: function(data){
    $("#district-list").html(data);
  }
  });
}
function selectCountry(val) {
$("#search-box").val(val);
$("#suggesstion-box").hide();
}
</script> 
<script src="../pho_mcms/js/jquery-1.11.1.js" type="text/javascript"></script>
<script src="../pho_mcms/js/bootstrap.min.js" type="text/javascript"></script>
<script src="../pho_mcms/js/jquery-ui-1.10.1.custom.min.js"></script>
<script>
$(function () {
    $('#date').datepicker({
      onSelect: function(value, ui) {
      var today = new Date(),
        dob = new Date(value),
        age = new Date(today - dob).getFullYear() - 1970;

      $('#age').val(age);
      
      },
    maxDate: '+0d',
    yearRange: '1900:2014',
    changeMonth: true,
    changeYear: true
  });
});
</script>

<script type="text/javascript">
	var check = function() {
  if (document.getElementById('pass').value ==
    document.getElementById('confirm_password').value) {
    document.getElementById('message').style.color = 'green';
    document.getElementById('message').innerHTML = 'Password Matched.';
  } else {
    document.getElementById('message').style.color = 'red';
    document.getElementById('message').innerHTML = 'Password you entered is not matched.';
  }
}
</script>