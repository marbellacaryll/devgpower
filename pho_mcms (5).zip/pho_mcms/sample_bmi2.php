

<div id="calculator_form_wrapper" class="module-typeA">

    <h3>BMI Calculator for Child and Teen</h3>


    <!-- ######################## FORM ######################## -->
    <div class="pull-right">

      <input checked type="radio" id="english" name="english_metric" value="english">
      <label for="english">English</label>&nbsp;&nbsp;

      <input type="radio" id="metric" name="english_metric" value="metric">
      <label for="metric">Metric</label>

    </div><br>

    <p class="form_err" id="all_form_check">&#10071; Please check the accuracy of the information you entered.</p>
    <p class="form_err_age_diff" id="age_under_2"><b>Birth Date</b> must be at least 2 years before <b>Date of Measurement</b>. If the child is under 2 years old, BMI cannot be calculated. Consult a healthcare provider for assessment.</p>
    <p class="form_err_age_diff" id="age_over_20">Based on the <b>Birth Date</b> and <b>Date of Measurement</b>, the calculated age is 20 years or older. This calculator can be used only if the calculated age is less than 20 years old. If the dates you entered are correct, use the <a href="/healthyweight/assessing/bmi/adult_BMI/english_bmi_calculator/bmi_calculator.html">Adult BMI Calculator</a>.</p>

    <div class="linebreak"></div>

    <div class="radio_buttons">
      <div class="inline_blk">
        <input checked type="radio" id="age_y_m" name="age_ym_or_do" value="age_y_m">
        <label for="age_y_m">Age: Years, Months</label>&nbsp;&nbsp;&nbsp;&nbsp;
      </div>
      <div class="inline_blk">
        <input type="radio" id="age_do" name="age_ym_or_do" value="age_do">
        <label for="age_do">Date of Birth, Date of Measurement</label>
      </div>
    </div>

    <div id="div_age_y_m">
    <p><b>Age:</b> <span class="form_err" id="age_check"> Select Age</span></p>

    <div class="inline_blk">
      <input type="text" pattern="[0-9]" maxlength="3" name="age_y_direct" id="age_y_direct">
      <label for="age_y_direct">years <small>(2 to 19)</small></label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    </div>

    <div class="inline_blk">
      <input type="text" pattern="[0-9]" maxlength="2" name="age_m_direct" id="age_m_direct">
      <label for="age_m_direct">months <small>(0 to 11)</small></label>
    </div>

    <p> or enter only the total number of months:</p>
    <input type="text" pattern="[0-9]" maxlength="3" name="age_m_only_direct" id="age_m_only_direct">
    <label for="age_m_only_direct">months <small>(24 to 239)</small></label>


  </div>

    <div id="div_dob_dom">

      <div id="div_dob">
        <p><b>Birth Date:</b> <span class="form_err" id="dob_check"> Select Date</span></p>

        <label for="dob_month" class="accessibleHide">Month:</label>
        <select name="dob_month" id="dob_month">
          <option selected value="0">Month</option>
          <option value="01">January</option>
          <option value="02">February</option>
          <option value="03">March</option>
          <option value="04">April</option>
          <option value="05">May</option>
          <option value="06">June</option>
          <option value="07">July</option>
          <option value="08">August</option>
          <option value="09">September</option>
          <option value="10">October</option>
          <option value="11">November</option>
          <option value="12">December</option>
        </select>&nbsp;&nbsp;&nbsp;

        <label for="dob_day" class="accessibleHide">Day:</label>
        <select name="dob_day" id="dob_day">
          <option value="0">Day</option>
          <option value="01">1</option>
          <option value="02">2</option>
          <option value="03">3</option>
          <option value="04">4</option>
          <option value="05">5</option>
          <option value="06">6</option>
          <option value="07">7</option>
          <option value="08">8</option>
          <option value="09">9</option>
          <option value="10">10</option>
          <option value="11">11</option>
          <option value="12">12</option>
          <option value="13">13</option>
          <option value="14">14</option>
          <option value="15">15</option>
          <option value="16">16</option>
          <option value="17">17</option>
          <option value="18">18</option>
          <option value="19">19</option>
          <option value="20">20</option>
          <option value="21">21</option>
          <option value="22">22</option>
          <option value="23">23</option>
          <option value="24">24</option>
          <option value="25">25</option>
          <option value="26">26</option>
          <option value="27">27</option>
          <option value="28">28</option>
          <option value="29">29</option>
          <option value="30">30</option>
          <option value="31">31</option>
        </select>&nbsp;&nbsp;&nbsp;

        <label for="dob_year" class="accessibleHide">Year:</label>
        <select name="dob_year" id="dob_year">
           <option value="0">Year</option>
           <option value="2017">2017</option>
           <option value="2016">2016</option>
           <option value="2015">2015</option>
           <option value="2014">2014</option>
           <option value="2013">2013</option>
           <option value="2012">2012</option>
           <option value="2011">2011</option>
           <option value="2010">2010</option>
           <option value="2009">2009</option>
           <option value="2008">2008</option>
           <option value="2007">2007</option>
           <option value="2006">2006</option>
           <option value="2005">2005</option>
           <option value="2004">2004</option>
           <option value="2003">2003</option>
           <option value="2002">2002</option>
           <option value="2001">2001</option>
           <option value="2000">2000</option>
           <option value="1999">1999</option>
           <option value="1998">1998</option>
        </select>&nbsp;&nbsp;&nbsp;
      </div>

      <div id="div_dom">
        <p><b>Date of Measurement:</b> <span class="form_err" id="dom_check"> Select Date</span></p>

        <label for="dom_month" class="accessibleHide">Month:</label>
        <select name="dom_month" id="dom_month">
          <option selected value="0">Month</option>
          <option value="01">January</option>
          <option value="02">February</option>
          <option value="03">March</option>
          <option value="04">April</option>
          <option value="05">May</option>
          <option value="06">June</option>
          <option value="07">July</option>
          <option value="08">August</option>
          <option value="09">September</option>
          <option value="10">October</option>
          <option value="11">November</option>
          <option value="12">December</option>
        </select>&nbsp;&nbsp;&nbsp;

        <label for="dom_day" class="accessibleHide">Day:</label>
        <select name="dom_day" id="dom_day">
          <option value="0">Day</option>
          <option value="01">1</option>
          <option value="02">2</option>
          <option value="03">3</option>
          <option value="04">4</option>
          <option value="05">5</option>
          <option value="06">6</option>
          <option value="07">7</option>
          <option value="08">8</option>
          <option value="09">9</option>
          <option value="10">10</option>
          <option value="11">11</option>
          <option value="12">12</option>
          <option value="13">13</option>
          <option value="14">14</option>
          <option value="15">15</option>
          <option value="16">16</option>
          <option value="17">17</option>
          <option value="18">18</option>
          <option value="19">19</option>
          <option value="20">20</option>
          <option value="21">21</option>
          <option value="22">22</option>
          <option value="23">23</option>
          <option value="24">24</option>
          <option value="25">25</option>
          <option value="26">26</option>
          <option value="27">27</option>
          <option value="28">28</option>
          <option value="29">29</option>
          <option value="30">30</option>
          <option value="31">31</option>
        </select>&nbsp;&nbsp;&nbsp;

        <label for="dom_year" class="accessibleHide">Year:</label>
        <select name="dom_year" id="dom_year">
         <option value="0">Year</option>
         <option value="2019">2019</option>
         <option value="2018">2018</option>
         <option value="2017">2017</option>
         <option value="2016">2016</option>
         <option value="2015">2015</option>
         <option value="2014">2014</option>
         <option value="2013">2013</option>
         <option value="2012">2012</option>
         <option value="2011">2011</option>
         <option value="2010">2010</option>
         <option value="2009">2009</option>
         <option value="2008">2008</option>
         <option value="2007">2007</option>
         <option value="2006">2006</option>
         <option value="2005">2005</option>
         <option value="2004">2004</option>
         <option value="2003">2003</option>
         <option value="2002">2002</option>
         <option value="2001">2001</option>
         <option value="2000">2000</option>
         <option value="1999">1999</option>
         <option value="1998">1998</option>
      </select>&nbsp;&nbsp;&nbsp;
      </div>

    </div>

    <div class="linebreak"></div>

    <div id="div_sex_m_f">
      <p><b>Sex:</b> <span class="form_err" id="sex_m_f_check"> Select Sex</span></p>

      <input type="radio" id="sex_m" name="sex_m_f" value="sex_m">
      <label for="sex_m">Boy</label>&nbsp;&nbsp;&nbsp;

      <input type="radio" id="sex_f" name="sex_m_f" value="sex_f">
      <label for="sex_f">Girl</label>

    </div>

    <div class="linebreak"></div>

    <div class="radio_buttons" id="radio_en_drop_or_direct">
      <div class="inline_blk">
        <input checked type="radio" id="height_eng_direct" name="height_eng_drop_or_direct" value="height_eng_direct">
        <label for="height_eng_direct">Height: Inches</label>&nbsp;&nbsp;&nbsp;&nbsp;
      </div>
      <div class="inline_blk">
        <input type="radio" id="height_eng_drop" name="height_eng_drop_or_direct" value="height_eng_drop">
        <label for="height_eng_drop">Height: Ft, Inch, Fraction</label>
      </div>
    </div>

    <div id="div_height_eng_direct">
      <p><b>Height</b> (decimal places allowed): <span class="form_err" id="height_check_eng_direct"> Select Height</span></p>

      <input type="text" pattern="[0-9]" maxlength="6" name="height_inch_direct" id="height_inch_direct">
      <label for="height_inch_direct">inches</label>
    </div>

    <div id="div_height_eng_drop">
      <p><b>Height</b>, to nearest 1/8 inch: <span class="form_err" id="height_check_eng"> Select Height</span></p>

      <label for="height_feet">Feet</label>
      <select name="height_feet" id="height_feet">
         <option value="0">0</option>
         <option value="1">1</option>
         <option value="2">2</option>
         <option value="3">3</option>
         <option value="4">4</option>
         <option value="5">5</option>
         <option value="6">6</option>
         <option value="7">7</option>
      </select>&nbsp;&nbsp;&nbsp;

      <label for="height_inches">Inches</label>
      <select name="height_inches" id="height_inches">
         <option value="0">0</option>
         <option value="1">1</option>
         <option value="2">2</option>
         <option value="3">3</option>
         <option value="4">4</option>
         <option value="5">5</option>
         <option value="6">6</option>
         <option value="7">7</option>
         <option value="8">8</option>
         <option value="9">9</option>
         <option value="10">10</option>
         <option value="11">11</option>
      </select>&nbsp;&nbsp;&nbsp;

      <label for="height_fraction_inches">Fractions of an inch</label>
      <select name="height_fraction_inches" id="height_fraction_inches">
         <option value="0">0</option>
         <option value="0.125">1/8</option>
         <option value="0.25">1/4</option>
         <option value="0.375">3/8</option>
         <option value="0.5">1/2</option>
         <option value="0.625">5/8</option>
         <option value="0.75">3/4</option>
         <option value="0.875">7/8</option>
      </select>

      <p>(12 inches = 1 foot; Example: 4 feet, 5 1/2 inches)</p>
    </div>



    <div id="linebreak_eng" class="linebreak"></div>

    <div class="radio_buttons" id="radio_en_weight_direct_or_drop">
      <div class="inline_blk">
        <input checked type="radio" id="weight_eng_direct" name="weight_eng_direct_or_drop" value="weight_eng_direct">
        <label for="weight_eng_direct">Weight: Lbs</label>&nbsp;&nbsp;&nbsp;&nbsp;
      </div>
      <div class="inline_blk">
        <input type="radio" id="weight_eng_drop" name="weight_eng_direct_or_drop" value="weight_eng_drop">
        <label for="weight_eng_drop">Weight: Lbs, Fraction</label>
      </div>
    </div>

    <div id="div_weight_eng_direct">
       <p><b>Weight</b> (decimal places allowed): <span class="form_err" id="weight_check_eng_direct"> Select Weight</span></p>
       <div class="inline_blk">
        <input type="text" pattern="[0-9]" maxlength="5" name="weight_lbs_direct" id="weight_lbs_direct">
        <label for="weight_lbs_direct">lbs</label>&nbsp;&nbsp;&nbsp;
      </div>
    </div>

    <div id="div_weight_eng">
      <p><b>Weight</b>, to nearest 1/4 (.25) pound: <span class="form_err" id="weight_check_eng"> Select Weight</span></p>

      <div class="inline_blk">
        <input type="text" pattern="[0-9]" maxlength="3" name="weight_pounds" id="weight_pounds">
        <label for="weight_pounds">pounds</label>&nbsp;&nbsp;&nbsp;
      </div>

      <div class="inline_blk">
        <select name="weight_fractions_pounds" id="weight_fractions_pounds">
         <option value="0">0</option>
         <option value="0.125">1/8</option>
         <option value="0.25">1/4</option>
         <option value="0.375">3/8</option>
         <option value="0.5">1/2</option>
         <option value="0.625">5/8</option>
         <option value="0.75">3/4</option>
         <option value="0.875">7/8</option>
        </select>
        <label for="weight_fractions_pounds">fractions of a pound</label>
      </div>
      <p>(8 ounces = 1/2 pounds; Example: 75 3/4 pounds)</p>
    </div>


    <!-- ######### METRIC ######### -->


    <div id="div_height_metr">
      <p><b>Height</b> (decimal places allowed): <span class="form_err" id="height_check_metr"> Select Height</span></p>

      <input type="text" pattern="[0-9]" maxlength="5" name="heght_cm" id="height_cm">
      <label for="height_cm">cm</label>

    </div>

    <div class="linebreak"></div>

    <div id="div_weight_metr">
      <p><b>Weight</b> (decimal places allowed): <span class="form_err" id="weight_check_metr"> Select Weight</span></p>

      <input type="text" pattern="[0-9]" maxlength="5" name="weight_kg" id="weight_kg">
      <label for="weight_kg">kg</label>
      <p></p>
    </div>

    <div>
      <button id="button_calculate" type="button" class="btn btn-primary">Calculate</button>
    </div>

    <!-- ######################## ./FORM ######################## -->

</div><!-- ./calculator_form_wrapper -->

