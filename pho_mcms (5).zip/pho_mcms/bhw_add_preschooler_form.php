<?php
include('bhw_add_preschooler_script.php');
include('bhw_header.php');
?>
<body>
    <div class="w3-container" style="width: 1100px; margin-left: 236px; margin-top: 40px;">
      <div class="card">
        <div class="card-body">
          <form name="basicform" id="basicform" method="post" action="bhw_add_preschooler_script.php" oninput="bmi.value = (weight.valueAsNumber/height.valueAsNumber/height.valueAsNumber)*10000" enctype="multipart/form-data">
          <div id="sf1" class="frm">
            <fieldset>
              <legend>PERSONAL INFORMATION</legend>
              <div class="w3-row-padding">
                <div class="w3-third">
                  <p class="w3-tiny">FIRST NAME:
                    <input type="text" name="pre_fname" class="w3-input w3-border w3-tiny" placeholder="Enter your first name...">
                  </p>
                </div>
                <div class="w3-third">
                  <p class="w3-tiny">MIDDLE NAME:
                    <input type="text" name="pre_mname" class="w3-input w3-border w3-tiny" placeholder="Enter your middle name...">
                  </p>
                </div>
                <div class="w3-third">
                  <p class="w3-tiny">LAST NAME:
                    <input type="text" name="pre_lname" class="w3-input w3-border w3-tiny" placeholder="Enter your last name...">
                  </p>
                </div>
                <div class="w3-third">
                  <p class="w3-tiny">BIRTHDATE:
                     <input type="text" name="pre_bdate" id="date" class="w3-input w3-border w3-tiny" placeholder="Date of birth...">
                  </p>
                </div>
                <div class="w3-third">
                  <p class="w3-tiny">AGE: (Years | Months | Days)
                    <input type="text" class="w3-input w3-border w3-tiny" style="width: 90px; " name="age_in_years">
                    <input type="text" class="w3-input w3-border w3-tiny" style="width: 90px; margin-top: -33px; margin-left: 111px;" name="age_in_months">
                    <input type="text" class="w3-input w3-border w3-tiny" style="width: 90px; margin-top: -33px; margin-left: 222px;" name="age_in_days">
                  </p>
                </div>
                <div class="w3-third">
                  <p class="w3-tiny">GENDER:
                    <select class="w3-select w3-input w3-border w3-tiny" name="pre_gender">
                      <option style="background-color: gray;">Choose</option>
                      <option value="male">Male</option>
                      <option value="female">Female</option>
                    </select>
                  </p>
                </div>
                <div class="w3-third">
                  <p class="w3-tiny">PUROK:
                    <input type="text" name="pre_purok" class="w3-input w3-border w3-tiny" placeholder="Enter purok...">
                  </p>
                </div>
                <div class="w3-third">
                  <p class="w3-tiny">Municipal:
                    <select onChange="getbarangay(this.value);" name="mun_id" id="municipality" class="w3-input w3-border w3-tiny">
                      <option>Choose</option>
                        <?php
                          $query3 = mysqli_query($conn, "SELECT * FROM municipality");
                          while($municipality = mysqli_fetch_array($query3)){
                          echo "<option value='".$municipality['mun_id']."'>".ucwords($municipality["muncipality_name"])."</option>";
                          } 
                        ?>    
                    </select>
                  </p>
                </div>
                <div class="w3-third">
                  <p class="w3-tiny">Barangay:
                    <select name="bar_id" id="district-list" class="w3-input w3-border w3-tiny">
                      <option value ="bar_id">Choose</option>
                    </select>
                  </p>
                </div>
                <div class="w3-third">
                  <p class="w3-tiny">NATIONALITY:
                    <input type="text" name="pre_nationality" class="w3-input w3-border w3-tiny" placeholder="Enter your nationality...">
                  </p>
                </div>
                <div class="w3-third">
                  <p class="w3-tiny">RELIGION:
                    <input type="text" name="pre_religion" class="w3-input w3-border w3-tiny" placeholder="Enter your religion...">
                  </p>
                </div>
              </div>
              <br>
              <button class="w3-button w3-blue  w3-round-xxlarge open1" type="button">N E X T <span class="fa fa-arrow-right"></span></button>
            </fieldset>
          </div>

          <div id="sf2" class="frm" style="display: none;">
            <fieldset>
              <legend>PHYSICAL INFORMATION</legend>
              <div class="w3-row-padding">
                <div class="w3-third">
                  <p class="w3-tiny">WEIGHT (kg):
                    <input type="number" id="weight" min="0" name="weight" class="w3-input w3-tiny w3-border" placeholder="Enter weight...">
                  </p>
                </div>
                <div class="w3-third">
                  <p class="w3-tiny">HEIGHT (m):
                    <input type="number" min="0" id="height" name="height" class="w3-input w3-tiny w3-border" min="0" step="any" placeholder="Enter height...">
                  </p>
                </div>
                <div class="w3-third">
                  <p class="w3-tiny">BMI:
                    <input type="number" id="bmi" class="w3-input w3-tiny w3-border"  name="bmi" min="0" step="any" placeholder="Calculated bmi...">
                  </p>
                </div>
              </div>
              <br>
              <button class="w3-button w3-gray  w3-round-xxlarge back2" type="button"><span class="fa fa-arrow-left"></span> B A C K</button> 
              <button class="w3-button w3-blue  w3-round-xxlarge open2" type="button">N E X T<span class="fa fa-arrow-right"></span></button> 
            </fieldset>
          </div>

          <div id="sf3" class="frm" style="display: none;">
            <fieldset>
              <legend>PARENT INFORMATION</legend>
              <div class="w3-row-padding">
                <div class="w3-half">
                  <p class="w3-tiny">FATHER'S NAME:
                    <input type="text" name="f_name" class="w3-input w3-border w3-tiny" placeholder="Father's Name...">
                  </p>
                </div>
                <div class="w3-half">
                  <p class="w3-tiny">OCCUPATION:
                    <input type="text" name="f_occupation" class="w3-input w3-border w3-tiny" placeholder="Father's Occupation...">
                  </p>
                </div>
                <div class="w3-half">
                  <p class="w3-tiny">MOTHER'S NAME:
                    <input type="text" name="m_name" class="w3-input w3-border w3-tiny" placeholder="Mother's name...">
                  </p>
                </div>
                <div class="w3-half">
                  <p class="w3-tiny">OCCUPATION:
                    <input type="text" name="m_occupation" class="w3-input w3-border w3-tiny" placeholder="Mother's Occupation...">
                  </p>
                </div>
                <div class="w3-half">
                  <p class="w3-tiny">ANNUAL INCOME OF THE FAMILY:
                    <input type="text" name="annual_income" class="w3-input w3-border w3-tiny" placeholder="Annual Income...">
                  </p>
                </div>
              </div>
              <br>
              <button class="w3-button w3-gray  w3-round-xxlarge back3" type="button"><span class="fa fa-arrow-left"></span>B A C K</button> 
              <input type="submit" name="addPreschooler" class="w3-button w3-round-xxlarge w3-blue" value="Submit">
            </fieldset>
          </div>
        </form>
      </div>
    </div>
  </div>
</body>
<script type="text/javascript" src="../pho_mcms/js/jquery.min.js"></script>
<script>
function getbarangay(val) {
  $.ajax({
  type: "POST",
  url: "get_barangay.php",
  data:'mun_id='+val,
  success: function(data){
    $("#district-list").html(data);
  }
  });
}
function selectCountry(val) {
$("#search-box").val(val);
$("#suggesstion-box").hide();
}
</script> 


<script type="text/javascript" src="../pho_mcms/js/jquery.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
  $('#date').on('mouseout',function(){
    getAge($(this).val());
  });

});
function getAge(dateString) {
  if(dateString!==''){
    d1 = new Date();
    d2 = new Date(dateString);
    diff = new Date(
        d1.getFullYear()-d2.getFullYear(), 
        d1.getMonth()-d2.getMonth(), 
        d1.getDate()-d2.getDate()
    );
    
    $('input[name="age_in_years"]').val(diff.getYear()+" Year(s)");
    $('input[name="age_in_months"]').val(diff.getMonth()+" Month(s)");
    $('input[name="age_in_days"]').val(diff.getDate()+" Day(s)");
  }
}
</script>

<script src="../pho_mcms/js/jquery-1.11.1.js" type="text/javascript"></script>
<script src="../pho_mcms/js/bootstrap.min.js" type="text/javascript"></script>
<script src="../pho_mcms/js/jquery-ui-1.10.1.custom.min.js"></script>
<script>
$(function () {
    $('#date').datepicker({
      onSelect: function(value, ui) {
      var today = new Date(),
        dob = new Date(value),
        age = new Date(today - dob).getFullYear() - 1970;

      $('#age').val(age);
      
      },
    maxDate: '+0d',
    yearRange: '1900:2014',
    changeMonth: true,
    changeYear: true
  });
});
</script>

<script type="text/javascript" src="js/jquery.validate.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript">
  jQuery().ready(function() {

    // validate form on keyup and submit
    var v = jQuery("#basicform").validate({
      rules: {
        name: {
          required: true,
          minlength: 5,
          maxlength: 100
        }

      },
      errorElement: "span",
      errorClass: "help-inline-error",
    });

    $(".open1").click(function() {
      if (v.form()) {
        $(".frm").hide("fast");
        $("#sf2").show("slow");
      }
    });

    $(".open2").click(function() {
      if (v.form()) {
        $(".frm").hide("fast");
        $("#sf3").show("slow");
      }
    });

     $(".open3").click(function() {
      if (v.form()) {
        $(".frm").hide("fast");
        $("#sf4").show("slow");
      }
    });
    
    $(".open4").click(function() {
      if (v.form()) {
        $("#loader").show();
         setTimeout(function(){
           $("#basicform").html('<h2>Thanks for your time.</h2>');
         }, 1000);
        return false;
      }
    });
    
    $(".back2").click(function() {
      $(".frm").hide("fast");
      $("#sf1").show("slow");
    });

    $(".back3").click(function() {
      $(".frm").hide("fast");
      $("#sf2").show("slow");
    });
  
  $(".back4").click(function() {
      $(".frm").hide("fast");
      $("#sf3").show("slow");
    });
  
  $(".back5").click(function() {
      $(".frm").hide("fast");
      $("#sf4").show("slow");
    });

    $(".back6").click(function() {
      $(".frm").hide("fast");
      $("#sf5").show("slow");
    });
  
 });
</script>