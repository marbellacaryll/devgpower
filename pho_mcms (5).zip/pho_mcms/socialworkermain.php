<?php 
include("connection.php");
include("headersw.php");
?>
<?
$username=$_SESSION['username'];
$query=mysqli_query($conn, "SELECT * FROM user_access WHERE username='{$username}'");
$row=mysqli_fetch_array($query);
$user_id=$row['user_id'];

?>


<!-- Fixed navbar -->
<body>

<div id="malnourish_children_result" class="w3-tiny w3-card" style="padding: 30px; width: 1065px; margin-left: 265px; margin-top: 8px;">
			<!--<div class="w3-card" style="width: 1000px; margin-left: 295px; margin-top: 100px; padding: 20px; height: 500px;"><-->
				<!--<div class="w3-card-body"><-->
					<table id="myTable" class="w3-table table-bordered w3-tiny table-hover">
	

		<table class="table table-bordered" >
			<tr>
				<th>Municipal</th>
				<th>Status</th>
			
				
			</tr>

			<?php
			 	$query = mysqli_query($conn, "SELECT * FROM municipality");
			 	while($cli = mysqli_fetch_array($query)){
			 		
			 	

			 		echo "
			 			<tr>
			 				<td><span class='glyphicon glyphicon-user'></span><b><a href = 'sw_view_barangay.php?mun_id=".$cli['mun_id']."' style ='text-decoration:none; color:Green;'> ".ucwords($cli['muncipality_name']  )."</a></td>
			 				
			 				
			 				<td>
			 			</tr>
			 		";
			 	}
			?>
		</table><br>
	</div>
</div>

</body>
</html>
<script src="js/jquery-1.11.1.js"></script>
<script src="js/bootstrap.min.js"></script>
