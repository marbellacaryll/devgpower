
<input type="date" name="birthday"><br/><br/>
<input type="text" name="Years"><br>
<input type="text" name="m"><br>
<input type="text" name="d"><br>
<script type="text/javascript">
  $(document).ready(function(){
  $('input[type="date"]').on('mouseout',function(){
    getAge($(this).val());
  });

});
function getAge(dateString) {
  if(dateString!==''){
    d1 = new Date();
    d2 = new Date(dateString);
    diff = new Date(
        d1.getFullYear()-d2.getFullYear(), 
        d1.getMonth()-d2.getMonth(), 
        d1.getDate()-d2.getDate()
    );
    
    $('input[name="Years"]').val(diff.getYear()+" Year(s)");
    $('input[name="m"]').val(diff.getMonth()+" Month(s)");
    $('input[name="d"]').val(diff.getDate()+" Day(s)");
  }
}
</script>