<?php
include('connection.php');

?>
<?php
if(isset($_POST['sbt-deactivate'])){
 
   $id=$_GET['user_acc_id'];
   $deactivate="Inactive";

  $query = mysqli_query($conn, "UPDATE user_access SET status = '{$deactivate}' WHERE user_acc_id = '{$id}'");
  header('location:approve_account.php?mes=Updated!');
}
  

if(isset($_POST['sbt-activate'])){
  
   $id=$_GET['user_acc_id'];
   $activate="Active";
  
  $query = mysqli_query($conn, "UPDATE user_access SET status = '{$activate}' WHERE user_acc_id = '{$id}'");
  header('location:approve_account.php?mes=Updated!');
}



?>
<table border="1" ">
			
				<tr>
					<th><div style="color:Black ;">firstname</div></th>
					<th><div style="color:Black ;">position</div></th>
					<th><div style="Color:Black ;">municipality</div></th>
					<th><div style="color:Black ;">email</div></th>
					<th><div style="color:Black ;">username</div></th>
					<th><div style="color:Black ;">password</div></th>
				</tr>

				<?php
				$query=mysqli_query($conn, "SELECT * FROM user_access WHERE level=1");
				while($ownAcc = mysqli_fetch_array($query)){
					$user_acc_id = $ownAcc['user_acc_id'];
			 		$userId = $ownAcc['user_id'];
					$query_for_users = mysqli_query($conn, "SELECT * FROM users WHERE user_id='{$userId}'");
					$users = mysqli_fetch_array($query_for_users);
				echo "
				<tr> <form action='approve_account.php?user_acc_id=$user_acc_id' method = 'POST' >
				<td>".$users['firstname']."</td>
				<td>".$users['position']."</td>
				<td>".$users['municipality']."</td>
				<td>".$users['email']."</td>
				<td>".$ownAcc['username']."</td>
				<td>".$ownAcc['password']."</td>
			
				";
if($ownAcc['status'] == 'Active'){
              echo "<td><button type='submit' name='sbt-deactivate' style='color:red'>DEACTIVATE</button></td>";
            }else{
              echo "<td><button type='submit' name='sbt-activate'  style='color:blue'>ACTIVATE</button></td>
             ";

            }
            echo "</form></tr>";
			}
				?>
				</table>