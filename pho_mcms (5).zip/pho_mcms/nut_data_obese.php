<?php


	$dbHost = "localhost";
	$dbDatabase = "mcmsdb";
	$dbUser = "root";
	$dbPasswrod = "";
	


	$conn = mysqli_connect($dbHost, $dbUser, $dbPasswrod, $dbDatabase);
	
// populating graph by obese
$query1 = "SELECT physical_info.bar_id,SUM( health_status = 'This is considered as  Obese') AS children FROM physical_info JOIN sw_approval ON physical_info.bar_id = sw_approval.bar_id AND status=1 GROUP BY bar_id";

$result1 = mysqli_query($conn, $query1);
$json1 = [];
	while($row1 = mysqli_fetch_assoc($result1))
   		 {
      		  $bar_id = $row1['bar_id'];
      		  $children = $row1['children'];

        	 $json1[] =[(int)$bar_id, (int)$children];
  		  }
	
	echo json_encode($json1);

?>




