<?php

session_start();
include("connection.php");
?>

<?php
$username=$_SESSION['username'];
$query=mysqli_query($conn, "SELECT * FROM user_access WHERE username='{$username}'");
$row=mysqli_fetch_array($query);
$user_id=$row['user_id'];


if (isset($_REQUEST['addPreschooler'])) {
  
  $pre_fname=$_REQUEST['pre_fname'];
  $pre_mname=$_REQUEST['pre_mname'];
  $pre_lname=$_REQUEST['pre_lname'];
  $pre_bdate=$_REQUEST['pre_bdate'];
  $age_in_years=$_REQUEST['age_in_years'];
  $age_in_months=$_REQUEST['age_in_months'];
  $age_in_days=$_REQUEST['age_in_days'];
  $pre_gender=$_REQUEST['pre_gender'];
  $pre_purok=$_REQUEST['pre_purok'];
  $mun_id=$_REQUEST['mun_id'];
  $bar_id=$_REQUEST['bar_id'];
  $pre_nationality=$_REQUEST['pre_nationality'];
  $pre_religion=$_REQUEST['pre_religion'];

  $weight=$_REQUEST['weight'];
  $height=$_REQUEST['height'];
  $bmi=$_REQUEST['bmi'];

  $f_name=$_REQUEST['f_name'];
  $f_occupation=$_REQUEST['f_occupation'];
  $m_name=$_REQUEST['m_name'];
  $m_occupation=$_REQUEST['m_occupation'];
  $annual_income=$_REQUEST['annual_income'];

$conn="This is considered as ";


if ($bmi<16.5) {
  $health_status="$conn Severly Underweight";
  echo '<script type="text/javascript">alert("Your body mass Index is '.$bmi.''.$health_status.'");</script>';
  echo("<script>window.location='bhw_add_preschooler_form.php';</script>");
}
elseif ($bmi>=16.5 && $bmi<18.5) {
  $health_status="$conn Underweight";
  echo '<script type="text/javascript">alert("Your body mass Index is '.$bmi.''.$health_status.'");</script>';
  echo("<script>window.location='bhw_add_preschooler_form.php';</script>");
}
elseif ($bmi>=18.5&&$bmi<25) {
  $health_status="$conn Normal";

  echo '<script type="text/javascript">alert("Your body mass Index is '.$bmi.' '.$health_status.'");</script>';
  echo("<script>window.location='bhw_add_preschooler_form.php';</script>");
}
elseif ($bmi>=25&&$bmi<100) {
  $health_status="$conn Obese";
  echo '<script type="text/javascript">alert("Your body mass Index is '.$bmi.''.$health_status.'");</script>';
  echo("<script>window.location='bhw_add_preschooler_form.php';</script>");
}else{
  $_SESSION['error']= "You input Wrong value";
}

 preschooler($pre_fname,$pre_mname,$pre_lname,$pre_bdate,$age_in_years, $age_in_months, $age_in_days, $pre_purok,$pre_gender,$mun_id,$bar_id,$pre_nationality,$pre_religion,$weight,$height,$bmi,$health_status, $weight_for_age, $height_for_age, $weight_for_height, $f_name,$f_occupation,$m_name,$m_occupation, $annual_income, $user_id);
}

function preschooler($pre_fname,$pre_mname,$pre_lname,$pre_bdate,$age_in_years, $age_in_months, $age_in_days, $pre_purok,$pre_gender,$mun_id,$bar_id,$pre_nationality,$pre_religion,$weight,$height,$bmi,$health_status, $weight_for_age, $height_for_age, $weight_for_height, $f_name,$f_occupation,$m_name,$m_occupation, $annual_income, $user_id){
  include('connection.php');

  $sql_preschooler=mysqli_query($conn,"INSERT INTO preschooler (pre_fname, pre_mname, pre_lname, pre_bdate, age_in_years, age_in_months, age_in_days, pre_purok, pre_gender, mun_id,bar_id, pre_nationality, pre_religion, user_id)
    VALUES('{$pre_fname}', '{$pre_mname}','{$pre_lname}', '{$pre_bdate}', '{$age_in_years}', '{$age_in_months}', '{$age_in_days}', '{$pre_purok}', '{$pre_gender}', '{$mun_id}','{$bar_id}', '{$pre_nationality}', '{$pre_religion}', '{$user_id}')");

  $x = mysqli_query($conn, "SELECT * FROM preschooler 
    ORDER BY pre_id 
    DESC");
          $preschooler = mysqli_fetch_array($x);
          $pre_id = $preschooler['pre_id'];

  $sql_preschooler=mysqli_query($conn,"INSERT INTO physical_info (pre_id, weight, height, bmi, health_status, weight_for_age, height_for_age, weight_for_height, bar_id, mun_id, user_id)
    VALUES('{$pre_id}','{$weight}', '{$height}', '{$bmi}', '{$health_status}', '{$weight_for_age}', '{$height_for_age}', '{$weight_for_height}', '{$bar_id}', '{$mun_id}', '{$user_id}')");


  $y = mysqli_query($conn, "SELECT * FROM preschooler 
    ORDER BY pre_id 
    DESC");
          $preschooler_parent = mysqli_fetch_array($y);
          $pre_id1 = $preschooler_parent['pre_id'];

  $sql_preschooler=mysqli_query($conn, "INSERT INTO parent_info (pre_id, f_name, f_occupation, m_name, m_occupation, user_id, annual_income)
    VALUES ('{$pre_id}','{$f_name}', '{$f_occupation}', '{$m_name}', '{$m_occupation}', '{$user_id}', '{$annual_income}')");

  if ($conn->query($sql_preschooler)===TRUE) {
    echo ". Your Body Mass Index is $bmi .";
}
}
//UPDATE PRESCHOOLER INFORMATION

//UPDATE PRESCHOOLER INFORMATION
if (isset($_POST['updatePreschooler'])) {
  $preschooler_id=$_GET['id'];

  $update_pre_fname=$_POST['update_pre_fname'];
  $update_pre_mname=$_POST['update_pre_mname'];
  $update_pre_lname=$_POST['update_pre_lname'];
  $update_pre_bdate=$_POST['update_pre_bdate'];
  $update_age_in_years=$_POST['update_age_in_years'];
  $update_age_in_months=$_POST['update_age_in_months'];
  $update_age_in_days=$_POST['update_age_in_days'];
  $update_pre_gender=$_POST['update_pre_gender'];
  $update_pre_purok=$_POST['update_pre_purok'];
  $update_mun_id=$_POST['update_mun_id'];
  $update_bar_id=$_POST['update_bar_id'];
  $update_pre_nationality=$_POST['update_pre_nationality'];
  $update_pre_religion=$_POST['update_pre_religion'];

  $update_weight=$_POST['update_weight'];
  $update_height=$_POST['update_height'];
  $update_bmi=$_POST['update_bmi'];

  $update_f_name=$_POST['update_f_name'];
  $update_fathers_occupation=$_POST['update_fathers_occupation'];
  $update_mothers_name=$_POST['update_mothers_name'];
  $update_mothers_occupation=$_POST['update_mothers_occupation'];


  update_preschooler($preschooler_id, $update_pre_fname, $update_pre_mname, $update_pre_lname, $update_pre_bdate, $update_age_in_years, $update_age_in_months, $update_age_in_days, $update_pre_gender, $update_pre_purok, $update_mun_id, $update_bar_id, $update_pre_nationality, $update_pre_religion, $update_weight, $update_height, $update_bmi, $update_f_name, $update_fathers_occupation, $update_mothers_name, $update_mothers_occupation);
}
function update_preschooler($preschooler_id, $update_pre_fname, $update_pre_mname, $update_pre_lname, $update_pre_bdate, $update_age_in_years, $update_age_in_months, $update_age_in_days, $update_pre_gender, $update_pre_purok, $update_mun_id, $update_bar_id, $update_pre_nationality, $update_pre_religion, $update_weight, $update_height, $update_bmi, $update_f_name, $update_fathers_occupation, $update_mothers_name, $update_mothers_occupation) {
  include('connection.php');
  
  $sql_update_preschooler="UPDATE preschooler 
  SET pre_fname='$update_pre_fname', pre_mname='$update_pre_mname', pre_lname='$update_pre_lname', pre_bdate='$update_pre_bdate', age_in_years='$update_age_in_years', age_in_months='$update_age_in_months', age_in_days='$update_age_in_days', pre_gender='$update_pre_gender', pre_purok='$update_pre_purok', mun_id='$update_mun_id', bar_id='$update_bar_id', pre_nationality='$update_pre_nationality', pre_religion='$update_pre_religion'
  WHERE pre_id=$preschooler_id"; 
  if ($conn->query($sql_update_preschooler) === TRUE) {
        header("Location:../pho_mcms/bhw_severly_underweight_list.php?msg='Successfully updated!'");
 
  $sql_update_preschooler="UPDATE physical_info 
  SET weight='$update_weight', height='$update_height', bmi='$update_bmi'
  WHERE pre_id='$preschooler_id'";

  if ($conn->query($sql_update_preschooler)===TRUE) {
    header("Location:../pho_mcms/bhw_severly_underweight_list.php?msg='Successfully updated!'");

  $sql_update_preschooler="UPDATE parent_info 
    SET f_name='$update_f_name', f_occupation='$update_fathers_occupation', m_name='$update_mothers_name', m_occupation='$update_mothers_occupation'
    WHERE pre_id='$preschooler_id'";

    if ($conn->query($sql_update_preschooler)===TRUE) {
      header("Location:../pho_mcms/bhw_severly_underweight_list.php?msg='Successfully updated!'");
    return $sql_update_preschooler;
  }
}

  $query2=mysqli_query($conn, "SELECT * FROM preschooler WHERE pre_id='{$pre_id}'");
  $pre=mysqli_fetch_array($query2);

  $query1=mysqli_query($conn, "SELECT * FROM physical_info WHERE phy_id='{$pre_id}");
  $row=mysqli_fetch_array($query1);

  $query3=mysqli_query($conn, "SELECT * FROM parent_info WHERE par_id='{$pre_id}");
  $row1=mysqli_fetch_array($query3);
  }



 //insert into social worker approval
      $query = mysqli_query($conn, "INSERT INTO `sw_approval` 
      (pre_id,bar_id,mun_id , status)
      VALUES ('{$pre_id}','{$bar_id}','{$mun_id}',0)");

      $xx = mysqli_query($conn, "SELECT * FROM sw_approval 
        ORDER BY app_id 
        DESC");
      $approval = mysqli_fetch_array($xx);
      $app_id = $approval['app_id'];

}
?>