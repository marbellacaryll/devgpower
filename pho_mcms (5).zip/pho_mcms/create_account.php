<link rel="stylesheet" type="text/css" href="../pho_mcms/css/w3.css">
<link rel="stylesheet" type="text/css" href="../pho_mcms/css/font_style.css">
<link rel="stylesheet" type="text/css" href="../pho_mcms/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../pho_mcms/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="../oshop/css/w3-colors-flat.css">
<link rel="stylesheet" type="text/css" href="../pho_mcms/css/jquery-ui-1.10.1.custom.min.css">
<?php
include('connection.php');

function CreateRandomPassword(){
	$chars="abcdefghijklmnopqrstuvwxyz0123456789";
	Srand((double)microtime()*1000000);
	$i=0;
	$pass='';

	while($i<10){
	$num=rand()% 35;
	$tmp=substr($chars,$num,1);
	$pass=$pass.$tmp;
	$i++;
}

	return $pass;
	}
	
	
if (isset($_POST['addAccount'])) {

	$firstname=$_POST['firstname'];
	$middlename=$_POST['middlename'];
	$lastname=$_POST['lastname'];
	$bdate=$_POST['bdate'];
	$age=$_POST['age'];
	$gender=$_POST['gender'];

	$email=$_POST['email'];
	$position=$_POST['position'];
	$municipality=$_POST['municipality'];
	

	$bar_id=$_POST['bar_id'];
	$username=$_POST['username'];
	$pass=CreateRandomPassword();

add_profile($firstname,$middlename,$lastname,$bdate,$age,$gender,$email,$position,$municipality,$username,$pass,$bar_id);
}

function add_profile($firstname,$middlename,$lastname,$bdate,$age,$gender,$email,$position,$municipality,$username,$pass,$bar_id){
  include('connection.php');
	if ($email && $username != "") {
		//$query = mysqli_query($conn, "SELECT `users.email`, `user_access.username` FROM users INNER JOIN user_access ON `users.user_id`=`user_access.user_acc_id`");
		$query1 = mysqli_query($conn, "SELECT * FROM users 
			WHERE email ='".$email."'");
		$query = mysqli_query($conn, "SELECT * FROM user_access 
			WHERE username ='".$username."'");

		$email_unique = mysqli_num_rows($query);
		$email_unique1 = mysqli_num_rows($query1);


		if ($email_unique>0) {
				echo "Username or email already Exist";
			
			}elseif ($email_unique1>0) {
				echo "Email already exist";
			}else{
				$query=mysqli_query($conn, "INSERT INTO users (firstname, middlename, lastname, bdate, age, gender, email, position, municipality)
					VALUES ('{$firstname}', '{$middlename}', '{$lastname}', '{$bdate}', '{$age}', '{$gender}', '{$email}','{$position}', '{$municipality}')");

				$x = mysqli_query($conn, "SELECT * FROM users 
					ORDER BY user_id 
					DESC");
          		$useracc = mysqli_fetch_array($x);
          		$user_id = $useracc['user_id'];
				$query=mysqli_query($conn,"INSERT INTO user_access (`user_id`, `level`, `mun_id`, `username`, `password`, `bar_id`) 
					VALUES ('{$user_id}', '{$position}','{$municipality}', '{$username}', '{$pass}', '{$bar_id}')");
				echo "User Account is pending for approval!";
			}
		}
	}

	//UPDATE PRESCHOOLER INFORMATION
if (isset($_POST['updateProfile'])) {
  $profile_id=$_GET['id'];

  $update_firstname=$_POST['update_firstname'];
  $update_middlename=$_POST['update_middlename'];
  $update_lastname=$_POST['update_lastname'];
  $update_bdate=$_POST['update_bdate'];
  $update_age=$_POST['update_age'];
  $update_gender=$_POST['update_gender'];
  $update_email=$_POST['update_email'];
  $update_position=$_POST['update_position'];
  $update_municipality=$_POST['update_municipality'];
  $update_username=$_POST['update_username'];
  $update_password=$_POST['update_password'];
  $update_bar_id=$_POST['update_bar_id'];


  update_profile($update_firstname,$update_middlename,$update_lastname,$update_bdate,$update_age,$update_gender,$update_email,$update_position,$update_municipality,$update_username,$update_password,$update_bar_id);
}
function update_profile($update_firstname,$update_middlename,$update_lastname,$update_bdate,$update_age,$update_gender,$update_email,$update_position,$update_municipality,$update_username,$update_password,$update_bar_id) {
  include('connection.php');
  
  $sql_update_profile="UPDATE users 
  SET firstname='$update_firstname', middlename='$update_middlename', lastname='$update_lastname', bdate='$update_bdate', age='$update_age', gender='$update_gender', email='$update_email', position='$update_position', municipality='$update_municipality'
  WHERE user_id='$profile_id'";
  if ($conn->query($sql_update_profile) === TRUE) {
        header("Location:../pho_mcms/register_account.php?msg='Successfully updated!'");
    return $sql_update_profile;
  }
  $update_profile_query=mysqli_query($conn, "SELECT * FROM users 
    WHERE user_id='{$user_id}'");
  $user=mysqli_fetch_array($update_profile_query);
  }

?>
