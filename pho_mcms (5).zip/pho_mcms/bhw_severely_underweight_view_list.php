<?php

session_start();
include("connection.php");
include('bhw_header.php');
?>

<?php
$username=$_SESSION['username'];
$query=mysqli_query($conn, "SELECT * FROM user_access WHERE username='{$username}'");
$row=mysqli_fetch_array($query);
$user_id=$row['user_id'];
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div class="w3-container" style="width: 1100px; margin-left: 236px; margin-top: -10px;">
		<div class="card">
			<div id="malnourish_children_result" class="card-body">
				<table id="myTable" class="w3-table w3-tiny table-bordered table-hover">
					<thead class="w3-tiny">
						<th>Name</th>
						<th>Weight</th>
						<th>Height</th>
						<th>BMI</th>
						<th>Health Status</th>
						<th>Date Updated</th>
						<th></th>
					</thead>
				</table>
			</div>
		</div>
	</div>
</body>
</html>