<?php


	$dbHost = "localhost";
	$dbDatabase = "mcmsdb";
	$dbUser = "root";
	$dbPasswrod = "";
	


	$conn = mysqli_connect($dbHost, $dbUser, $dbPasswrod, $dbDatabase);
	
// populating graph by obese children
$query1 = "SELECT bar_id ,SUM( health_status = 'This is considered as  Obese') AS children_one FROM  physical_info  GROUP BY bar_id";
$result1 = mysqli_query($conn, $query1);
$json1 = [];
	while($row1 = mysqli_fetch_assoc($result1))
   		 {
      		  $pre_id = $row1['bar_id'];
      		  $bar_id = $row1['children_one'];

        	 $json1[] =[(int)$pre_id, (int)$bar_id];
  		  }
	
	echo json_encode($json1);

?>




