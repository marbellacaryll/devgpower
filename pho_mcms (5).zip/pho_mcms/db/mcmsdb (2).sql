-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 10, 2018 at 03:48 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mcmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `addr_id` int(10) UNSIGNED NOT NULL,
  `pre_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `street` varchar(45) NOT NULL DEFAULT '',
  `barangay` varchar(45) NOT NULL DEFAULT '',
  `municipality` varchar(45) NOT NULL DEFAULT '',
  `province` varchar(45) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `albay_town`
--

CREATE TABLE `albay_town` (
  `idalbay_town` int(10) UNSIGNED NOT NULL,
  `pre_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `par_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `phy_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `nutri_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `tiwi` varchar(45) NOT NULL DEFAULT '',
  `malinao` varchar(45) NOT NULL DEFAULT '',
  `tabaco` varchar(45) NOT NULL DEFAULT '',
  `malilipot` varchar(45) NOT NULL DEFAULT '',
  `bacacay` varchar(45) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `barangay`
--

CREATE TABLE `barangay` (
  `bar_id` int(10) UNSIGNED NOT NULL,
  `mun_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `barangay_name` varchar(45) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barangay`
--

INSERT INTO `barangay` (`bar_id`, `mun_id`, `barangay_name`) VALUES
(1, 1, 'Barangay 1 (Pob.)'),
(2, 1, 'Barangay 2 (Pob.)'),
(3, 1, 'Barangay 3 (Pob.)'),
(4, 1, 'Barangay 4 (Pob.)'),
(5, 1, 'Barangay 5 (Pob.)'),
(6, 1, 'Barangay 6 (Pob.)'),
(7, 1, 'Barangay 7 (Pob.)'),
(8, 1, 'Barangay 8 (Pob.)'),
(9, 1, 'Barangay 9 (Pob.)'),
(10, 1, 'Barangay 10 (Pob.)'),
(11, 1, 'Barangay 11 (Pob.)'),
(12, 1, 'Barangay 12 (Pob.)'),
(13, 1, 'Barangay 13 (Pob.)'),
(14, 1, 'Barangay 14 (Pob.)'),
(15, 1, 'Baclayon'),
(16, 1, 'Bariw'),
(17, 1, 'Basud'),
(18, 1, 'Bayandong'),
(19, 1, 'Bonga (Upper)'),
(20, 1, 'Buang'),
(21, 1, 'Busdac (San Jose)'),
(22, 1, 'Cabasan'),
(23, 1, 'Cagbulacao'),
(24, 1, 'Cagraray'),
(25, 1, 'Cajogutan'),
(26, 1, 'Cawayan'),
(27, 1, 'Damacan'),
(28, 1, 'Gubat Ilawod'),
(29, 1, 'Gubat Iraya'),
(30, 1, 'Hindi'),
(31, 1, 'Igang'),
(32, 1, 'Langaton'),
(33, 1, 'Manaet'),
(34, 1, 'Mapulang Daga'),
(35, 1, 'Mataas'),
(36, 1, 'Misibis'),
(37, 1, 'Nahapunan'),
(38, 1, 'Namanday'),
(39, 1, 'Namantao'),
(40, 1, 'Napao'),
(41, 1, 'Panarayon'),
(42, 1, 'Pigcobohan'),
(43, 1, 'Pili Ilawod'),
(44, 1, 'Pili Iraya'),
(45, 1, 'Pongco (Lower Bonga)'),
(46, 1, 'San Pablo'),
(47, 1, 'San Pedro'),
(48, 1, 'Sogod'),
(49, 1, 'Sula'),
(50, 1, 'Tambilagao (Tambongon)'),
(51, 1, 'Tambongon (Tambilagao)'),
(52, 1, 'Tanagan'),
(53, 1, 'Uson'),
(54, 1, 'Vinisitahan-Basud (Mainland)'),
(55, 1, 'Vinisitahan-Napao (Island)'),
(56, 2, 'Anoling'),
(57, 2, 'Baligang'),
(58, 2, 'Bantonan'),
(59, 2, 'Barangay 1 (Pob.)'),
(60, 2, 'Barangay 2 (Pob.)'),
(61, 2, 'Barangay 3 (Pob.)'),
(62, 2, 'Barangay 4 (Pob.)'),
(63, 2, 'Barangay 5 (Pob.)'),
(64, 2, 'Barangay 6 (Pob.)'),
(65, 2, 'Barangay 7 (Pob.)'),
(66, 2, 'Bariw'),
(67, 2, 'Binanderahan'),
(68, 2, 'Binitayan'),
(69, 2, 'Bongabong'),
(70, 2, 'Cabagnan'),
(71, 2, 'Cabraran Pequeno'),
(72, 2, 'Cagiba'),
(73, 2, 'Calabidongan'),
(74, 2, 'Comun'),
(75, 2, 'Cotmon'),
(76, 2, 'Del Rosario'),
(77, 2, 'Gapo'),
(78, 2, 'Gotob'),
(79, 2, 'Ilawod'),
(80, 2, 'Iluluan'),
(81, 2, 'Libod'),
(82, 2, 'Ligban'),
(83, 2, 'Mabunga'),
(84, 2, 'Magogon'),
(85, 2, 'Manawan'),
(86, 2, 'Maninila'),
(87, 2, 'Mina'),
(88, 2, 'Miti'),
(89, 2, 'Palanog'),
(90, 2, 'Panoypoy'),
(91, 2, 'Pariaan'),
(92, 2, 'Quinartilan'),
(93, 2, 'Quirangay'),
(94, 2, 'Quitinday'),
(95, 2, 'Salogan'),
(96, 2, 'Solong'),
(97, 2, 'Sua'),
(98, 2, 'Sumlang'),
(99, 2, 'Tagaytay'),
(100, 2, 'Tagoytoy'),
(101, 2, 'Taladong'),
(102, 2, 'Taloto'),
(103, 2, 'Taplacon'),
(104, 2, 'Tinaco'),
(105, 2, 'Tumpa'),
(106, 3, 'Alcala'),
(107, 3, 'Alobo'),
(108, 3, 'Anislag'),
(109, 3, 'Bagumbayan'),
(110, 3, 'Balinad'),
(111, 3, 'Banadero'),
(112, 3, 'Banad'),
(113, 3, 'Biscaran'),
(114, 3, 'Bigao'),
(115, 3, 'Binitayan'),
(116, 3, 'Bongalon'),
(117, 3, 'Budiao'),
(118, 3, 'Burgos'),
(119, 3, 'Busay'),
(120, 3, 'Canaron'),
(121, 3, 'Cullat'),
(122, 3, 'Dela Paz'),
(123, 3, 'Dinoronan'),
(124, 3, 'Gabawan'),
(125, 3, 'Gapo'),
(126, 3, 'Ibaugan'),
(127, 3, 'Ilawod Area Pob (Dist.2)'),
(128, 3, 'Inarado'),
(129, 3, 'Kidaco'),
(130, 3, 'Kilicao'),
(131, 3, 'Kimantong'),
(132, 3, 'Kinawitan'),
(133, 3, 'Kiwalo'),
(134, 3, 'Lacag'),
(135, 3, 'Mabini'),
(136, 3, 'Malabog'),
(137, 3, 'Malobago'),
(138, 3, 'Maopi'),
(139, 3, 'Market Area Pob (Dist.1)'),
(140, 3, 'Maroroy'),
(141, 3, 'Matnog'),
(142, 3, 'Mayon'),
(143, 3, 'Mi-isi'),
(144, 3, 'Nabasan'),
(145, 3, 'Namantao'),
(146, 3, 'Pandan'),
(147, 3, 'Penafrancia'),
(148, 3, 'Sagpon'),
(149, 3, 'Salvacion'),
(150, 3, 'San Rafael'),
(151, 3, 'San Roque'),
(152, 3, 'San Ramon'),
(153, 3, 'San Vicente Grande'),
(154, 3, 'San Vicente Pequeno'),
(155, 3, 'Sipi'),
(156, 3, 'Tabon-Tabon'),
(157, 3, 'Tagas'),
(158, 3, 'Talahib'),
(159, 3, 'Villahermosa'),
(160, 4, 'Agpay'),
(161, 4, 'Balite'),
(162, 4, 'Banao'),
(163, 4, 'Batbat'),
(164, 4, 'Bingsocan Lower'),
(165, 4, 'Bingsocan Upper'),
(166, 4, 'Bololo'),
(167, 4, 'Bubulusan'),
(168, 4, 'Calzada'),
(169, 4, 'Cotomag'),
(170, 4, 'Dona Mercedes'),
(171, 4, 'Dona Tomasa (Magatol)'),
(172, 4, 'Ilawod'),
(173, 4, 'Inamnan Grande'),
(174, 4, 'Inamnan Pequeno'),
(175, 4, 'Inascan'),
(176, 4, 'Iraya'),
(177, 4, 'Lomacao'),
(178, 4, 'Maguiron'),
(179, 4, 'Maipon'),
(180, 4, 'Malabnig'),
(181, 4, 'Malipo'),
(182, 4, 'Malobago'),
(183, 4, 'Maninila'),
(184, 4, 'Mapaco'),
(185, 4, 'Marcial O. Ranola (Cabaloaon)'),
(186, 4, 'Masarawag'),
(187, 4, 'Mauraro'),
(188, 4, 'Minto'),
(189, 4, 'Morera'),
(190, 4, 'Muladbucad Grande'),
(191, 4, 'Muladbucad Pequeno'),
(192, 4, 'Ongo'),
(193, 4, 'Palanas'),
(194, 4, 'Poblacion'),
(195, 4, 'Pood'),
(196, 4, 'Quibongbongan'),
(197, 4, 'Quitago'),
(198, 4, 'San Francisco'),
(199, 4, 'San Jose (Ogsong)'),
(200, 4, 'San Rafael'),
(201, 4, 'Sinungtan'),
(202, 4, 'Tandarora'),
(203, 4, 'Traversia'),
(204, 5, 'Aurora Pob. (Brgy. 6)'),
(205, 5, 'Bagacay'),
(206, 5, 'Bautista'),
(207, 5, 'Cabraran'),
(208, 5, 'Calzada Pob. (Brgy. 7)'),
(209, 5, 'Del Rosario'),
(210, 5, 'Estrella'),
(211, 5, 'Florista'),
(212, 5, 'Mabini Pob. (Brgy. 2)'),
(213, 5, 'Magsaysay Pob. (Brgy. 4)'),
(214, 5, 'Mamlad'),
(215, 5, 'Maogob'),
(216, 5, 'Mercado Pob. (Brgy. 5)'),
(217, 5, 'Plaza Pob. (Brgy. 3)'),
(218, 5, 'Quitinday Pob. (Brgy. 8)'),
(219, 5, 'Rizal Pob. (Brgy. 1)'),
(220, 5, 'Salvacion'),
(221, 5, 'San Isidro'),
(222, 5, 'San Roque'),
(223, 5, 'San Vicente'),
(224, 5, 'Sinagaran'),
(225, 5, 'Villa Paz'),
(226, 5, 'White Deer Pob. (Brgy. 9)'),
(227, 6, 'Brgy. 10 - Cabugao'),
(228, 6, 'Brgy. 11 - Maoyod Pob. (Brgy. 10 & 11)'),
(229, 6, 'Brgy. 12 - Tula Tula Pob.'),
(230, 6, 'Brgy. 13 - Ilawod West Pob. (Ilawod 1)'),
(231, 6, 'Brgy. 14 - Ilawod Pob. (Ilawod 2)'),
(232, 6, 'Brgy. 15 - Ilawod East Pob. (Ilawod 3)'),
(233, 6, 'Brgy. 16 - Kawit - East Washington Drive (Pob'),
(234, 6, 'Brgy. 17 - Rizal Street'),
(235, 6, 'Brgy. 18 - Cabagnan West (Pob.)'),
(236, 6, 'Brgy. 19 - Cabagnan'),
(237, 6, 'Brgy. 20 - Cabgnan East (Pob.)'),
(238, 6, 'Brgy. 21 - Binanuahan West (Pob.)'),
(239, 6, 'Brgy. 22 - Binanuahan East (Pob.)'),
(240, 6, 'Brgy. 23 - Imperial Court Subd. (Pob.)'),
(241, 6, 'Brgy. 24 - Rizal St.'),
(242, 6, 'Brgy. 25 - Lapu - Lapu (Pob.)'),
(243, 6, 'Brgy. 26 - Dinagaan (Pob.)'),
(244, 6, 'Brgy. 27 - Victory Village South (Pob.)'),
(245, 6, 'Brgy. 28 - Victory Village North (Pob.)'),
(246, 6, 'Brgy. 29 - Sabang (Pob.)'),
(247, 6, 'Brgy. 30 - Pigcale (Pob.)'),
(248, 6, 'Brgy. 31 - Centro - Baybay (Pob.)'),
(249, 6, 'Brgy. 32 - San Roque (Brgy. 66)'),
(250, 6, 'Brgy. 33 - Pnr - Penaranda St. - Iraya (Pob.)'),
(251, 6, 'Brgy. 34 - Oro Site - Magallanes St. (Pob.)'),
(252, 6, 'Brgy. 35 - Tinago (Pob.)'),
(253, 6, 'Brgy. 36 - Kapantawan (Pob.)'),
(254, 6, 'Brgy. 37 - Bitano (Pob.)'),
(255, 6, 'Brgy. 38 - Gogon (Brgy. 54)'),
(256, 6, 'Brgy. 39 - Bonot (Pob.)'),
(257, 6, 'Brgy. 4 - Sagpon Pob. (Sagpon 1)'),
(258, 6, 'Brgy. 40 - Cruzada (Brgy. 52)'),
(259, 6, 'Brgy. 41 - Bogtong (Brgy. 45)'),
(260, 6, 'Brgy. 42 - Rawis (Brgy. 65)'),
(261, 6, 'Brgy. 43 - Tamaoyan (Brgy. 67)'),
(262, 6, 'Brgy. 44 - Pawa (Brgy. 61)'),
(263, 6, 'Brgy. 45 - Dita (Brgy. 51)'),
(264, 6, 'Brgy. 46 - San Joaquin (Brgy. 64)'),
(265, 6, 'Brgy. 47 - Arimbay'),
(266, 6, 'Brgy. 48 - Bagong Abre (Brgy. 42)'),
(267, 6, 'Brgy. 49 - Bigaa (Brgy. 44)'),
(268, 6, 'Brgy. 5 - Sagmin Pob. (Sagpon 2)'),
(269, 6, 'Brgy. 50 - Padang (Brgy. 60)'),
(270, 6, 'Brgy. 51 - Buyuan (Brgy. 49)'),
(271, 6, 'Brgy. 52 - Matanag'),
(272, 6, 'Brgy. 53 - Bonga (Brgy. 48)'),
(273, 6, 'Brgy. 54 - Mabinit (Brgy. 59)'),
(274, 6, 'Brgy. 55 - Estanza (Brgy. 53)'),
(275, 6, 'Brgy. 56 - Taysan (Brgy. 68)'),
(276, 6, 'Brgy. 57 - Dap-Dap (Brgy. 69)'),
(277, 6, 'Brgy. 58 - Buragwis'),
(278, 6, 'Brgy. 59 - Puro (Brgy. 63)'),
(279, 6, 'Brgy. 6 - Banadero Pob. (Sagpon 3)'),
(280, 6, 'Brgy. 60 - Lamba'),
(281, 6, 'Brgy. 61 - Maslog (Brgy. 58)'),
(282, 6, 'Brgy. 62 - Homapon (Brgy. 55)'),
(283, 6, 'Brgy. 63 - Mariawa (Brgy. 56)'),
(284, 6, 'Brgy. 64 - Bagacay (Brgy. 41 Bagacay)'),
(285, 6, 'Brgy. 65 - Imalnod (Brgy. 57)'),
(286, 6, 'Brgy. 66 - Banquerohan (Brgy. 43)'),
(287, 6, 'Brgy. 67 - Bariis (Brgy. 46)'),
(288, 6, 'Brgy. 68 - San Francisco (Brgy. 62)'),
(289, 6, 'Brgy. 69 - Buenavista (Brgy. 47)'),
(290, 6, 'Brgy. 7 - Bano (Pob.)'),
(291, 6, 'Brgy. 70 - Cagbacong (Brgy. 50)'),
(292, 6, 'Brgy. 8 - Bagumbayan (Pob.)'),
(293, 6, 'Brgy. 9 - Pinaric (Pob.)'),
(294, 7, 'Alongong'),
(295, 7, 'Apud'),
(296, 7, 'Bacolod'),
(297, 7, 'Bariw'),
(298, 7, 'Bonbon'),
(299, 7, 'Buga'),
(300, 7, 'Bulusan'),
(301, 7, 'Burabod'),
(302, 7, 'Caguscos'),
(303, 7, 'East Carisac'),
(304, 7, 'Harigue'),
(305, 7, 'Libtong'),
(306, 7, 'Linao'),
(307, 7, 'Mabayawas'),
(308, 7, 'Macabugos'),
(309, 7, 'Magallang'),
(310, 7, 'Malabiga'),
(311, 7, 'Marayag'),
(312, 7, 'Matara'),
(313, 7, 'Molosbolos'),
(314, 7, 'Natasan'),
(315, 7, 'Nino Jesus (Santo Nino Jesus)'),
(316, 7, 'Nogpo'),
(317, 7, 'Pantao'),
(318, 7, 'Rawis'),
(319, 7, 'Sagrada Familia'),
(320, 7, 'Salvacion'),
(321, 7, 'Sampongan'),
(322, 7, 'San Agustin'),
(323, 7, 'San Antonio'),
(324, 7, 'San Isidro'),
(325, 7, 'San Jose'),
(326, 7, 'San Pascual'),
(327, 7, 'San Ramon'),
(328, 7, 'San Vicente'),
(329, 7, 'Santa Cruz'),
(330, 7, 'Talin - Talin'),
(331, 7, 'Tambo'),
(332, 7, 'Villa Petrona'),
(333, 7, 'West Carisac'),
(334, 7, 'Zone I (Pob.)'),
(335, 7, 'Zone II (Pob.)'),
(336, 7, 'Zone III (Pob.)'),
(337, 7, 'Zone IV (Pob.)'),
(338, 7, 'Zone V (Pob.)'),
(339, 7, 'Zone VI (Pob.)'),
(340, 7, 'Zone VII (Pob.)'),
(341, 8, 'Abella'),
(342, 8, 'Allang'),
(343, 8, 'Amtic'),
(344, 8, 'Bacong'),
(345, 8, 'Bagumbayan'),
(346, 8, 'Balanac'),
(347, 8, 'Baligang'),
(348, 8, 'Barayong'),
(349, 8, 'Basag'),
(350, 8, 'Batang'),
(351, 8, 'Bay'),
(352, 8, 'Binanowan'),
(353, 8, 'Binatagan (Pob.)'),
(354, 8, 'Bobonsuran'),
(355, 8, 'Bonga'),
(356, 8, 'Busac'),
(357, 8, 'Busay'),
(358, 8, 'Cabarian'),
(359, 8, 'Calzada (Pob.)'),
(360, 8, 'Catburawan'),
(361, 8, 'Cavasi'),
(362, 8, 'Culliat'),
(363, 8, 'Dunao'),
(364, 8, 'Francia'),
(365, 8, 'Guilid'),
(366, 8, 'Herrera'),
(367, 8, 'Layon'),
(368, 8, 'Macalidong'),
(369, 8, 'Mahaba'),
(370, 8, 'Malamo'),
(371, 8, 'Maonon'),
(372, 8, 'Nabonton'),
(373, 8, 'Nasisi'),
(374, 8, 'Oma - Oma'),
(375, 8, 'Palapas'),
(376, 8, 'Pandan'),
(377, 8, 'Paulba'),
(378, 8, 'Paulog'),
(379, 8, 'Pinamaniquian'),
(380, 8, 'Pinit'),
(381, 8, 'Ranao - Ranao'),
(382, 8, 'San Vicente'),
(383, 8, 'Santa Cruz (Pob.)'),
(384, 8, 'Tagpo'),
(385, 8, 'Tambo'),
(386, 8, 'Tandarora'),
(387, 8, 'Tastas'),
(388, 8, 'Tinago'),
(389, 8, 'Tinampo'),
(390, 8, 'Tiongson'),
(391, 8, 'Tomolin'),
(392, 8, 'Tuburan'),
(393, 8, 'Tula - Tula Grande'),
(394, 8, 'Tula - Tula Pequeno'),
(395, 8, 'Tupas'),
(396, 9, 'Barangay 1 (Pob.)'),
(397, 9, 'Barangay 2 (Pob.)'),
(398, 9, 'Barangay 3 (Pob.)'),
(399, 9, 'Barangay 4 (Pob.)'),
(400, 9, 'Barangay 5 (Pob.)'),
(401, 9, 'Binitayan'),
(402, 9, 'Calbayog'),
(403, 9, 'Canaway'),
(404, 9, 'Salvacion'),
(405, 9, 'San Antonio Santicon (Pob.)'),
(406, 9, 'San Antonio Sulong'),
(407, 9, 'San Francisco'),
(408, 9, 'San Isidro (Ilawod)'),
(409, 9, 'San Isidro (Iraya)'),
(410, 9, 'San Jose'),
(411, 9, 'San Roque'),
(412, 9, 'Santa Cruz'),
(413, 9, 'Santa Teresa'),
(414, 10, 'Awang'),
(415, 10, 'Bagatangki'),
(416, 10, 'Bagumbayan'),
(417, 10, 'Balading'),
(418, 10, 'Balza'),
(419, 10, 'Bariw'),
(420, 10, 'Baybay'),
(421, 10, 'Bulang'),
(422, 10, 'Burabod'),
(423, 10, 'Cabunturan'),
(424, 10, 'Comun'),
(425, 10, 'Diaro'),
(426, 10, 'Estancia'),
(427, 10, 'Jonop'),
(428, 10, 'Labnig'),
(429, 10, 'Libod'),
(430, 10, 'Malolos'),
(431, 10, 'Matalipni'),
(432, 10, 'Ogob'),
(433, 10, 'Pawa'),
(434, 10, 'Payahan'),
(435, 10, 'Poblacion'),
(436, 10, 'Quinarabasahan'),
(437, 10, 'Santa Elena'),
(438, 10, 'Soa'),
(439, 10, 'Sugcad'),
(440, 10, 'Tagoytoy'),
(441, 10, 'Tunawan'),
(442, 10, 'Tuliw'),
(443, 11, 'Balabagon'),
(444, 11, 'Balasbas'),
(445, 11, 'Bamban'),
(446, 11, 'Buyo'),
(447, 11, 'Cabacongan'),
(448, 11, 'Cabit'),
(449, 11, 'Cawayan'),
(450, 11, 'Cawit'),
(451, 11, 'Holugan'),
(452, 11, 'It-Ba (Pob.)'),
(453, 11, 'Malobago'),
(454, 11, 'Manumbalay'),
(455, 12, 'Badbad'),
(456, 12, 'Badian'),
(457, 12, 'Bagsa'),
(458, 12, 'Bagumbayan'),
(459, 12, 'Balogo'),
(460, 12, 'Banao'),
(461, 12, 'Bangiawon'),
(462, 12, 'Bogtong'),
(463, 12, 'Bongoran'),
(464, 12, 'Busac'),
(465, 12, 'Cadawag'),
(466, 12, 'Cagmanaba'),
(467, 12, 'Calaguimit'),
(468, 12, 'Calpi'),
(469, 12, 'Calzada'),
(470, 12, 'Camagong'),
(471, 12, 'Casinagan'),
(472, 12, 'Centro Poblacion'),
(473, 12, 'Coliat'),
(474, 12, 'Del Rosario'),
(475, 12, 'Gumabao'),
(476, 12, 'Ilaor Norte'),
(477, 12, 'Ilaor Sur'),
(478, 12, 'Iraya Norte'),
(479, 12, 'Iraya Sur'),
(480, 12, 'Manga'),
(481, 12, 'Maporong'),
(482, 12, 'Maramba'),
(483, 12, 'Matambo'),
(484, 12, 'Mayag'),
(485, 12, 'Mayao'),
(486, 12, 'Moroponros'),
(487, 12, 'Nagas'),
(488, 12, 'Obaliw - Rinas'),
(489, 12, 'Pistola'),
(490, 12, 'Ramay'),
(491, 12, 'Rizal'),
(492, 12, 'Saban'),
(493, 12, 'San Agustin'),
(494, 12, 'San Antonio'),
(495, 12, 'San Isidro'),
(496, 12, 'San Jose'),
(497, 12, 'San Juan'),
(498, 12, 'San Pascual (Nale)'),
(499, 12, 'San Ramon'),
(500, 12, 'San Vicente (Suca)'),
(501, 12, 'Tablon'),
(502, 12, 'Talisay'),
(503, 12, 'Talongog'),
(504, 12, 'Tapel'),
(505, 12, 'Tobgon'),
(506, 12, 'Tobog'),
(507, 13, 'Agol'),
(508, 13, 'Alabangpuro'),
(509, 13, 'Barangay 1 (Pob.)'),
(510, 13, 'Barangay 2 (Pob.)'),
(511, 13, 'Barangay 3 (Pob.)'),
(512, 13, 'Barangay 4 (Pob.)'),
(513, 13, 'Barangay 5 (Pob.)'),
(514, 13, 'Basicao Coastal'),
(515, 13, 'Binodegahan'),
(516, 13, 'Buenavista'),
(517, 13, 'Buyo'),
(518, 13, 'Caratagan'),
(519, 13, 'Cuyaoyao'),
(520, 13, 'Flores'),
(521, 13, 'La Medalla'),
(522, 13, 'Lawinon'),
(523, 13, 'Macasitas'),
(524, 13, 'Malapay'),
(525, 13, 'Malidong'),
(526, 13, 'Mamlad'),
(527, 13, 'Marigondon'),
(528, 13, 'Matanglad'),
(529, 13, 'Nablangbulod'),
(530, 13, 'Oringon'),
(531, 13, 'Palapas'),
(532, 13, 'Panganiran'),
(533, 13, 'Rawis'),
(534, 13, 'Salvacion'),
(535, 13, 'Santo Cristo'),
(536, 13, 'Sukip'),
(537, 13, 'Tibabo'),
(538, 14, 'Agos'),
(539, 14, 'Alnay'),
(540, 14, 'Alomon'),
(541, 14, 'Amoguis'),
(542, 14, 'Anopol'),
(543, 14, 'Apad'),
(544, 14, 'Balaba'),
(545, 14, 'Balangibang'),
(546, 14, 'Balinad'),
(547, 14, 'Basud'),
(548, 14, 'Binagbangan (Pintor)'),
(549, 14, 'Buyo'),
(550, 14, 'Centro Occidental (Pob.)'),
(551, 14, 'Centro Oriental (Pob.)'),
(552, 14, 'Cepres'),
(553, 14, 'Cotmon'),
(554, 14, 'Cotnogan'),
(555, 14, 'Danao'),
(556, 14, 'Gabon'),
(557, 14, 'Gamot'),
(558, 14, 'Itaran'),
(559, 14, 'Kinale'),
(560, 14, 'Kinuartilan'),
(561, 14, 'La Medalla'),
(562, 14, 'La Purisima'),
(563, 14, 'Lanigay'),
(564, 14, 'Lidong'),
(565, 14, 'Lourdes'),
(566, 14, 'Magpanambo'),
(567, 14, 'Magurang'),
(568, 14, 'Matacon'),
(569, 14, 'Maynag'),
(570, 14, 'Maysua'),
(571, 14, 'Mendez'),
(572, 14, 'Napo'),
(573, 14, 'Pinagdapugan'),
(574, 14, 'Ponso'),
(575, 14, 'Salvacion'),
(576, 14, 'San Roque'),
(577, 14, 'Santa Cruz'),
(578, 14, 'Santa Teresita'),
(579, 14, 'Santicon'),
(580, 14, 'Sugcad'),
(581, 14, 'Ubaliw'),
(582, 15, 'Bagaobawan'),
(583, 15, 'Batan'),
(584, 15, 'Bilbao'),
(585, 15, 'Binosawan'),
(586, 15, 'Bogtong'),
(587, 15, 'Buenavista'),
(588, 15, 'Buhatan'),
(589, 15, 'Calanaga'),
(590, 15, 'Caracaran'),
(591, 15, 'Carogcog'),
(592, 15, 'Dap - Dap'),
(593, 15, 'Gaba'),
(594, 15, 'Galicia'),
(595, 15, 'Guadalupe'),
(596, 15, 'Hamorawon'),
(597, 15, 'Lagundi'),
(598, 15, 'Liguan'),
(599, 15, 'Linao'),
(600, 15, 'Linao'),
(601, 15, 'Malobago'),
(602, 15, 'Mananao'),
(603, 15, 'Mancao'),
(604, 15, 'Manila'),
(605, 15, 'Masaga'),
(606, 15, 'Morocborocan'),
(607, 15, 'Nagcalsot'),
(608, 15, 'Pagcolbon'),
(609, 15, 'Poblacion'),
(610, 15, 'Sagrada'),
(611, 15, 'San Ramon'),
(612, 15, 'Santa Barbara'),
(613, 15, 'Tinocawan'),
(614, 15, 'Tinopan'),
(615, 15, 'Viga'),
(616, 15, 'Villa Hermosa'),
(617, 16, 'Alimsog'),
(618, 16, 'Bagong San Roque'),
(619, 16, 'Buhatan'),
(620, 16, 'Calayucay'),
(621, 16, 'Del Rosario Pob. (Brgy. 3)'),
(622, 16, 'Fidel Surtida'),
(623, 16, 'Lidong'),
(624, 16, 'Market Site Pob. (Brgy. 9)'),
(625, 16, 'Nagsiya Pob. (Brgy. 8)'),
(626, 16, 'Pandayan Pob. (Brgy. 10)'),
(627, 16, 'Salvacion'),
(628, 16, 'San Andres'),
(629, 16, 'San Fernando'),
(630, 16, 'San Francisco Pob. (Brgy. 1)'),
(631, 16, 'San Isidro'),
(632, 16, 'San Juan Pob. (Brgy. 2)'),
(633, 16, 'San Pedro Pob. (Brgy. 5)'),
(634, 16, 'San Rafael Pob. (Brgy. 7)'),
(635, 16, 'San Roque'),
(636, 16, 'San Vicente Pob. (Brgy. 6)'),
(637, 16, 'Santa Misericordia'),
(638, 16, 'Santo Domingo Pob. (Brgy. 4)'),
(639, 16, 'Santo Nino'),
(640, 17, 'Agnas (San Miguel Island)'),
(641, 17, 'Bacolod'),
(642, 17, 'Bangkilingan'),
(643, 17, 'Bantayan'),
(644, 17, 'Baranghawon'),
(645, 17, 'Basagan'),
(646, 17, 'Basud (Pob.)'),
(647, 17, 'Bognabong'),
(648, 17, 'Bombon (Pob.)'),
(649, 17, 'Bonot'),
(650, 17, 'Buang'),
(651, 17, 'Buhian'),
(652, 17, 'Cabagnan'),
(653, 17, 'Cobo'),
(654, 17, 'Comon'),
(655, 17, 'Cormidal'),
(656, 17, 'Divino Rostro (Pob.)'),
(657, 17, 'Fatima'),
(658, 17, 'Guinobat'),
(659, 17, 'Hacienda (San Miguel Island)'),
(660, 17, 'Magapo'),
(661, 17, 'Mariroc'),
(662, 17, 'Matagbac'),
(663, 17, 'Oras'),
(664, 17, 'Oson'),
(665, 17, 'Panal'),
(666, 17, 'Pawa'),
(667, 17, 'Pinagbobong'),
(668, 17, 'Quinale Cabasan (Pob.)'),
(669, 17, 'Quinastillojan'),
(670, 17, 'Rawis (San Miguel Island)'),
(671, 17, 'Sagurong (San Miguel Island)'),
(672, 17, 'Salvacion'),
(673, 17, 'San Antonio'),
(674, 17, 'San Carlos'),
(675, 17, 'San Isidro (Boring)'),
(676, 17, 'San Juan'),
(677, 17, 'San Lorenzo'),
(678, 17, 'San Ramon'),
(679, 17, 'San Roque'),
(680, 17, 'San Vicente'),
(681, 17, 'Santo Cristo'),
(682, 17, 'Sua - Igot'),
(683, 17, 'Tabiguian'),
(684, 17, 'Tagas'),
(685, 17, 'Tayhi (Pob.)'),
(686, 17, 'Visita (San Miguel Island)'),
(687, 18, 'Bagumbayan'),
(688, 18, 'Bariis'),
(689, 18, 'Baybay'),
(690, 18, 'Belen (Malabog)'),
(691, 18, 'Biyong'),
(692, 18, 'Bolo'),
(693, 18, 'Cale'),
(694, 18, 'Cararayan'),
(695, 18, 'Coro - Coro'),
(696, 18, 'Dap - Dap'),
(697, 18, 'Gajo'),
(698, 18, 'Joroan'),
(699, 18, 'Libjo'),
(700, 18, 'Libtong'),
(701, 18, 'Matalibong'),
(702, 18, 'Maynonong'),
(703, 18, 'Mayong'),
(704, 18, 'Misibis'),
(705, 18, 'Naga'),
(706, 18, 'Nagas'),
(707, 18, 'Oyama'),
(708, 18, 'Putsan'),
(709, 18, 'San Bernardo'),
(710, 18, 'Sogod'),
(711, 18, 'Tigbi (Pob.)');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `comment_id` int(10) UNSIGNED NOT NULL,
  `nutri_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `pre_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `comment_message` varchar(45) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `logs_id` int(10) UNSIGNED NOT NULL,
  `username_logs` varchar(45) NOT NULL DEFAULT '',
  `action_performed` varchar(45) NOT NULL DEFAULT '',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `municipality`
--

CREATE TABLE `municipality` (
  `mun_id` int(11) NOT NULL,
  `muncipality_name` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `municipality`
--

INSERT INTO `municipality` (`mun_id`, `muncipality_name`) VALUES
(1, 'Bacacay'),
(2, 'camalig'),
(3, 'Daraga'),
(4, 'Guinobatan'),
(5, 'Jovellar'),
(6, 'Legazpi'),
(7, 'Libon'),
(8, 'Ligao'),
(9, 'Malilipot'),
(10, 'Malinao'),
(11, 'Manito'),
(12, 'Oas'),
(13, '	Pio Duran'),
(14, '	Polangui'),
(15, 'Rapu-Rapu'),
(16, '	Santo Domingo'),
(17, 'Tabaco'),
(18, '	Tiwi');

-- --------------------------------------------------------

--
-- Table structure for table `nutritional_status`
--

CREATE TABLE `nutritional_status` (
  `nutri_id` int(10) UNSIGNED NOT NULL,
  `pre_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `status` varchar(45) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `parent_info`
--

CREATE TABLE `parent_info` (
  `par_id` int(10) UNSIGNED NOT NULL,
  `pre_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `f_name` varchar(45) NOT NULL DEFAULT '',
  `f_occupation` varchar(45) NOT NULL DEFAULT '',
  `m_name` varchar(45) NOT NULL DEFAULT '',
  `m_occupation` varchar(45) NOT NULL DEFAULT '',
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `annual_income` varchar(45) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parent_info`
--

INSERT INTO `parent_info` (`par_id`, `pre_id`, `f_name`, `f_occupation`, `m_name`, `m_occupation`, `user_id`, `annual_income`) VALUES
(147, 234568294, 'papa', 'para tindapa', 'papa', 'papa', 110, ''),
(148, 234568295, 'papa', 'para tindapa', 'papa', 'papa', 110, ''),
(149, 234568296, 'papa', 'para tindapa', 'mama', 'mamaku', 110, ''),
(150, 234568297, 'papa', 'para tindapa', 'mama', 'mamaku', 110, ''),
(151, 234568298, 'papa', 'gd', 'sss', 'ssss', 110, ''),
(152, 234568299, 'papa', 'gd', 'sss', 'ssss', 110, ''),
(153, 234568300, 'QWERTFGHJ', 'trek', 'xxx', 'trek', 0, ''),
(154, 234568301, 'asdadad', 'asdadad', 'asdadad', 'asdadad', 0, ''),
(155, 234568302, 'asdadad', 'asdadad', 'asdadad', 'asdadad', 0, ''),
(156, 234568303, 'papa', 'a=ollll', 'trek', 'a=ollll', 0, ''),
(157, 234568304, 'papa', 'a=ollll', 'trek', 'a=ollll', 0, ''),
(158, 234568305, 'asdadad', 'xxx', 'itay', 'trek', 0, ''),
(159, 234568306, 'asdadad', 'xxx', 'itay', 'trek', 0, ''),
(160, 234568307, 'z', 'z', 'z', 'z', 110, ''),
(161, 234568308, 'z', 'z', 'z', 'z', 110, ''),
(162, 234568309, 'z', 'z', 'z', 'z', 110, ''),
(163, 234568310, '', '', '', '', 110, ''),
(164, 234568311, 'asdadad', 'asas', 'asasa', 'sasa', 110, ''),
(165, 234568312, 'asdadad', 'asas', 'asasa', 'sasa', 110, ''),
(166, 234568313, 'aSD', 'ASDS', 'ASDASF', 'adfg', 110, ''),
(167, 234568314, 'aSD', 'ASDS', 'ASDASF', 'adfg', 110, ''),
(168, 234568315, 'ASAS', 'ASASA', 'ASASA', 'SASAS', 110, ''),
(169, 234568316, 'ASAS', 'ASASA', 'ASASA', 'SASAS', 110, ''),
(170, 234568317, 'ASAS', 'ASASA', 'ASASA', 'SASAS', 110, ''),
(171, 234568318, 'asd', 'safddsaf', 'sfdadf', 'assdfa', 110, ''),
(172, 234568318, 'asd', 'safddsaf', 'sfdadf', 'assdfa', 110, ''),
(173, 234568318, '2423', '32423', '3423', '234234', 110, ''),
(174, 234568319, '2423', '32423', '3423', '234234', 110, ''),
(175, 234568320, 'fghfyhy', 'fghfgh', 'fghfgh', 'fghfg', 110, ''),
(176, 234568321, 'gfyj', 'yhjuty', 'yjtu', 'tyjuiy', 110, ''),
(177, 234568322, 'gfyj', 'yhjuty', 'yjtu', 'tyjuiy', 0, ''),
(178, 234568323, 'z', 'itay', 'gd', '', 0, ''),
(179, 234568324, 'aaaaaaa', 'aaaaaaaaaaa', 'aaaaaaaaaaa', 'aaaaaaaaaaa', 0, ''),
(180, 234568325, 'aaaaaaa', 'aaaaaaaaaaa', 'aaaaaaaaaaa', 'aaaaaaaaaaa', 0, ''),
(181, 234568326, 'aaaaaaa', 'aaaaaaaaaaa', 'aaaaaaaaaaa', 'aaaaaaaaaaa', 0, ''),
(182, 234568327, 'aaaaaaa', 'aaaaaaaaaaa', 'aaaaaaaaaaa', 'aaaaaaaaaaa', 110, ''),
(183, 234568327, 'aaaaaaa', 'aaaaaaaaaaa', 'aaaaaaaaaaa', 'aaaaaaaaaaa', 110, ''),
(184, 234568328, 'asdasd', 'asdas', 'asda', 'asdasd', 110, ''),
(185, 234568329, 'asas', 'asas', 'asas', 'asasas', 110, ''),
(186, 234568330, 'asas', 'asas', 'asas', 'asasas', 110, ''),
(187, 234568331, 'ass', 'ds', 'as', 'dds', 110, ''),
(188, 234568331, 'ass', 'ds', 'as', 'dds', 110, ''),
(189, 234568331, 'fd', 'fvf', 'fv', 'fvfv', 110, ''),
(190, 234568331, 'fd', 'fvf', 'fv', 'fvfv', 110, ''),
(191, 234568331, 'fd', 'fvf', 'fv', 'fvfv', 110, ''),
(192, 234568331, 'fgdrfd', 'dfgdfg', 'dfgdfg', 'dfgdfdfg', 110, ''),
(193, 234568331, 'fgdrfd', 'dfgdfg', 'dfgdfg', 'dfgdfdfg', 110, ''),
(194, 234568331, 'fgdrfd', 'dfgdfg', 'dfgdfg', 'dfgdfdfg', 110, ''),
(195, 234568331, 'w2qs', 'sa', 'wdsqa', 'qwsa', 110, ''),
(196, 234568331, '23', '323', '2323', '32323', 110, ''),
(197, 234568332, '', 'qwwqw', 'wqqw', 'qwqw', 110, ''),
(198, 234568333, 'ASAS', 'jasda', 'jasda', 'jasda', 110, ''),
(199, 234568334, 'wew', 'wwq', 'wq', 'qw', 110, ''),
(200, 234568335, '3', '3', '11', '1w', 110, ''),
(201, 234568336, 'qwerdtfg', 'wesrdfgh', 'werdfgh', 'wertyghj', 110, ''),
(202, 234568337, 'esdfg', 'dfg', 'werfg', 'wedfg', 110, ''),
(203, 234568338, 'wedqwsdqwsd', 'qwe', 'wd', 'wedf', 123, '');

-- --------------------------------------------------------

--
-- Table structure for table `phone`
--

CREATE TABLE `phone` (
  `phone_id` int(10) UNSIGNED NOT NULL,
  `par_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `pre_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `phone_number` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `phone_network` varchar(45) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `physical_info`
--

CREATE TABLE `physical_info` (
  `phy_id` int(10) UNSIGNED NOT NULL,
  `pre_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `weight` float NOT NULL DEFAULT '0',
  `height` float NOT NULL DEFAULT '0',
  `bmi` float NOT NULL DEFAULT '0',
  `health_status` varchar(45) NOT NULL DEFAULT '',
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `physical_info`
--

INSERT INTO `physical_info` (`phy_id`, `pre_id`, `weight`, `height`, `bmi`, `health_status`, `user_id`) VALUES
(316, 234568294, 3, 3, 0.333333, 'This is considered as  severly Underweight', 110),
(317, 234568295, 3, 3, 0.333333, 'This is considered as  severly Underweight', 110),
(318, 234568296, 25, 10, 0.25, 'This is considered as  severly Underweight', 110),
(319, 234568297, 25, 10, 0.25, 'This is considered as  severly Underweight', 110),
(320, 234568298, 3, 2, 0.75, 'This is considered as  severly Underweight', 110),
(321, 234568299, 3, 2, 0.75, 'This is considered as  severly Underweight', 110),
(322, 234568300, 5, 5, 0.2, 'This is considered as  severly Underweight', 0),
(323, 234568301, 3, 3, 0.333333, 'This is considered as  severly Underweight', 0),
(324, 234568302, 3, 3, 0.333333, 'This is considered as  severly Underweight', 0),
(325, 234568303, 6, 7, 0.122449, 'This is considered as  severly Underweight', 0),
(326, 234568304, 6, 7, 0.122449, 'This is considered as  severly Underweight', 0),
(327, 234568305, 1, 4, 0.0625, 'This is considered as  severly Underweight', 0),
(328, 234568306, 1, 4, 0.0625, 'This is considered as  severly Underweight', 0),
(329, 234568307, 2, 5, 0.08, 'This is considered as  severly Underweight', 110),
(330, 234568308, 2, 5, 0.08, 'This is considered as  severly Underweight', 110),
(331, 234568309, 2, 5, 0.08, 'This is considered as  severly Underweight', 110),
(332, 234568310, 0, 0, 0, 'This is considered as  severly Underweight', 110),
(333, 234568311, 1, 1, 1, 'This is considered as  severly Underweight', 110),
(334, 234568312, 1, 1, 1, 'This is considered as  severly Underweight', 110),
(335, 234568313, 42, 6, 1.16667, 'This is considered as  severly Underweight', 110),
(336, 234568314, 42, 6, 1.16667, 'This is considered as  severly Underweight', 110),
(337, 234568315, 55, 4, 3.4375, 'This is considered as  severly Underweight', 110),
(338, 234568316, 55, 4, 3.4375, 'This is considered as  severly Underweight', 110),
(339, 234568317, 55, 4, 3.4375, 'This is considered as  severly Underweight', 110),
(340, 234568318, 2, 2, 0.5, 'This is considered as  severly Underweight', 110),
(341, 234568318, 2, 2, 0.5, 'This is considered as  severly Underweight', 110),
(342, 234568318, 45, 5, 1.8, 'This is considered as  severly Underweight', 110),
(343, 234568319, 45, 5, 1.8, 'This is considered as  severly Underweight', 110),
(344, 234568320, 4, 3, 0.444444, 'This is considered as  severly Underweight', 110),
(345, 234568321, 2, 3, 0.222222, 'This is considered as  severly Underweight', 110),
(346, 234568322, 2, 3, 0.222222, 'This is considered as  severly Underweight', 0),
(347, 234568323, 9, 6, 0.25, 'This is considered as  severly Underweight', 0),
(348, 234568324, 2, 12, 0.0138889, 'This is considered as  severly Underweight', 0),
(349, 234568325, 2, 12, 0.0138889, 'This is considered as  severly Underweight', 0),
(350, 234568326, 2, 12, 0.0138889, 'This is considered as  severly Underweight', 0),
(351, 234568327, 2, 12, 0.0138889, 'This is considered as  severly Underweight', 110),
(352, 234568327, 2, 12, 0.0138889, 'This is considered as  severly Underweight', 110),
(353, 234568328, 1, 1, 1, 'This is considered as  severly Underweight', 110),
(354, 234568329, 1, 2, 0.25, 'This is considered as  severly Underweight', 110),
(355, 234568330, 1, 2, 0.25, 'This is considered as  severly Underweight', 110),
(356, 234568331, 1, 2, 0.25, 'This is considered as  severly Underweight', 110),
(357, 234568331, 1, 2, 0.25, 'This is considered as  severly Underweight', 110),
(358, 234568331, 6, 4, 0.375, 'This is considered as  severly Underweight', 110),
(359, 234568331, 6, 4, 0.375, 'This is considered as  severly Underweight', 110),
(360, 234568331, 6, 4, 0.375, 'This is considered as  severly Underweight', 110),
(361, 234568331, 6, 45, 0.00296296, 'This is considered as  severly Underweight', 110),
(362, 234568331, 6, 45, 0.00296296, 'This is considered as  severly Underweight', 110),
(363, 234568331, 6, 45, 0.00296296, 'This is considered as  severly Underweight', 110),
(364, 234568331, 1, 1, 1, 'This is considered as  severly Underweight', 110),
(365, 234568331, 12, 4, 0.75, 'This is considered as  severly Underweight', 110),
(366, 234568332, 3, 2, 0.75, 'This is considered as  severly Underweight', 110),
(367, 234568333, 4, 3, 0.444444, 'This is considered as  severly Underweight', 110),
(368, 234568334, 2, 2, 0.5, 'This is considered as  severly Underweight', 110),
(369, 234568335, 1, 3, 0.111111, 'This is considered as  severly Underweight', 110),
(370, 234568336, 2, 2, 0.5, 'This is considered as  severly Underweight', 110),
(371, 234568337, 5, 3, 0.555556, 'This is considered as  severly Underweight', 110),
(372, 234568338, 12, 23, 0.0226843, 'This is considered as  severly Underweight', 123);

-- --------------------------------------------------------

--
-- Table structure for table `preschooler`
--

CREATE TABLE `preschooler` (
  `pre_id` int(10) UNSIGNED NOT NULL,
  `mun_id` int(11) NOT NULL,
  `bar_id` int(8) NOT NULL,
  `pre_fname` varchar(45) NOT NULL DEFAULT '',
  `pre_mname` varchar(45) NOT NULL DEFAULT '',
  `pre_lname` varchar(45) NOT NULL DEFAULT '',
  `pre_bdate` varchar(45) NOT NULL DEFAULT '',
  `pre_age` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `pre_gender` varchar(45) NOT NULL DEFAULT '',
  `pre_nationality` varchar(45) DEFAULT NULL,
  `pre_religion` varchar(45) NOT NULL DEFAULT '',
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `preschooler`
--

INSERT INTO `preschooler` (`pre_id`, `mun_id`, `bar_id`, `pre_fname`, `pre_mname`, `pre_lname`, `pre_bdate`, `pre_age`, `pre_gender`, `pre_nationality`, `pre_religion`, `user_id`) VALUES
(234568294, 4, 0, 'dddd', 'ddddd', 'ddddd', '11/08/2012', 6, 'male', 'xcxcxc', 'asas', 110),
(234568295, 4, 0, 'dddd', 'ddddd', 'ddddd', '11/08/2012', 6, 'male', 'xcxcxc', 'asas', 110),
(234568296, 2, 0, 'Tracy', 'Tracy', 'Guazon', '11/08/2012', 3, 'female', 'qwqwq', 'wrerer', 110),
(234568297, 2, 0, 'Tracy', 'Tracy', 'Guazon', '11/08/2012', 3, 'female', 'qwqwq', 'wrerer', 110),
(234568298, 1, 2, 'Alyl', 'B.', 'MArbella', '11/07/2003', 16, 'female', 'trek', 'Med', 110),
(234568299, 1, 3, 'Alyl', 'B.', 'MArbella', '11/07/2003', 16, 'female', 'trek', 'Med', 110),
(234568331, 1, 0, 'sddd', 'sdddd', 'sddd', 'sd', 0, 'female', 'assa', 'qwqwq', 110),
(234568332, 1, 3, 'qwqwq', 'qwqw', 'qwqw', 'qwqw', 0, 'male', 'qwqw', 'qwqw', 110),
(234568333, 1, 10, 'tr', 'asadas', 'trek', 'jasda', 0, 'male', 'qwqwq', 'jasda', 110),
(234568334, 1, 1, 'antoontete', 'wq', 'df', '11/08/2012', 12, 'female', 'we', 'we', 110),
(234568335, 1, 1, 'guazon', 'sas', 'asasa', '11/08/2012', 15, 'male', 'qwqwq', 'sas', 110),
(234568336, 1, 2, 'werdtfyghj', 'eawsrdgtfhj', 'qwerdtgfhj', '34werty', 3, 'male', 'werdtfghbn', 'ertyfhj', 110),
(234568337, 6, 0, 'wedfg', 'wefrdg', 'wedfgbv', 'wedrfg', 0, 'male', 'qwerfg', 'edfg', 110),
(234568338, 4, 162, 'fffffffffff', 'asdf', 'asdf', '11/08/2012', 15, 'male', 'wedf', 'wedf', 123);

-- --------------------------------------------------------

--
-- Table structure for table `sw_approval`
--

CREATE TABLE `sw_approval` (
  `app_id` int(255) NOT NULL,
  `pre_id` int(11) NOT NULL,
  `bar_id` int(3) NOT NULL,
  `mun_id` int(3) NOT NULL,
  `status` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sw_approval`
--

INSERT INTO `sw_approval` (`app_id`, `pre_id`, `bar_id`, `mun_id`, `status`) VALUES
(18, 234568298, 2, 1, 1),
(19, 234568299, 3, 1, 1),
(50, 234568335, 1, 1, 1),
(51, 234568336, 2, 1, 1),
(52, 234568338, 162, 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `town`
--

CREATE TABLE `town` (
  `idtown` int(10) UNSIGNED NOT NULL,
  `town_name` varchar(45) NOT NULL DEFAULT '',
  `underweight` varchar(45) NOT NULL DEFAULT '',
  `overweight` varchar(45) NOT NULL DEFAULT '',
  `normal` varchar(45) NOT NULL DEFAULT '',
  `obese` varchar(45) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `userposition_id`
--

CREATE TABLE `userposition_id` (
  `up_id` int(8) NOT NULL,
  `positions` varchar(45) NOT NULL DEFAULT '0',
  `level` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userposition_id`
--

INSERT INTO `userposition_id` (`up_id`, `positions`, `level`) VALUES
(4, 'bhw', 0),
(5, 'socialworkers', 1),
(6, 'nutritionist', 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `firstname` varchar(45) NOT NULL DEFAULT '',
  `middlename` varchar(45) NOT NULL DEFAULT '',
  `lastname` varchar(45) NOT NULL DEFAULT '',
  `bdate` varchar(45) NOT NULL DEFAULT '',
  `age` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `gender` varchar(45) NOT NULL DEFAULT '',
  `contact number` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `email` varchar(45) NOT NULL DEFAULT '',
  `position` varchar(45) NOT NULL DEFAULT '',
  `municipality` varchar(45) NOT NULL,
  `img` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `firstname`, `middlename`, `lastname`, `bdate`, `age`, `gender`, `contact number`, `email`, `position`, `municipality`, `img`) VALUES
(110, 'alyl', 'bhw', 'alylm@gmail.com', '', 0, '', 0, '', '', '', ''),
(111, 'Tracy Guazon', '1', 'trg@gmail.com', '', 0, '', 0, '', '', '', ''),
(112, 'ericka marbella', '2', 'marbea@fmail.com', '', 0, '', 0, '', '', '', ''),
(113, 'bob', '0', 'marbellacaryll@gmail.com', '', 0, '', 0, '', '', '', ''),
(114, 'erwin marbella', '0', 'marbellaaer@gmail.com', '', 0, '', 0, '', '', '', ''),
(115, 'jdasgdj', '0', 'erickamaemarbella@gmail.com', '', 0, '', 0, '', '', '', ''),
(116, 'arwinm', 'bhw', 'arwinm@gmail.com', '', 0, '', 0, '', '', '', ''),
(117, '', '', '', '', 0, '', 0, 'woyriquh@gmail.com', '0', '', ''),
(118, 'rweuio', '', '', '', 0, '', 0, 'wqrewrteyrutio@gmail.com', '1', '', 0x34363138323832385f3237363531313333393732333937345f363534303533333738393238383832343833325f6e2e6a7067),
(119, 'victoring', '', '', '', 0, '', 0, 'victtt@gmail.com', '0', '', 0x34363138323832385f3237363531313333393732333937345f363534303533333738393238383832343833325f6e2e6a7067),
(120, 'qwerdfghbn', '', '', '', 0, '', 0, 'q3wesdrfv@adfdsc.com', '1', '', ''),
(121, '2wedrfghnm', '', '', '', 0, '', 0, 'qwedfrgh@edfghmj', '2', '', ''),
(122, 'SDFGH', '', '', '', 0, '', 0, 'SDFGH@EDFGHNB', '1', '2', ''),
(123, 'dd', '', '', '', 0, '', 0, 'asd2EDFG@WDF', '0', '4', ''),
(124, 'cc', '', '', '', 0, '', 0, 'cc@dd', '1', '4', '');

-- --------------------------------------------------------

--
-- Table structure for table `user_access`
--

CREATE TABLE `user_access` (
  `user_acc_id` int(10) UNSIGNED NOT NULL,
  `mun_id` int(9) NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `level` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `username` varchar(45) NOT NULL DEFAULT '',
  `password` varchar(45) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_access`
--

INSERT INTO `user_access` (`user_acc_id`, `mun_id`, `user_id`, `level`, `username`, `password`) VALUES
(104, 0, 110, 0, 'alylm', 'alylm123'),
(105, 1, 111, 1, 'tracyg', 'tracy123'),
(106, 2, 11, 1, 'em', 'em12345'),
(107, 0, 0, 0, 'bhw', 'saaa'),
(108, 0, 0, 0, 'lolopp', 'loloppp123'),
(109, 0, 0, 0, 'dasdasda', 'dasdad'),
(110, 4, 116, 1, 'arwinm', 'arwinm123'),
(111, 0, 0, 0, 'vic', 'vic123'),
(112, 0, 0, 0, 'uiew', 'oiqueqoeoiq'),
(113, 0, 0, 1, 'oiuuytyrtewreqd', 'wqeqweqqeq'),
(114, 0, 119, 0, 'victor', '1234'),
(127, 0, 0, 1, 'dfsdf', 'dfsdf'),
(128, 0, 0, 1, 'aaaaaaaaasxaas', 'sdedawed'),
(129, 0, 0, 1, 'ghryhryh', 'ryhrthrth'),
(130, 0, 0, 1, '123eqrwfds', 'ewqrdfg'),
(131, 0, 0, 1, '24WTRGF', 'YHJUKYHJMNBGF'),
(132, 0, 119, 1, 'ewds', 'qewds'),
(133, 0, 119, 1, '2weads', 'qweasd'),
(134, 0, 0, 1, 'somebodey', 'somebodey'),
(135, 0, 0, 1, 'qwaesrdfgcvhbn', 'erdtfghbn'),
(136, 0, 0, 1, 'wesrdtgfh', 'ewrtfgh'),
(137, 0, 119, 1, '345ertyghj', 'erdtyghj'),
(138, 0, 0, 1, '2q3wertyuj', '2ertyhj'),
(139, 0, 0, 1, 'QWERTFHYJ', 'WERSDGFH'),
(140, 0, 0, 1, '3wesrdtf', 'q23wertdf'),
(141, 0, 0, 0, 'aqsd1erfed', 'qweds'),
(142, 0, 120, 1, 'ewdsfvc', '3erfdgvb'),
(143, 0, 120, 1, '12e3r', '12qwedf'),
(144, 0, 120, 1, 'wedsfvc', 'wefdv'),
(145, 0, 120, 1, 'WEEEEEEEEEE', 'WEEEEEEEEEEEEEEEEEE'),
(146, 0, 120, 1, 'aaaaaaaaaaaa', 'aaaaaaaaaaaaa'),
(147, 0, 120, 1, 'QWEDFGVB', 'QWSDFVB'),
(148, 0, 0, 1, 'QASDXC', 'ASDXC'),
(149, 0, 0, 1, 'wsdfvbn', 'wsdsfvb'),
(150, 0, 0, 1, 'qsdfgbn', 'qwefrghjm'),
(151, 0, 120, 1, 'wds', 'sdxc'),
(152, 0, 121, 2, 'wdsv', 'dcv'),
(153, 0, 121, 1, 'vvvvvvvv', 'vvvvvvvvvvvvv'),
(154, 0, 121, 1, 'ewsdw', 'ewdwew'),
(155, 0, 121, 1, 'QWDFG', 'WEDFRGHJM,'),
(156, 2, 122, 1, 'WEDSFGBN', 'WEASDFGH'),
(157, 4, 123, 0, 'DD', 'DD'),
(158, 4, 124, 1, 'ccc', 'ccc');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`addr_id`);

--
-- Indexes for table `albay_town`
--
ALTER TABLE `albay_town`
  ADD PRIMARY KEY (`idalbay_town`);

--
-- Indexes for table `barangay`
--
ALTER TABLE `barangay`
  ADD PRIMARY KEY (`bar_id`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`logs_id`);

--
-- Indexes for table `municipality`
--
ALTER TABLE `municipality`
  ADD PRIMARY KEY (`mun_id`);

--
-- Indexes for table `nutritional_status`
--
ALTER TABLE `nutritional_status`
  ADD PRIMARY KEY (`nutri_id`);

--
-- Indexes for table `parent_info`
--
ALTER TABLE `parent_info`
  ADD PRIMARY KEY (`par_id`);

--
-- Indexes for table `phone`
--
ALTER TABLE `phone`
  ADD PRIMARY KEY (`phone_id`);

--
-- Indexes for table `physical_info`
--
ALTER TABLE `physical_info`
  ADD PRIMARY KEY (`phy_id`);

--
-- Indexes for table `preschooler`
--
ALTER TABLE `preschooler`
  ADD PRIMARY KEY (`pre_id`);

--
-- Indexes for table `sw_approval`
--
ALTER TABLE `sw_approval`
  ADD PRIMARY KEY (`app_id`);

--
-- Indexes for table `town`
--
ALTER TABLE `town`
  ADD PRIMARY KEY (`idtown`);

--
-- Indexes for table `userposition_id`
--
ALTER TABLE `userposition_id`
  ADD PRIMARY KEY (`up_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_access`
--
ALTER TABLE `user_access`
  ADD PRIMARY KEY (`user_acc_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `addr_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `albay_town`
--
ALTER TABLE `albay_town`
  MODIFY `idalbay_town` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `barangay`
--
ALTER TABLE `barangay`
  MODIFY `bar_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=712;

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `comment_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `logs_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `municipality`
--
ALTER TABLE `municipality`
  MODIFY `mun_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `nutritional_status`
--
ALTER TABLE `nutritional_status`
  MODIFY `nutri_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `parent_info`
--
ALTER TABLE `parent_info`
  MODIFY `par_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=204;

--
-- AUTO_INCREMENT for table `phone`
--
ALTER TABLE `phone`
  MODIFY `phone_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `physical_info`
--
ALTER TABLE `physical_info`
  MODIFY `phy_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=373;

--
-- AUTO_INCREMENT for table `preschooler`
--
ALTER TABLE `preschooler`
  MODIFY `pre_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=234568339;

--
-- AUTO_INCREMENT for table `sw_approval`
--
ALTER TABLE `sw_approval`
  MODIFY `app_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `town`
--
ALTER TABLE `town`
  MODIFY `idtown` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `userposition_id`
--
ALTER TABLE `userposition_id`
  MODIFY `up_id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=125;

--
-- AUTO_INCREMENT for table `user_access`
--
ALTER TABLE `user_access`
  MODIFY `user_acc_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=159;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
