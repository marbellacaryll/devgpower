-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2018 at 10:20 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mcmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `addr_id` int(10) UNSIGNED NOT NULL,
  `pre_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `street` varchar(45) NOT NULL DEFAULT '',
  `barangay` varchar(45) NOT NULL DEFAULT '',
  `municipality` varchar(45) NOT NULL DEFAULT '',
  `province` varchar(45) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `albay_town`
--

CREATE TABLE `albay_town` (
  `idalbay_town` int(10) UNSIGNED NOT NULL,
  `pre_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `par_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `phy_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `nutri_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `tiwi` varchar(45) NOT NULL DEFAULT '',
  `malinao` varchar(45) NOT NULL DEFAULT '',
  `tabaco` varchar(45) NOT NULL DEFAULT '',
  `malilipot` varchar(45) NOT NULL DEFAULT '',
  `bacacay` varchar(45) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `barangay`
--

CREATE TABLE `barangay` (
  `bar_id` int(10) NOT NULL,
  `mun_id` int(10) NOT NULL,
  `barangay_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barangay`
--

INSERT INTO `barangay` (`bar_id`, `mun_id`, `barangay_name`) VALUES
(1, 1, 'Baclayon'),
(2, 1, 'Banao'),
(3, 1, 'Bariw'),
(4, 1, 'Basud'),
(5, 1, 'Bayandong'),
(6, 1, 'Bonga'),
(7, 1, 'Buang'),
(8, 1, 'Cabasan'),
(9, 1, 'Cagbulacao'),
(10, 1, 'Cagraray'),
(11, 1, 'Cajogutan'),
(12, 1, 'Cawayan'),
(13, 1, 'Damacan'),
(14, 1, 'Gubat Ilawod '),
(15, 1, 'Gubat Iraya'),
(16, 1, 'Hindi '),
(17, 1, 'Igang'),
(18, 1, 'Langaton'),
(19, 1, 'Manaet'),
(20, 1, 'Mapulang Daga'),
(21, 1, 'Mataas'),
(22, 1, 'Misibis'),
(23, 1, 'Nahapunan '),
(24, 1, 'Namanday'),
(25, 1, 'Namantao'),
(26, 1, 'Napao'),
(27, 1, 'Panarayon'),
(28, 1, 'Pigcobohan'),
(29, 1, 'Pili Ilawod'),
(30, 1, 'Pili Iraya '),
(31, 1, 'Barangay 1 (Pob.)'),
(32, 1, 'Barangay 10 (Pob.)'),
(33, 1, 'Barangay 11 (Pob.)'),
(34, 1, 'Barangay 12 (Pob.)'),
(35, 1, 'Barangay 13 (Pob.)'),
(36, 1, 'Barangay 14 (Pob.)'),
(37, 1, 'Barangay 2 (Pob.)'),
(38, 1, 'Barangay 3 (Pob.)'),
(39, 1, 'Barangay 4 (Pob.)'),
(40, 1, 'Barangay 5 (Pob.)'),
(41, 1, 'Barangay 6 (Pob.)'),
(42, 1, 'Barangay 7 (Pob.)'),
(43, 1, 'Barangay 8 (Pob.) '),
(44, 1, 'Barangay 9 (Pob.)'),
(45, 1, 'Pongco (Lower Bonga)'),
(46, 1, 'Busdac (San Jose)'),
(47, 1, 'San Pablo'),
(48, 1, 'San Pedro'),
(49, 1, 'Sogod'),
(50, 1, 'Sogod'),
(51, 1, 'Sula '),
(52, 1, 'Tambilagao '),
(53, 1, 'Tambongon '),
(54, 1, 'Tanagan'),
(55, 1, 'Uson'),
(56, 1, 'Vinisitahan-Basud (Mainland)'),
(57, 1, 'Vinisitahan-Napao (lsland)');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `comment_id` int(10) UNSIGNED NOT NULL,
  `nutri_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `pre_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `comment_message` varchar(45) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `logs_id` int(10) UNSIGNED NOT NULL,
  `username_logs` varchar(45) NOT NULL DEFAULT '',
  `action_performed` varchar(45) NOT NULL DEFAULT '',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `municipality`
--

CREATE TABLE `municipality` (
  `mun_id` int(11) NOT NULL,
  `muncipality_name` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `municipality`
--

INSERT INTO `municipality` (`mun_id`, `muncipality_name`) VALUES
(1, 'Bacacay'),
(2, 'camalig'),
(3, 'Daraga'),
(4, 'Guinobatan'),
(5, 'Jovellar'),
(6, 'Legazpi'),
(7, 'Libon'),
(8, 'Ligao'),
(9, 'Malilipot'),
(10, 'Malinao'),
(11, 'Manito'),
(12, 'Oas'),
(13, '	Pio Duran'),
(14, '	Polangui'),
(15, 'Rapu-Rapu'),
(16, '	Santo Domingo'),
(17, 'Tabaco'),
(18, '	Tiwi');

-- --------------------------------------------------------

--
-- Table structure for table `nutritional_status`
--

CREATE TABLE `nutritional_status` (
  `nutri_id` int(10) UNSIGNED NOT NULL,
  `pre_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `status` varchar(45) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `parent_info`
--

CREATE TABLE `parent_info` (
  `par_id` int(10) UNSIGNED NOT NULL,
  `pre_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `f_name` varchar(45) NOT NULL DEFAULT '',
  `f_occupation` varchar(45) NOT NULL DEFAULT '',
  `m_name` varchar(45) NOT NULL DEFAULT '',
  `m_occupation` varchar(45) NOT NULL DEFAULT '',
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `annual_income` varchar(45) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parent_info`
--

INSERT INTO `parent_info` (`par_id`, `pre_id`, `f_name`, `f_occupation`, `m_name`, `m_occupation`, `user_id`, `annual_income`) VALUES
(147, 234568294, 'papa', 'para tindapa', 'papa', 'papa', 110, ''),
(148, 234568295, 'papa', 'para tindapa', 'papa', 'papa', 110, ''),
(149, 234568296, 'papa', 'para tindapa', 'mama', 'mamaku', 110, ''),
(150, 234568297, 'papa', 'para tindapa', 'mama', 'mamaku', 110, ''),
(151, 234568298, 'papa', 'gd', 'sss', 'ssss', 110, ''),
(152, 234568299, 'papa', 'gd', 'sss', 'ssss', 110, ''),
(153, 234568300, 'QWERTFGHJ', 'trek', 'xxx', 'trek', 0, ''),
(154, 234568301, 'asdadad', 'asdadad', 'asdadad', 'asdadad', 0, ''),
(155, 234568302, 'asdadad', 'asdadad', 'asdadad', 'asdadad', 0, ''),
(156, 234568303, 'papa', 'a=ollll', 'trek', 'a=ollll', 0, ''),
(157, 234568304, 'papa', 'a=ollll', 'trek', 'a=ollll', 0, ''),
(158, 234568305, 'asdadad', 'xxx', 'itay', 'trek', 0, ''),
(159, 234568306, 'asdadad', 'xxx', 'itay', 'trek', 0, ''),
(160, 234568307, 'z', 'z', 'z', 'z', 110, ''),
(161, 234568308, 'z', 'z', 'z', 'z', 110, ''),
(162, 234568309, 'z', 'z', 'z', 'z', 110, ''),
(163, 234568310, '', '', '', '', 110, ''),
(164, 234568311, 'asdadad', 'asas', 'asasa', 'sasa', 110, '');

-- --------------------------------------------------------

--
-- Table structure for table `phone`
--

CREATE TABLE `phone` (
  `phone_id` int(10) UNSIGNED NOT NULL,
  `par_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `pre_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `phone_number` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `phone_network` varchar(45) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `physical_info`
--

CREATE TABLE `physical_info` (
  `phy_id` int(10) UNSIGNED NOT NULL,
  `pre_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `weight` float NOT NULL DEFAULT '0',
  `height` float NOT NULL DEFAULT '0',
  `bmi` float NOT NULL DEFAULT '0',
  `health_status` varchar(45) NOT NULL DEFAULT '',
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `physical_info`
--

INSERT INTO `physical_info` (`phy_id`, `pre_id`, `weight`, `height`, `bmi`, `health_status`, `user_id`) VALUES
(316, 234568294, 3, 3, 0.333333, 'This is considered as  severly Underweight', 110),
(317, 234568295, 3, 3, 0.333333, 'This is considered as  severly Underweight', 110),
(318, 234568296, 25, 10, 0.25, 'This is considered as  severly Underweight', 110),
(319, 234568297, 25, 10, 0.25, 'This is considered as  severly Underweight', 110),
(320, 234568298, 3, 2, 0.75, 'This is considered as  severly Underweight', 110),
(321, 234568299, 3, 2, 0.75, 'This is considered as  severly Underweight', 110),
(322, 234568300, 5, 5, 0.2, 'This is considered as  severly Underweight', 0),
(323, 234568301, 3, 3, 0.333333, 'This is considered as  severly Underweight', 0),
(324, 234568302, 3, 3, 0.333333, 'This is considered as  severly Underweight', 0),
(325, 234568303, 6, 7, 0.122449, 'This is considered as  severly Underweight', 0),
(326, 234568304, 6, 7, 0.122449, 'This is considered as  severly Underweight', 0),
(327, 234568305, 1, 4, 0.0625, 'This is considered as  severly Underweight', 0),
(328, 234568306, 1, 4, 0.0625, 'This is considered as  severly Underweight', 0),
(329, 234568307, 2, 5, 0.08, 'This is considered as  severly Underweight', 110),
(330, 234568308, 2, 5, 0.08, 'This is considered as  severly Underweight', 110),
(331, 234568309, 2, 5, 0.08, 'This is considered as  severly Underweight', 110),
(332, 234568310, 0, 0, 0, 'This is considered as  severly Underweight', 110),
(333, 234568311, 1, 1, 1, 'This is considered as  severly Underweight', 110);

-- --------------------------------------------------------

--
-- Table structure for table `preschooler`
--

CREATE TABLE `preschooler` (
  `pre_id` int(10) UNSIGNED NOT NULL,
  `mun_id` int(4) NOT NULL,
  `bar_id` int(8) NOT NULL,
  `pre_fname` varchar(45) NOT NULL DEFAULT '',
  `pre_mname` varchar(45) NOT NULL DEFAULT '',
  `pre_lname` varchar(45) NOT NULL DEFAULT '',
  `pre_bdate` varchar(45) NOT NULL DEFAULT '',
  `pre_age` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `pre_gender` varchar(45) NOT NULL DEFAULT '',
  `pre_nationality` varchar(45) DEFAULT NULL,
  `pre_religion` varchar(45) NOT NULL DEFAULT '',
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `preschooler`
--

INSERT INTO `preschooler` (`pre_id`, `mun_id`, `bar_id`, `pre_fname`, `pre_mname`, `pre_lname`, `pre_bdate`, `pre_age`, `pre_gender`, `pre_nationality`, `pre_religion`, `user_id`) VALUES
(234568294, 4, 0, 'dddd', 'ddddd', 'ddddd', '11/08/2012', 6, 'male', 'xcxcxc', 'asas', 110),
(234568295, 4, 0, 'dddd', 'ddddd', 'ddddd', '11/08/2012', 6, 'male', 'xcxcxc', 'asas', 110),
(234568296, 2, 0, 'Tracy', 'Tracy', 'Guazon', '11/08/2012', 3, 'female', 'qwqwq', 'wrerer', 110),
(234568297, 2, 0, 'Tracy', 'Tracy', 'Guazon', '11/08/2012', 3, 'female', 'qwqwq', 'wrerer', 110),
(234568298, 1, 2, 'Alyl', 'B.', 'MArbella', '11/07/2003', 16, 'female', 'trek', 'Med', 110),
(234568299, 1, 3, 'Alyl', 'B.', 'MArbella', '11/07/2003', 16, 'female', 'trek', 'Med', 110),
(234568300, 0, 0, 'assss', 'ddddd', 'itay', '11/08/2012', 15, 'male', 'qwqwq', 'qwqwq', 0),
(234568301, 0, 0, 'asdadad', 'asdadad', 'asdadad', 'asdadad', 15, 'male', 'asdadad', 'asdadad', 0),
(234568302, 0, 0, 'asdadad', 'asdadad', 'asdadad', 'asdadad', 15, 'male', 'asdadad', 'asdadad', 0),
(234568303, 0, 0, 'dddd', 'ddddd', 'ddddd', '11/08/2012', 15, 'male', 'a=ollll', 'saa', 0),
(234568304, 0, 0, 'dddd', 'ddddd', 'ddddd', '11/08/2012', 15, 'male', 'a=ollll', 'saa', 0),
(234568305, 0, 0, 'yuuuuuuuuu', 'asadas', 'trek', '11/08/2012', 16, 'female', 'qwqwq', 'qwqwq', 0),
(234568306, 0, 0, 'yuuuuuuuuu', 'asadas', 'trek', '11/08/2012', 16, 'female', 'qwqwq', 'qwqwq', 0),
(234568307, 0, 0, 'zzzzzzzzz', 'zzzzzzzz', 'zzzzzzzzz', 'z', 0, 'female', 'z', 'z', 110),
(234568308, 0, 0, 'zzzzzzzzz', 'zzzzzzzz', 'zzzzzzzzz', 'z', 0, 'female', 'z', 'z', 110),
(234568309, 0, 0, 'zzzzzzzzz', 'zzzzzzzz', 'zzzzzzzzz', 'z', 0, 'female', 'z', 'z', 110),
(234568310, 0, 0, 'adadadad', 'asadas', 'ddddd', '', 0, 'Choose', '', '', 110),
(234568311, 0, 0, 'aaaaaaaa', 'aaaaaaaa', 'asasa', 'aaaaaaaa', 0, 'male', '', 'asaa', 110);

-- --------------------------------------------------------

--
-- Table structure for table `sw_approval`
--

CREATE TABLE `sw_approval` (
  `app_id` int(255) NOT NULL,
  `pre_id` int(11) NOT NULL,
  `bar_id` int(3) NOT NULL,
  `mun_id` int(3) NOT NULL,
  `status` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sw_approval`
--

INSERT INTO `sw_approval` (`app_id`, `pre_id`, `bar_id`, `mun_id`, `status`) VALUES
(17, 234568297, 0, 0, 1),
(18, 234568298, 2, 1, 1),
(19, 234568299, 3, 1, 0),
(20, 234568300, 0, 0, 0),
(21, 234568301, 0, 0, 0),
(22, 234568302, 0, 0, 0),
(23, 234568303, 0, 0, 0),
(24, 234568304, 0, 0, 0),
(25, 234568305, 0, 0, 0),
(26, 234568306, 0, 0, 0),
(27, 234568307, 0, 0, 0),
(28, 234568308, 0, 0, 0),
(29, 234568309, 0, 0, 0),
(30, 234568310, 0, 0, 0),
(31, 234568311, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `town`
--

CREATE TABLE `town` (
  `idtown` int(10) UNSIGNED NOT NULL,
  `town_name` varchar(45) NOT NULL DEFAULT '',
  `underweight` varchar(45) NOT NULL DEFAULT '',
  `overweight` varchar(45) NOT NULL DEFAULT '',
  `normal` varchar(45) NOT NULL DEFAULT '',
  `obese` varchar(45) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `userposition_id`
--

CREATE TABLE `userposition_id` (
  `up_id` int(8) NOT NULL,
  `positions` varchar(45) NOT NULL DEFAULT '0',
  `level` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userposition_id`
--

INSERT INTO `userposition_id` (`up_id`, `positions`, `level`) VALUES
(4, 'bhw', 0),
(5, 'socialworkers', 1),
(6, 'nutritionist', 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `mun_id` varchar(100) NOT NULL,
  `bar_id` int(11) NOT NULL,
  `firstname` varchar(45) NOT NULL DEFAULT '',
  `middlename` varchar(45) NOT NULL DEFAULT '',
  `lastname` varchar(45) NOT NULL DEFAULT '',
  `bdate` varchar(45) NOT NULL DEFAULT '',
  `age` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `gender` varchar(45) NOT NULL DEFAULT '',
  `contact number` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `email` varchar(45) NOT NULL DEFAULT '',
  `position` varchar(45) NOT NULL DEFAULT '',
  `img` blob NOT NULL,
  `barangay` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `mun_id`, `bar_id`, `firstname`, `middlename`, `lastname`, `bdate`, `age`, `gender`, `contact number`, `email`, `position`, `img`, `barangay`) VALUES
(110, '', 0, 'alyl', 'bhw', 'alylm@gmail.com', '', 0, '', 0, '', '', '', ''),
(111, '1', 0, 'Tracy Guazon', '1', 'trg@gmail.com', '', 0, '', 0, '', '', '', ''),
(112, '', 0, 'ericka marbella', '2', 'marbea@fmail.com', '', 0, '', 0, '', '', '', ''),
(113, '', 0, 'bob', '0', 'marbellacaryll@gmail.com', '', 0, '', 0, '', '', '', ''),
(114, '', 0, 'erwin marbella', '0', 'marbellaaer@gmail.com', '', 0, '', 0, '', '', '', ''),
(115, '', 0, 'jdasgdj', '0', 'erickamaemarbella@gmail.com', '', 0, '', 0, '', '', '', ''),
(116, '', 0, 'arwinm', 'bhw', 'arwinm@gmail.com', '', 0, '', 0, '', '', '', ''),
(117, '', 0, '', '', '', '', 0, '', 0, 'woyriquh@gmail.com', '0', '', ''),
(118, '', 0, 'rweuio', '', '', '', 0, '', 0, 'wqrewrteyrutio@gmail.com', '1', 0x34363138323832385f3237363531313333393732333937345f363534303533333738393238383832343833325f6e2e6a7067, ''),
(119, '', 0, 'victoring', '', '', '', 0, '', 0, 'victtt@gmail.com', '0', 0x34363138323832385f3237363531313333393732333937345f363534303533333738393238383832343833325f6e2e6a7067, '');

-- --------------------------------------------------------

--
-- Table structure for table `user_access`
--

CREATE TABLE `user_access` (
  `user_acc_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `level` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `username` varchar(45) NOT NULL DEFAULT '',
  `password` varchar(45) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_access`
--

INSERT INTO `user_access` (`user_acc_id`, `user_id`, `level`, `username`, `password`) VALUES
(104, 110, 0, 'alylm', 'alylm123'),
(105, 111, 1, 'tracyg', 'tracy123'),
(106, 0, 2, 'em', 'em12345'),
(107, 0, 0, 'bhw', 'saaa'),
(108, 0, 0, 'lolopp', 'loloppp123'),
(109, 0, 0, 'dasdasda', 'dasdad'),
(110, 116, 0, 'arwinm', 'arwinm123'),
(111, 0, 0, 'vic', 'vic123'),
(112, 0, 0, 'uiew', 'oiqueqoeoiq'),
(113, 0, 1, 'oiuuytyrtewreqd', 'wqeqweqqeq'),
(114, 119, 0, 'victor', '1234'),
(115, 0, 1, 'haha', 'haha'),
(116, 0, 1, 'tga', 'tga'),
(117, 0, 1, 'for', 'for'),
(118, 0, 1, 'asasasa', 'asasas');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`addr_id`);

--
-- Indexes for table `albay_town`
--
ALTER TABLE `albay_town`
  ADD PRIMARY KEY (`idalbay_town`);

--
-- Indexes for table `barangay`
--
ALTER TABLE `barangay`
  ADD PRIMARY KEY (`bar_id`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`logs_id`);

--
-- Indexes for table `municipality`
--
ALTER TABLE `municipality`
  ADD PRIMARY KEY (`mun_id`);

--
-- Indexes for table `nutritional_status`
--
ALTER TABLE `nutritional_status`
  ADD PRIMARY KEY (`nutri_id`);

--
-- Indexes for table `parent_info`
--
ALTER TABLE `parent_info`
  ADD PRIMARY KEY (`par_id`);

--
-- Indexes for table `phone`
--
ALTER TABLE `phone`
  ADD PRIMARY KEY (`phone_id`);

--
-- Indexes for table `physical_info`
--
ALTER TABLE `physical_info`
  ADD PRIMARY KEY (`phy_id`);

--
-- Indexes for table `preschooler`
--
ALTER TABLE `preschooler`
  ADD PRIMARY KEY (`pre_id`);

--
-- Indexes for table `sw_approval`
--
ALTER TABLE `sw_approval`
  ADD PRIMARY KEY (`app_id`);

--
-- Indexes for table `town`
--
ALTER TABLE `town`
  ADD PRIMARY KEY (`idtown`);

--
-- Indexes for table `userposition_id`
--
ALTER TABLE `userposition_id`
  ADD PRIMARY KEY (`up_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_access`
--
ALTER TABLE `user_access`
  ADD PRIMARY KEY (`user_acc_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `addr_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `albay_town`
--
ALTER TABLE `albay_town`
  MODIFY `idalbay_town` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `barangay`
--
ALTER TABLE `barangay`
  MODIFY `bar_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `comment_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `logs_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `municipality`
--
ALTER TABLE `municipality`
  MODIFY `mun_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `nutritional_status`
--
ALTER TABLE `nutritional_status`
  MODIFY `nutri_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `parent_info`
--
ALTER TABLE `parent_info`
  MODIFY `par_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=165;

--
-- AUTO_INCREMENT for table `phone`
--
ALTER TABLE `phone`
  MODIFY `phone_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `physical_info`
--
ALTER TABLE `physical_info`
  MODIFY `phy_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=334;

--
-- AUTO_INCREMENT for table `preschooler`
--
ALTER TABLE `preschooler`
  MODIFY `pre_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=234568312;

--
-- AUTO_INCREMENT for table `sw_approval`
--
ALTER TABLE `sw_approval`
  MODIFY `app_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `town`
--
ALTER TABLE `town`
  MODIFY `idtown` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `userposition_id`
--
ALTER TABLE `userposition_id`
  MODIFY `up_id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=120;

--
-- AUTO_INCREMENT for table `user_access`
--
ALTER TABLE `user_access`
  MODIFY `user_acc_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=119;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
