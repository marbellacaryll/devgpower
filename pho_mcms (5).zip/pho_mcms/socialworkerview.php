<?php

session_start();
include("connection.php");
include('sw_header.php');

if ($_SESSION['username']==true) {
	echo "welcome"." ".$_SESSION['username'];
}
else{
	header("location:mockindex.php");
}

	//Approve Data from BHW
	if(isset($_GET['approve'])){
		$approve = $_GET['approve'];
		$query = mysqli_query($conn, "UPDATE sw_approval SET status = 1 WHERE bar_id='{$approve}'");
	}

//Redo Action
	if(isset($_GET['refresh'])){
		$refresh = $_GET['refresh'];
		$query = mysqli_query($conn, "UPDATE sw_approval SET status=0 WHERE bar_id='{$refresh}'");
	}
?>
<a href="mocklogout.php">LOGOUT</a>

<?php
$username=$_SESSION['username'];
$query1=mysqli_query($conn, "SELECT * FROM user_access WHERE username='{$username}'");
$row1=mysqli_fetch_array($query1);
$mun_id=$row1['mun_id'];
$query=mysqli_query($conn, "SELECT * FROM sw_approval WHERE mun_id='$mun_id'   GROUP BY bar_id ");

$rowcount=mysqli_num_rows($query);


?>
<body>
	<div class="w3-container" style="width: 1100px; margin-left: 236px; margin-top: -10px;">
		<div class="card">
			<div id="obese_list" class="card-body">
				<table id="myTable" class="w3-table w3-tiny table-bordered table-hover">
				<thead>
					<th>BARANGAY</th>
					<th>STATUS</th>	
				</thead>
				
				<?php
				for ($i=0; $i<=$rowcount; $i++) { 
				$row=mysqli_fetch_array($query);

			
				$bar_id = $row['bar_id'];
				$preschooler = "SELECT * FROM sw_approval 
				WHERE  bar_id='{$bar_id}'
				GROUP BY bar_id";
				$output = $conn->query($preschooler);
	 			while($pre = $output->fetch_assoc()){

					$bar_id = $pre['bar_id'];
					$xxx = mysqli_query($conn, "SELECT * FROM barangay 
					WHERE  bar_id='{$bar_id}' 
					GROUP BY bar_id ");
					$cliii = mysqli_fetch_array($xxx);

				
					$x = mysqli_query($conn, "SELECT * FROM sw_approval 
					WHERE  bar_id='{$bar_id}' AND status=0
					GROUP BY status ");
					$cli = mysqli_fetch_array($x);

					
					$xx = mysqli_query($conn, "SELECT * FROM sw_approval 
					WHERE  bar_id='{$bar_id}' AND status=1
					GROUP BY status ");
					$clii = mysqli_fetch_array($xx);

				
					echo "
					<tr>
					<td><span class='glyphicon glyphicon-user'></span><b><a href = 'sw_view_preschooler.php?bar_id=".$cli['bar_id']."&status=".$cli['status']."&mun_id=".$cli['mun_id']."'style ='text-decoration:none; color:Green;'>".ucwords($cliii['barangay_name'])."</a></td>
					
					<td>
					
					";
					//pending for approval of the social workers
					if ($cli['status']==0) {
						echo "Pending for approval";

					}

				
					


				}
			}
			?>
			</table>
		</div>
	</div>
</body>		