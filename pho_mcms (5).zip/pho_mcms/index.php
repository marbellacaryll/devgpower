
<link rel="stylesheet" type="text/css" href="../pho_mcms/css/w3.css">
<link rel="stylesheet" type="text/css" href="../pho_mcms/css/font_style.css">
<link rel="stylesheet" type="text/css" href="../pho_mcms/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../pho_mcms/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="../oshop/css/w3-colors-flat.css">

<?php

session_start();
include('connection.php');

if (isset($_REQUEST['loginbutton'])) {
  $username=$_REQUEST['username'];
  $password=$_REQUEST['password'];

  index($username,$password);
  }
    function index($username,$password){
      include("connection.php");
  $sql_index = "SELECT * FROM `user_access` 
  WHERE username='{$username}' 
  AND password='{$password}' ";

  $query=mysqli_query($conn, "SELECT * FROM user_access 
    WHERE username='{$username}' 
    AND password='{$password}'");

  $result_show_account = $conn->query($sql_index);
    $cnt = $result_show_account->num_rows;
    if ($result_show_account->num_rows >0) {

    $user = $result_show_account ->fetch_array();
      $_SESSION['user_acc_id']=$user['user_id'];
      $_SESSION['mun_id']=$user['mun_id'];
      $_SESSION['level']=$user['level'];
      if($user['status'] == 'Active'){
    if ($user['level']==0) {
      $_SESSION['username']=$username;
      header("location:bhw_add_preschooler_form.php");
    }
    if ($user['level']==1) {
      $_SESSION['username']=$username;
      header("Location:socialworkerview.php");
    }
    if ($user['level']==2) {
      header("Location:nutritionist_home.php");
    }
  }else{
    $_SESSION['error']= "User Account does not exist";
  }
}
}

?>

<body>
  <form action="index.php" method="POST">
  <div class="container">
    <div class="card">
      <h1>LOGIN FORM</h1>
      <br>
      <br>
      <br>
      <p>Username:</p>
      <input type="text" name="username" class="w3-input w3-small" placeholder="Enter your username..." required="autofocus">
      <br>
      <br>
      <p>Password:</p>
      <input type="password" name="password" class="w3-input w3-small" placeholder="Enter your password..." required="autofocus">

      <input type="submit" name="loginbutton" id="login_submit" class="w3-button w3-small w3-blue  w3-round-xxlarge" value="L O G I N">
      <center>
      <p>New User? <a href="register_accountm.php"><b class="register">Register</b></a> here</p>
      <p class="small" style="color: #adacac">Marbella | Guazon</p>
    </div>
  </div>
</body>


<style>
  body {
    background-image: url(../pho_mcms/img/index_bg.jpg);
    background-repeat: no-repeat;
  }

  @media (max-width: 960px;) {
    .w3-container {
      width: auto;
    }
  }
  .card {
    margin: auto;
    margin-top: 65px;
    width: 420px;
    height: 520px;
    padding: 20px;
    border-radius: 20px; 
    background-image: url(../pho_mcms/img/card1.jpg);
    background-repeat: no-repeat;
    background-size: 420px 117px;
  }

  h1 {
    margin-top: 15px;
    margin-left: 70px;
    color: #fff;
  }

  .card_malchi {
    height: 10px;
    width: 60px;
  }

  @font-face{
    font-family: "RobotoSlab-Light";
    src:url(../pho_mcms/fonts/RobotoSlab-Light.ttf) format("truetype");
  }

  p {
    font-family: RobotoSlab-Light, sans-serif;
  }

  .w3-input {
    font-family: RobotoSlab-Light, sans-serif;
  }

  #login_submit {
    margin: auto;
    width: 280px;
    font-family: RobotoSlab-Light, sans-serif;
  }

  .register {
    color: #ae0a0a;
  }
</style>