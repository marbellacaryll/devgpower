<?php
include('connection.php');
include('nutritionist_header.php');
?>
<?php
if(isset($_POST['sbt-deactivate'])){
 
   $id=$_GET['user_acc_id'];
   $deactivate="Inactive";

  $query = mysqli_query($conn, "UPDATE user_access SET status = '{$deactivate}' WHERE user_acc_id = '{$id}'");
  header('location:bhw_approve_account.php?mes=Updated!');
}
  

if(isset($_POST['sbt-activate'])){
  
   $id=$_GET['user_acc_id'];
   $activate="Active";
  
  $query = mysqli_query($conn, "UPDATE user_access SET status = '{$activate}' WHERE user_acc_id = '{$id}'");
  header('location:bhw_approve_account.php?mes=Updated!');
}



?>
<body>
	<div class="w3-container" style="width: 1100px; margin-left: 236px; margin-top: -10px;">
		<div class="card">
			<div id="malnourished_children_result" class="card_body">
				<table id="myTable" class="w3-table w3-tiny table-bordered table-hover">
					<thead class="w3-tiny">
						<th class="w3-tiny">firstname</th>
						<th class="w3-tiny">position</th>
						<th class="w3-tiny">municipality</th>
						<th class="w3-tiny">email</th>
						<th class="w3-tiny">username</th>
						<th class="w3-tiny">password</th>
						<th>Control</th>
					</thead>
					<?php
				$query=mysqli_query($conn, "SELECT * FROM user_access 
					WHERE level=0");
				while($ownAcc = mysqli_fetch_array($query)){
					$user_acc_id = $ownAcc['user_acc_id'];
			 		$userId = $ownAcc['user_id'];
					$query_for_users = mysqli_query($conn, "SELECT * FROM users 
						WHERE user_id='{$userId}'");
					$users = mysqli_fetch_array($query_for_users);
				echo "
				<tr> <form action='bhw_approve_account.php?user_acc_id=$user_acc_id' method = 'POST' >
				<td>".$users['firstname']."</td>
				<td>".$users['position']."</td>
				<td>".$users['municipality']."</td>
				<td>".$users['email']."</td>
				<td>".$ownAcc['username']."</td>
				<td>".$ownAcc['password']."</td>
			
				";
				if($ownAcc['status'] == 'Active'){
              echo "<td><button type='submit' name='sbt-deactivate' style='color:red'>DEACTIVATE</button></td>";
            }else{
              echo "<td><button type='submit' name='sbt-activate'  style='color:blue'>ACTIVATE</button></td>
             ";

            }
            echo "</form></tr>";
			}
				?>
				</table>
			</div>
		</div>
	</div>
</body>