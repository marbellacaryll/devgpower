<?php
include('connection.php');
include('bhw_header.php');

if (isset($_GET['id'])) {
  $profile_id=$_GET['id'];


  $sql_update_profile=mysqli_query($conn, "SELECT * FROM users 
    WHERE user_id='{$profile_id}'");

  if(mysqli_num_rows($sql_update_profile)){
    $result3=mysqli_fetch_array($sql_update_profile);
  }
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<!--<form action="bhw_add_preschooler_script.php?id=<?php //echo $_GET ['id']?> " method="POST"><-->
		<div class="w3-container" style="width: 1100px; margin-left: 236px; margin-top: 40px;">
			<div class="card">
				<div class="card-body">
					<form name="basicform" id="basicform" action="create_account.php?id=<?php echo $_GET ['id']?>" method="POST">
						<div class="w3-row-padding">
							<div class="w3-third">
								<p class="w3-tiny">FIRST NAME:
									<input type="text" name="update_firstname" class="w3-input w3-border w3-tiny" value="<?php echo $result3['firstname']; ?>">
								</p>
							</div>
							<div class="w3-third">
								<p class="w3-tiny">MIDDLE NAME:
									<input type="text" name="update_middlename" class="w3-input w3-border w3-tiny" value="<?php echo $result3['middlename']; ?>">
								</p>
							</div>
							<div class="w3-third">
								<p class="w3-tiny">LAST NAME:
									<input type="text" name="update_lastname" class="w3-input w3-border w3-tiny" value="<?php echo $result3['lastname']; ?>">
								</p>
							</div>
							<div class="w3-third">
								<p class="w3-tiny">BIRTHDATE:
									<input type="text" name="update_bdate" id="date" class="w3-input w3-border w3-tiny" value="<?php echo $result3['bdate']; ?>">
								</p>
							</div>
							<div class="w3-third">
								<p class="w3-tiny">AGE:
									<input type="text" name="update_age" class="w3-input w3-border w3-tiny" value="<?php echo $result3['age']; ?>">
								</p>
							</div>
							<div class="w3-third">
			                  <p class="w3-tiny">GENDER:
			                    <select class="w3-select w3-input w3-border w3-tiny" name="update_gender" class="w3-input w3-border w3-tiny" value="<?php echo $result3['gender']; ?>">
			                      <option style="background-color: gray;">Choose</option>
			                      <option value="male">Male</option>
			                      <option value="female">Female</option>
			                    </select>
			                  </p>
			                </div>
			                <div class="w3-third">
								<p class="w3-tiny">CONTACT NUMBER:
									<input type="text" name="update_contact_number" class="w3-input w3-border w3-tiny" value="<?php echo $result3['contact_number']; ?>">
								</p>
							</div>
							<div class="w3-third">
								<p class="w3-tiny">EMAIL:									
									<input type="text" name="update_email" class="w3-input w3-border w3-tiny" value="<?php echo $result3['email']; ?>">
                  <br>
								</p>
							</div>
              <br>
              <input type="submit" name="updateProfile" class="w3-button w3-round-xxlarge w3-blue" value="Submit">
						</div>
					</form>
				</div>
			</div>
		</div>
	<!--</form><-->
</body>
</html>
<script src="../pho_mcms/js/jquery-1.11.1.js" type="text/javascript"></script>
<script src="../pho_mcms/js/bootstrap.min.js" type="text/javascript"></script>
<script src="../pho_mcms/js/jquery-ui-1.10.1.custom.min.js"></script>
<script>
$(function () {
    $('#date').datepicker({
      onSelect: function(value, ui) {
      var today = new Date(),
        dob = new Date(value),
        age = new Date(today - dob).getFullYear() - 1970;

      $('#age').val(age);
      
      },
    maxDate: '+0d',
    yearRange: '1900:2014',
    changeMonth: true,
    changeYear: true
  });
});
</script>

<script type="text/javascript" src="js/jquery.validate.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript">
  jQuery().ready(function() {

    // validate form on keyup and submit
    var v = jQuery("#basicform").validate({
      rules: {
        name: {
          required: true,
          minlength: 5,
          maxlength: 100
        }

      },
      errorElement: "span",
      errorClass: "help-inline-error",
    });

    $(".open1").click(function() {
      if (v.form()) {
        $(".frm").hide("fast");
        $("#sf2").show("slow");
      }
    });

    $(".open2").click(function() {
      if (v.form()) {
        $(".frm").hide("fast");
        $("#sf3").show("slow");
      }
    });

     $(".open3").click(function() {
      if (v.form()) {
        $(".frm").hide("fast");
        $("#sf4").show("slow");
      }
    });
    
    $(".open4").click(function() {
      if (v.form()) {
        $("#loader").show();
         setTimeout(function(){
           $("#basicform").html('<h2>Thanks for your time.</h2>');
         }, 1000);
        return false;
      }
    });
    
    $(".back2").click(function() {
      $(".frm").hide("fast");
      $("#sf1").show("slow");
    });

    $(".back3").click(function() {
      $(".frm").hide("fast");
      $("#sf2").show("slow");
    });
  
  $(".back4").click(function() {
      $(".frm").hide("fast");
      $("#sf3").show("slow");
    });
  
  $(".back5").click(function() {
      $(".frm").hide("fast");
      $("#sf4").show("slow");
    });

    $(".back6").click(function() {
      $(".frm").hide("fast");
      $("#sf5").show("slow");
    });
  
 });
</script>