<?php


    $dbHost = "localhost";
    $dbDatabase = "mcmsdb";
    $dbUser = "root";
    $dbPasswrod = "";
    


    $conn = mysqli_connect($dbHost, $dbUser, $dbPasswrod, $dbDatabase);
    
// populating graph by severely underweight children
$query = "SELECT bar_id ,SUM( health_status = 'This is considered as  severly Underweight') AS children FROM  physical_info  GROUP BY bar_id";
$result = mysqli_query($conn, $query);
$json = [];
    while($row = mysqli_fetch_assoc($result))
         {
              $pre_id = $row['bar_id'];
              $bar_id = $row['children'];

             $json[] =[(int)$pre_id, (int)$bar_id];
          }
    
    echo json_encode($json);

?>




