<?
include("connection.php");
 $query = mysqli_query($conn, "SELECT * FROM municipality");
 	if(mysql_num_rows($sql)){
 		$data = array();
 		while($row=mysql_fetch_data($query)){
 			$data[] = array(
 				'mun_id' => $row['mun_id']
 				'municipality' =>$row['municipality']
 			);
 		}
 		header('Content-type:application/json');
 		echo json_encode($data);
 	}
 ?>