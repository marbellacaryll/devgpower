<?php
  $dbHost = "localhost";
  $dbDatabase = "mcmsdb";
  $dbUser = "root";
  $dbPasswrod = "";
  
  $conn = mysqli_connect($dbHost, $dbUser, $dbPasswrod, $dbDatabase);

	//set timezone
	//date_default_timezone_set('Asia/Manila');

	//SEVERELY UNDERWEIGHT DATA FOR GRAPH BY MUNICIPALITY 
	$obtot=array();
	for($municipality = 1; $municipality <= 18; $municipality ++){
		$sql="SELECT *, COUNT(physical_info.mun_id) as children FROM physical_info JOIN sw_approval ON physical_info.bar_id = sw_approval.bar_id WHERE physical_info.mun_id = $municipality AND health_status ='This is considered as  Severly Underweight' AND status = 1 ";
		$query=$conn->query($sql);
		$row = mysqli_fetch_assoc($query);
		$obtot[]=$row['children'];
			}

				 $bac  = $obtot[0];
	 			 $cam  = $obtot[1];
				 $dar  = $obtot[2];
				 $gbtn = $obtot[3];
				 $jov  = $obtot[4];
				 $leg  = $obtot[5];
				 $lib  = $obtot[6];
				 $lig  = $obtot[7];
				 $malp = $obtot[8];
				 $maln = $obtot[9];
				 $mant = $obtot[10];
				 $oas  = $obtot[11];
				 $pio  = $obtot[12];
				 $pol  = $obtot[13];
				 $rap  = $obtot[14];
				 $sant = $obtot[15];
				 $tab  = $obtot[16];
				 $tiw  = $obtot[17];
	 			//SEVERELY UNDERWEIGHT ENDING


	//UNDERWEIGHT DATA FOR GRAPH BY MUNICIPALITY 
	$obunder=array();
	for($municipality = 1; $municipality <= 18; $municipality ++){
		$sql="SELECT *, COUNT(physical_info.mun_id) as children FROM physical_info JOIN sw_approval ON physical_info.bar_id = sw_approval.bar_id WHERE physical_info.mun_id = $municipality AND health_status ='This is considered as  Underweight' AND status = 1 ";
		$query=$conn->query($sql);
		$row = mysqli_fetch_assoc($query);
		$obunder[]=$row['children'];
			}

	 			 $bacun  = $obunder[0];
				 $camun  = $obunder[1];
				 $darun  = $obunder[2];
				 $gbtnun = $obunder[3];
				 $jovun  = $obunder[4];
				 $legun  = $obunder[5];
				 $libun  = $obunder[6];
				 $ligun  = $obunder[7];
				 $malpun = $obunder[8];
				 $malnun = $obunder[9];
				 $mantun = $obunder[10];
				 $oasun  = $obunder[11];
				 $pioun  = $obunder[12];
				 $polun  = $obunder[13];
				 $rapun  = $obunder[14];
				 $santun = $obunder[15];
				 $tabun  = $obunder[16];
				 $tiwun  = $obunder[17];
				 //UNDERWEIGHT ENDING


	//OBESE DATA FOR GRAPH BY MUNICIPALITY 
	$obess=array();
	for($municipality = 1; $municipality <= 18; $municipality ++){
		$sql="SELECT *, COUNT(physical_info.mun_id) as children FROM physical_info JOIN sw_approval ON physical_info.bar_id = sw_approval.bar_id WHERE physical_info.mun_id = $municipality AND health_status ='This is considered as  Obese' AND status = 1 ";
		$query=$conn->query($sql);
		$row = mysqli_fetch_assoc($query);
		$obess[]=$row['children'];
			}

				 $bacob  = $obess[0];
				 $camob =  $obess[1];
				 $darob  = $obess[2];
				 $gbtnob = $obess[3];
				 $jovob  = $obess[4];
				 $legob  = $obess[5];
				 $libob  = $obess[6];
				 $ligob  = $obess[7];
				 $malpob = $obess[8];
				 $malnob = $obess[9];
				 $mantob = $obess[10];
				 $oasob  = $obess[11];
				 $pioob  = $obess[12];
				 $polob  = $obess[13];
				 $rapob  = $obess[14];
				 $santob = $obess[15];
				 $tabob  = $obess[16];
				 $tiwob  = $obess[17];
	 			//OBESE ENDING

?>