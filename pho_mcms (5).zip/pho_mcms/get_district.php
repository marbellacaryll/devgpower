<?php
require_once("connection.php");
if(!empty($_POST["mun_id"])) 
{
$query =mysqli_query($con,"SELECT * FROM barangay WHERE mun_id = '" . $_POST["mun_id"] . "'");
?>
<option value="">Select District</option>
<?php
while($row=mysqli_fetch_array($query))  
{
?>
<option value="<?php echo $row["BarangayName"]; ?>"><?php echo $row["barangay_name"]; ?></option>
<?php
}
}
?>
