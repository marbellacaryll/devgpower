<html>
<head>
</head>
<body>
	<form action='retype-password.php' method='POST'>
		<input type='text' name='username' placeholder="Enter your Username">
		<input type='password' name='pass1' placeholder="Enter your Password">
		<input type='password' name='pass2' placeholder="Re-type your Password">
		<input type='submit' name='sbt-submit' value='Submit'>
	</form>
</body>
</html>

<?php

include('connection.php');

if(isset($_POST['sbt-submit'])){

	$username=$_POST['username'];
	$pass1=$_POST['pass1'];
	$pass2=$_POST['pass2'];

	register($username,$pass1,$pass2);
}

function register($username,$pass1,$pass2){

	include('../server/connection.php');

	if ($pass1 == $pass2){
		$sql = mysqli_query($con,"INSERT INTO useraccounts (username, password) 
			   VALUES ('{$username}', '{$pass2}')");

		header("location:retype-password.php?Msg=Added Successfully!");
	}else{

		header("location:retype-password.php?Msg=Mismatch Password!");

	}
}





?>