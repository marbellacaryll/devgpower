<?php

session_start();
include("connection.php");
include('sw_header.php');

if ($_SESSION['username']==true) {
	echo "welcome"." ".$_SESSION['username'];
}
else{
	header("location:mockindex.php");
}
?>
<a href="mocklogout.php">LOGOUT</a>

<?php
$username=$_SESSION['username'];
$query1=mysqli_query($conn, "SELECT * FROM user_access WHERE username='{$username}'");
$row1=mysqli_fetch_array($query1);
$user_id=$row1['user_id'];
$query=mysqli_query($conn, "SELECT * FROM sw_approval WHERE user_id='$user_id' AND `status` = 1 ORDER BY app_id DESC");

$rowcount=mysqli_num_rows($query);


?>
<body>
	<div class="w3-container" style="width: 1100px; margin-left: 236px; margin-top: -10px;">
		<div class="card">
			<div id="malnourish_children_result" class="card-body">
				<table id="myTable" class="w3-table w3-tiny table-bordered table-hover">
					<thead class="w3-tiny">
						<th class="w3-tiny">First Name</th>
						<th class="w3-tiny">Weight</th>
						<th class="w3-tiny">Height</th>
						<th class="w3-tiny">BMI</th>
						<th class="w3-tiny">Health Status</th>
						<th class="w3-tiny">Update</th>
					</thead>
					<?php
					for ($i=1; $i<=$rowcount; $i++) { 
						$row=mysqli_fetch_array($query);
					?>
					<?php
						$pre_id = $row['pre_id'];
	 					$preschooler = "SELECT * FROM sw_approval WHERE status='{$pre_id}'";
	 					$output = $conn->query($preschooler);
	 					$pre = $output->fetch_assoc();
					?>
					<tr>
						<td><?php echo $pre['pre_fname'] ?></td>
						<td><?php echo $row['weight'] ?></td>
						<td><?php echo $row['height'] ?></td>
						<td><?php echo $row['bmi'] ?></td>
						<td><?php echo $row['health_status'] ?></td>
						<?php
						echo "<td><a href='bhw_update_preschooler.php?id=".$pre['pre_id']."'><i class='now-ui-icons objects_support-17'></i></a></td>";
						?>
					</tr>
					<?php
				}
					?>
				</table>
			</div>
		</div>
	</div>
</body>