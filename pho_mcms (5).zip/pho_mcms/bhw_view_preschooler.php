<?php
include('connection.php');
include('bhw_header.php');
?>

<?php
$username=$_SESSION['username'];
$query1=mysqli_query($conn, "SELECT * FROM user_access WHERE username='{$username}'");
$row1=mysqli_fetch_array($query1);
$user_id=$row1['user_id'];
$query=mysqli_query($conn, "SELECT * FROM preschooler WHERE user_id='$user_id'");
$rowcount=mysqli_num_rows($query);
?>

<body>
	<div class="w3-container">
		<div id="normal_result" class="w3-tiny w3-card" style="padding: 30px; width: 998px; margin-left: 300px; margin-top: 90px;">
					<table id="myTable" class="w3-table table-bordered w3-tiny table-hover">
						<thead class="w3-tiny">
							<th class="w3-tiny">Weight</th>
							<th class="w3-tiny">Height</th>
							<th class="w3-tiny">BMI</th>
							<th class="w3-tiny">Health Status</th>
						</thead>

						<?php
$query = mysqli_query($conn, "SELECT * FROM `physical_info` WHERE `health_status` = 'This is considered as  normal'");
				 	while($ser = mysqli_fetch_array($query)){

							echo "
							<tr>
							
							
							<td>".$ser['weight']."</td>
							<td>".$ser['height']."</td>
							<td>".$ser['bmi']."</td>
							<td>".$ser['health_status']."</td>
							</tr>
							";
						}
						?>
					</table>
				</div>
			</div>
		</div>
	</div>

	<a href="bhw_add_preschooler-form.php">back</a>
</body>


<script type="text/javascript">
	$(document).ready(function(){
		$('#normal_result').keyup(function(){
			var searchVal = $.trim($(this).val());
			$.get('bhw_search.php?search_malnourish_children='+searchVal,function(returnData){
				$('#normal_result').html(returnData)
			});
		}
	});



</script>