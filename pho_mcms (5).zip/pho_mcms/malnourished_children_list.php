<?php

session_start();
include("connection.php");

if ($_SESSION['username']==true) {
	echo "welcome"." ".$_SESSION['username'];
}
else{
	header("location:mockindex.php");
}
?>
<a href="mocklogout.php">LOGOUT</a>

<?php
$username=$_SESSION['username'];
$query1=mysqli_query($conn, "SELECT * FROM user_access WHERE username='{$username}'");
$row1=mysqli_fetch_array($query1);
$user_id=$row1['user_id'];
$query=mysqli_query($conn, "SELECT * FROM physical_info WHERE user_id='$user_id' AND `health_status` = 'This is considered as  severly Underweight' ORDER BY phy_id DESC");

$rowcount=mysqli_num_rows($query);


?>

<body>
	<div class="w3-container">
		<div id="malnourish_children_result" class="w3-tiny w3-card" style="padding: 30px; width: 998px; margin-left: 300px; margin-top: 90px;">
			<!--<div class="w3-card" style="width: 1000px; margin-left: 295px; margin-top: 100px; padding: 20px; height: 500px;"><-->
				<!--<div class="w3-card-body"><-->
					<table id="myTable" class="w3-table table-bordered w3-tiny table-hover">
						<thead class="w3-tiny">
							<th class="w3-tiny">ID</th>
							<th class="w3-tiny">Weight</th>
							<th class="w3-tiny">Height</th>
							<th class="w3-tiny">BMI</th>
							<th class="w3-tiny">Health Status</th>
						</thead>
<?php
	for ($i=1; $i<=$rowcount; $i++) { 
		$row=mysqli_fetch_array($query);
	?>

	<?php
	//View Stock of product
 		$pre_id = $row['pre_id'];
	 	$preschooler = "SELECT * FROM preschooler WHERE pre_id='{$pre_id}'";
	 	$output = $conn->query($preschooler);
	 	$pre = $output->fetch_assoc();
	?>

	<tr>
		<td><?php echo $pre['pre_fname'] ?></td>
		<td><?php echo $row['weight'] ?></td>
		<td><?php echo $row['height'] ?></td>
		<td><?php echo $row['bmi'] ?></td>
		<td><?php echo $row['health_status'] ?></td>
	</tr>



	<?php
}
	?>
</table>
<br>
<a href="bhwmake.php">BACK</a>