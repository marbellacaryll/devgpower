$(document).ready(function(){
//=====================================================================general=============================
    $('[data-toggle="popover"]').popover();   
//=====================================================================create_subj.php=====================
	$('#sub_num').change(function(){
		var id = $.trim($(this).val());
		if(id!=0){
		$.get('preload_sub.php?pre_id='+id, function(returnData) {
			$('#preload').html(returnData);
			$('#create_subject').css('display','block');
		});		
		}else{
			$('#preload').html('Choose Subject to Create');
			$('#create_subject').css('display','none');
		}
	});	
	$('#create_subject').click(function(){
		var sub_no = $.trim($('#sub_no').val());
		var sub_desc = $.trim($('#sub_desc').val());
		var sub_unit = $.trim($('#sub_unit').val());
		var sem = $.trim($('#sem').val());
		var sy = $.trim($('#sy').val());
		var gformat = $.trim($('#gformat').val());
		var lec_per = $.trim($('#lec_per').val());
		var lab_per = $.trim($('#lab_per').val());
		var lec = Number(lec_per);
		var lab = Number(lab_per);
		var fid = $.trim($('#fids').val());
		var type ="create_subject";
		
		if(lec+lab==100){
			if (sub_no !="" && sub_desc!="" && sub_unit!="" && sem!="" && sy!=""){
				$.get('db/server.php?type='+type+'&sub_no='+sub_no+'&sub_desc='+sub_desc+'&sub_unit='+sub_unit+'&sem='+sem+'&sy='+sy+'&fid='+fid+'&lab_per='+lab_per+'&lec_per='+lec_per+'&gformat='+gformat, function(returnData) {
					if(returnData=="error"){
						$('.errorcreation').html('Subject already exists, check your subject lists');
					}else{
						$(location).attr('href', 'update_subj2.php?sub_id='+returnData+'&mode=11&term=1');
						
					}
				});		
			}		
		}else{
			$('.errorcreation').html('Total Percentage must be equal to 100 to avoid errors on computation');
		}	
	});
//=======================================================================update_subj.php===================
	$('#sch_subj').keyup(function() {
		var sch = $.trim($(this).val());
		var fid = $.trim($('#fid').val());
		if(sch ==""){
			$('#subj_view').css("display","block");
			$('#subj_view2').css("display","none");
		}else{
			$.get('search_subj.php?fid='+fid+'&sch='+sch, function(returnData){
				$('#subj_view').css("display","none");
				$('#subj_view2').css("display","block");
				$('#subj_view2').html(returnData);
			});	
		}	
	});
//=======================================================================update_subj2.php===================	
	$('#gformat2').change(function(){
		var value = $(this).val();
		if(value==1){
			$('#lec_no_items').attr('disabled',false);
			$('#lec_rub_grp').attr('disabled',true);
			$('#lab_no_items').attr('disabled',false);
			$('#lab_rub_grp').attr('disabled',true);
		} else if(value==2){
			$('#lec_no_items').attr('disabled',true);
			$('#lec_rub_grp').attr('disabled',false);
			$('#lab_no_items').attr('disabled',true);
			$('#lab_rub_grp').attr('disabled',false);
		}
	});
	$('#lec_group').change(function(){
		var value = $(this).val();
		if(value==1){
			$('#gformat2').attr('disabled',false);
			$('#lec_no_items').attr('disabled',false);
			$('#lec_rub_grp').attr('disabled',false);
			$('#lec_ass').attr('disabled',false);
			$('#lec_rub_grp').attr('disabled',true);
		} else if(value==2){
			$('#gformat2').attr('disabled',true);
			$('#lec_no_items').attr('disabled',true);
			$('#lec_rub_grp').attr('disabled',true);
			$('#lec_ass').attr('disabled',true);
			$('#lec_rub_grp').attr('disabled',true);
		}
	});
	$('#lab_group').change(function(){
		var value = $(this).val();
		if(value==1){
			$('#gformat2').attr('disabled',false);
			$('#lab_no_items').attr('disabled',false);
			$('#lab_rub_grp').attr('disabled',false);
			$('#lab_ass').attr('disabled',false);
			$('#lab_rub_grp').attr('disabled',true);
		} else if(value==2){
			$('#gformat2').attr('disabled',true);
			$('#lab_no_items').attr('disabled',true);
			$('#lab_rub_grp').attr('disabled',true);
			$('#lab_ass').attr('disabled',true);
			$('#lab_rub_grp').attr('disabled',true);
		}
	});
	$('#sub_gformat2').change(function(){
		var value = $(this).val();
		if(value==1){
			$('#sub_lec_no_items').attr('disabled',false);
			$('#sub_lec_rub_grp').attr('disabled',true);
			$('#sub_lab_no_items').attr('disabled',false);
			$('#sub_lab_rub_grp').attr('disabled',true);
		} else if(value==2){
			$('#sub_lec_no_items').attr('disabled',true);
			$('#sub_lec_rub_grp').attr('disabled',false);
			$('#sub_lab_no_items').attr('disabled',true);
			$('#sub_lab_rub_grp').attr('disabled',false);
		}
	});
	$('#rubricview2').on('show.bs.modal', function(e) {
		//get data-id attribute of the clicked element
		var rubId = $(e.relatedTarget).data('book-id');
		$.get('rubric/rubricview.php?rub_id='+rubId, function(returnData) {
			$('#rubview2').html(returnData);
		});		
	});
//=============================================================addrub.php===========================================
	
	$('#rubricview').on('show.bs.modal', function(e) {
		//get data-id attribute of the clicked element
		var rubId = $(e.relatedTarget).data('book-id');
		$.get('rubric/rubricview.php?rub_id='+rubId, function(returnData) {
			$('#rubview').html(returnData);
		});		
	});
//===========================================================addstud.php=============================================
	$('#create_student').click(function(){
		var first_name = $.trim($('#first_name').val());
		var last_name = $.trim($('#last_name').val());
		var course = $.trim($('#course').val());
		var fid = $.trim($('#fid').val());
		var type ="create_student";
		if (first_name !="" && last_name!="" && course!=""){
			$.get('db/server.php?type='+type+'&first_name='+first_name+'&last_name='+last_name+'&course='+course+'&fid='+fid, function(returnData) {
				$('#res').html(returnData);
			});		
		}		
	});	
	$('#choose_sub').change(function(){
		var sub_id = $.trim($(this).val());	
		$.get('../server/server.php?choosesub=0&sub_id='+sub_id, function(returnData) {
			$('#sub_info').html(returnData);
		});
		$.get('../server/server.php?studlist=0&sub_id='+sub_id, function(returnData) {
			$('#stud_list_search').html(returnData);
		});
		$.get('../server/server.php?studlistinfo=0&sub_id='+sub_id, function(returnData) {
			$('#stud_list_info').html(returnData);
		});
	});	
	$('#add_stud_subj_list').keyup(function() {
		var searchVal = $.trim($(this).val());
		var sub_id = $.trim($('#choose_sub').val());	
		if(searchVal==""){
			$.get('../server/server.php?studlist=0&sub_id='+sub_id, function(returnData) {
				$('#stud_list_search').html(returnData);
			});
		}else{
		$.get('../server/server.php?studlist=0&sub_id='+sub_id+'&lname='+searchVal, function(returnData) {
				$('#stud_list_search').html(returnData);
			});
		}
	});
	
//=====================================================grade_subj.php===========================
	$('#sch_subj2').keyup(function() {
		var sch = $.trim($(this).val());
		var fid = $.trim($('#fid').val());
		if(sch ==""){
			$('#subj_view').css("display","block");
			$('#subj_view2').css("display","none");
		}else{
			$.get('search_subj2.php?fid='+fid+'&sch='+sch, function(returnData){
				$('#subj_view').css("display","none");
				$('#subj_view2').css("display","block");
				$('#subj_view2').html(returnData);
			});	
		}	
	});
	$('#rate_sub_select').change(function(){
		var sub_id = $.trim($(this).val());
		$.get('sample2.php?term=1&sub_id='+sub_id, function(returnData) {
			$('#rate_subject_box').html(returnData);
		});		
	});	
	$('.ass_input_click').click(function(){
		var row1 = $(this).closest("tr");	
		row1.find(":text").each(function(){
			$(this).attr('disabled',true);
		});	
		row1.find(":hidden").each(function(){
			$(this).attr('disabled',true);
		});	
		$(this).find(":text").attr('disabled',false);
		$(this).find(":hidden").attr('disabled',false);
	});
	$('.input_grade_click').click(function(){
		var row1 = $(this).closest("tr");	
		row1.find(":text").each(function(){
			$(this).attr('disabled',true);
		});	
		row1.find(":hidden").each(function(){
			$(this).attr('disabled',true);
		});	
		$(this).find(":text").attr('disabled',false);
		$(this).find(":hidden").attr('disabled',false);
	});
	$('.head').click(function(){
		
		var id = $(this).attr('name');
		$('#grade_format1').find(":text").each(function(){
			$(this).attr('disabled',true);
		});	
		$('#grade_format1').find(":hidden").each(function(){
			$(this).attr('disabled',true);
		});	
		$('#grade_format1').find("input[type='text'][class$='in"+id+"']").attr('disabled',false);
		$('#grade_format1').find("input[type='text'][class$='in"+id+"']").attr('disabled',false);
	});	
	$('.lecturecrit').click(function(){	
		var id = $(this).attr('id');
		$('#grade_format1').find("input").each(function(){
			$(this).attr('disabled',true);
		});	
		$('#grade_format1').find(":hidden").each(function(){
			$(this).attr('disabled',true);
		});	
			$('#grade_format1').find('.lec'+id).attr('disabled',false);
			$('#grade_format1').find("input[type='hidden'][class$='lec"+id+"']").attr('disabled',false);	
			$('#grade_format1').find("input[type='hidden'][class$='counter']").attr('disabled',false);	
			$('#grade_format1').find("input[type='hidden'][id$='lecture_grade']").attr('disabled',false);	
	});
	$('.lecturesubcrit').click(function(){	
		var id = $(this).attr('id');
		$('#grade_format1').find("input").each(function(){
			$(this).attr('disabled',true);
		});	
		$('#grade_format1').find(":hidden").each(function(){
			$(this).attr('disabled',true);
		});	
			$('#grade_format1').find('.lecsub'+id).attr('disabled',false);
			$('#grade_format1').find("input[type='hidden'][class$='lecsub"+id+"']").attr('disabled',false);	
			$('#grade_format1').find("input[type='hidden'][class$='counter']").attr('disabled',false);	
			$('#grade_format1').find("input[type='hidden'][id$='lecture_subgrade']").attr('disabled',false);	
	});	
	$('.laboratorycrit').click(function(){	
		var id = $(this).attr('id');
		$('#grade_format1').find("input").each(function(){
			$(this).attr('disabled',true);
		});	
		$('#grade_format1').find(":hidden").each(function(){
			$(this).attr('disabled',true);
		});	
			$('#grade_format1').find('.lab'+id).attr('disabled',false);
			$('#grade_format1').find("input[type='hidden'][class$='lab"+id+"']").attr('disabled',false);	
			$('#grade_format1').find("input[type='hidden'][class$='counter']").attr('disabled',false);	
			$('#grade_format1').find("input[type='hidden'][id$='laboratory_grade']").attr('disabled',false);	
	});
	$('.laboratorysubcrit').click(function(){	
		var id = $(this).attr('id');
		$('#grade_format1').find("input").each(function(){
			$(this).attr('disabled',true);
		});	
		$('#grade_format1').find(":hidden").each(function(){
			$(this).attr('disabled',true);
		});	
			$('#grade_format1').find('.labsub'+id).attr('disabled',false);
			$('#grade_format1').find("input[type='hidden'][class$='labsub"+id+"']").attr('disabled',false);	
			$('#grade_format1').find("input[type='hidden'][class$='counter']").attr('disabled',false);	
			$('#grade_format1').find("input[type='hidden'][id$='laboratory_subgrade']").attr('disabled',false);	
	});	
	$('#rubricview3').on('show.bs.modal', function(e) {
		//get data-id attribute of the clicked element
		var rubId = $(e.relatedTarget).data('book-id');
		var studId = $(e.relatedTarget).data('book-student');
		var dbtable = $(e.relatedTarget).data('book-dbtable');
		var ids = $(e.relatedTarget).data('book-ids');
		var sub_id = $(e.relatedTarget).data('book-subid');
		var term = $(e.relatedTarget).data('book-term');
		var mode = $(e.relatedTarget).data('book-mode');
		$.get('rubric/rubricview2.php?rub_id='+rubId+'&stud_id='+studId+'&dbtable='+dbtable+'&ids='+ids+'&term='+term+'&mode='+mode+'&sub_id='+sub_id, function(returnData) {
			$('#rubview3').html(returnData);
		});		
	});
	$("#print_grade_detailed").click(function(){
		var divContents = $('#grade_detailed').html();
		var printWindow = window.open('','', height=400,width=800)	;
		printWindow.document.write("<html><body>");
		printWindow.document.write(divContents);
		printWindow.document.write("</body></html>");
		printWindow.document.close();
		printWindow.print();
	});
	$("#print_grade_total").click(function(){
		var divContents = $('#grade_total').html();
		var printWindow = window.open('','', height=400,width=800)	;
		printWindow.document.write("<html><body>");
		printWindow.document.write(divContents);
		printWindow.document.write("</body></html>");
		printWindow.document.close();
		printWindow.print();
	});
});