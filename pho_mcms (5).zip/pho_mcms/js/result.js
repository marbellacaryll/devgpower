
(function($, moment){


  // helper reads query string parameter
  function getQueryStrParamByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
  }// ./getQueryStrParamByName

  var method = getQueryStrParamByName('method')
  var gender = getQueryStrParamByName('gender')

  // age was entered in years months
  var age_y = getQueryStrParamByName('age_y');
  var age_m = getQueryStrParamByName('age_m')
  // age was entered as dates
  var dob_Str_Y_M_D_ISO = getQueryStrParamByName('dob')
  var dom_Str_Y_M_D_ISO = getQueryStrParamByName('dom')

  // height was entered in inches direct
  var hinches = getQueryStrParamByName('hinches')
  // height was entered on dropdowns
  var height_feet = getQueryStrParamByName('hft')
  var height_inches = getQueryStrParamByName('hin')

  var totalWeightPounds = parseFloat(getQueryStrParamByName('twp'), 10)

  var hcm  = parseFloat(getQueryStrParamByName('hcm'), 10)
  var wkg  = parseFloat(getQueryStrParamByName('wkg'), 10)

  function isDataInQueryString() {
    dataIsValid = true

    if (method && gender) {
    } else { dataIsValid = false}

    if (age_y && age_m || dob_Str_Y_M_D_ISO && dom_Str_Y_M_D_ISO) {
    } else { dataIsValid = false}

    if (method==='metric' && hcm && wkg || method==='english' && hinches && totalWeightPounds ||  method==='english' && height_feet && height_inches && totalWeightPounds) {
    } else { dataIsValid = false}

    return dataIsValid
  }// ./isDataInQueryString


  if ( isDataInQueryString() ) { // there are inputs

    // for link to respective graph page
    var fullLinkToResultGraph = './resultgraph.html' + window.location.search

    $('#link_to_result_graph').attr('href', fullLinkToResultGraph)





    // setting up session storage if back button to return to english respective metric entry form
    if (typeof(Storage) !== "undefined") { window.sessionStorage.setItem('eng_or_metr',method) }

    // display entered sex
    $('#sex_m_f').text(gender==='m'?'boy':'girl')


    if ( dob_Str_Y_M_D_ISO && dom_Str_Y_M_D_ISO ) { // age was entered as dates

        $('.age_by_dates').show()

        age_y = moment(dom_Str_Y_M_D_ISO, 'YYYY-MM-DD').diff(moment(dob_Str_Y_M_D_ISO, 'YYYY-MM-DD'), 'years')
        age_m = moment(dom_Str_Y_M_D_ISO, 'YYYY-MM-DD').diff(moment(dob_Str_Y_M_D_ISO, 'YYYY-MM-DD'), 'months') % 12

        $('#dob_full_str').text(moment(dob_Str_Y_M_D_ISO, 'YYYY-MM-DD').format('ll'))
        $('#dom_full_str').text(moment(dom_Str_Y_M_D_ISO, 'YYYY-MM-DD').format('ll'))
    }// ./  if (age_y && age_m )

    age_y = parseInt(age_y, 10)
    age_m = parseInt(age_m, 10)

    if ( age_y > 0 ) { $('#age_years').text(age_y + ' years') }

    var monthsTxt
    if ( age_m === 0 ) {
      monthsTxt = ''
    } else if ( age_m === 1 ){
      monthsTxt = ' 1 month'
    } else {
      monthsTxt = ' ' + age_m + ' months'
    }// ./if

    $('#age_months').text(monthsTxt)

    if ( age_y > 0 ) { $('.dom_years').text(age_y + ' years') }
    $('.dom_months').text(monthsTxt)

    var agem = age_y * 12 + age_m

    var genderNoStr = gender==='m'?'1':'2'
    var bmiCalculatedObj

    if (method === 'english') {

      if (hinches) {
        // height was entered in inches direct
        hinches = parseFloat(hinches, 10)
        $('#height_inches').text(hinches)

      } else {

        // height was entered on dropdowns
        $('#height_feet').text(height_feet + ' feet')
        $('#height_inches').text(height_inches)

        hinches = parseFloat(height_feet, 10) * 12 + parseFloat(height_inches, 10)
      }// ./if (hinches)


      $('#totalWeightPounds').text(totalWeightPounds)

      bmiCalculatedObj = bmi_calc.calcBMIandPerc_Eng(totalWeightPounds, hinches, genderNoStr, agem)

    } else { // method was metric
        $('.metric_inputs').show()
        $('.english_inputs').hide()


        $('#height_cm').text(hcm)
        $('#weight_kgs').text(wkg)

        bmiCalculatedObj = bmi_calc.calcBMIandPerc_Metr(wkg, hcm /100, genderNoStr, agem)

    }// ./if (method === 'english')

    /* warning for
    1)    (BMI / BMI_M) < 0.7, or
    2)    Perc_of_P95 ≥ 150
    */
    if ( (bmiCalculatedObj.bmi/bmiCalculatedObj.M < 0.7) || bmiCalculatedObj.overP95 >= 150 ) {
      //console.log(bmiCalculatedObj.bmi/bmiCalculatedObj.M, bmiCalculatedObj.overP95)
      $('.data_potential_err').show()
    }


    $('.bmi_no').text(bmiCalculatedObj.bmi)

    switch (bmiCalculatedObj.z_perc) {

      case 0:
        $('.bmi_percentile').html('less than the 1<sup>st</sup> ')
        break

      case 100:
        $('.bmi_percentile').html('greater than the 99<sup>th</sup> ')
        break

      default:
      $('.bmi_percentile').html('the ' + bmiCalculatedObj.z_perc + getOrdinalIndicator(bmiCalculatedObj.z_perc))
    }// ./switch bmiCalculatedObj.z_perc

    $('.gender').text(gender==='m'?'boy':'girl')

    $('img#bmi_chart').attr('src', getImageSrc(bmiCalculatedObj.z_perc))

    $('.bmi_conclusion').text(getBMIConclusion(bmiCalculatedObj.z_perc))


    if (bmiCalculatedObj.z_perc < 5) {
      $('.bmi_text').text(getBMI_text(bmiCalculatedObj.z_perc))
    } else if ( 5 <= bmiCalculatedObj.z_perc && bmiCalculatedObj.z_perc <= 85 ) {
      $('.normal_weight').show()
    } else if ( 85 <= bmiCalculatedObj.z_perc && bmiCalculatedObj.z_perc < 95 ) {
      $('.over_weight').show()
    } else if ( bmiCalculatedObj.z_perc >= 95) {
        $('.bmi_text').text(getBMI_text(bmiCalculatedObj.z_perc))
    }


    if (bmiCalculatedObj.z_perc > 95) {
      $('.child_obesity_95_to_97').show()
    }

    if (bmiCalculatedObj.z_perc > 97) {
      $('.child_obesity_over_97').show()
      $('#z_perc_over_97').text(bmiCalculatedObj.overP95)
    }

  } else {// there no are inputs
    // no data for the page, result page was possibly accessed directly, this would not happen regular case
    $('.noInfoForPage').show()
    $('.dataValidForPage').hide()
  }// ./if (method)


  // check class categories
  function getBMIConclusion(z_percentile) {

    if (z_percentile < 5) {
      return 'is underweight'
    } else if ( 5 <= z_percentile && z_percentile < 85 ) {
      return 'has healthy weight'
    } else if ( 85 <= z_percentile && z_percentile < 95 ) {
      return 'is overweight'
    } else if ( z_percentile >= 95) {
      return 'has obesity'
    }
  }// ./getBMIConclusion

  function getBMI_text(z_percentile) {

    if (z_percentile < 5) {
      return ' and should be seen by a healthcare provider for further assessment to determine possible causes of underweight'
    } else if ( 5 <= z_percentile && z_percentile < 85 ) {
      return ''
    } else if ( 85 <= z_percentile && z_percentile < 95 ) {
      return ''
    } else if ( z_percentile >= 95) {

      var tempRetTxt = ' and may have weight-related health problems. '
      var tempGend = 'He'
      if (gender==='f') { tempGend = 'She' }
      tempRetTxt += tempGend
      tempRetTxt += ' should be seen by a healthcare provider for further assessment'

      return tempRetTxt
    }
  }// ./getBMI_text

  function getImageSrc(z_percentile) {

    if (z_percentile < 5) {
      return './img/1_underweight.gif'
    } else if (5 <= z_percentile && z_percentile < 85 ) {
      return './img/2_healthy.gif'
    } else if ( 85 <= z_percentile && z_percentile < 95  ) {
      return './img/3_overweight.gif'
    } else if ( z_percentile >= 95) {
      return './img/4_obese.gif'
    }
  }// ./getImageSrc

  function getOrdinalIndicator(z_percentile) {
    switch (z_percentile) {
      case 0:
        return ''
        break;
      case 100:
        return ''
        break;
      case 1:
        return '<sup>st</sup>'
        break;
      case 2:
        return '<sup>nd</sup>'
        break;
      case 3:
        return '<sup>rd</sup>'
        break;
      default:
        return '<sup>th</sup>'
    }
  }// ./getOrdinalIndicator



})(jQuery, moment)
