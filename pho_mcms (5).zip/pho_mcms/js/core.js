$(window).ready(function() {

  $('#toggle').click(function() {
    if ($('#menu').is(':hidden')) $('#menu').addClass('visible');
    else $('#menu').removeClass('visible');
  });


  if  ( $.cookie("cookie_msg") != "1" )  
    $("#cookie_msg").fadeIn('fast');

  //$("#closecookiebutton").on('click',function() {$.cookie("cookie_msg", 1, { expires: 365}); $("#cookie_msg").fadeOut('fast');  });
  $("#closecookiebutton").click( function() {$.cookie("cookie_msg", 1, { expires: 365}); }); 


  $(".goto").click(function() {
    var divTarget = '#'+$(this).attr('rel');
    $('body,html').animate({scrollTop: $(divTarget).offset().top}, 1000);
    $("#menu").removeClass('visible');
  });

   var $window = $(window);

  $window.scroll(function() {
    if ( $window.scrollTop() >= $('#features').offset().top ) {
      $("#toggle i").css('color','#000'); }
     else if ( $window.scrollTop() >= $('#download').offset().top ) {
      $("#toggle i").css('color','#fff'); }

    else if ( $window.scrollTop() >= $('#main').offset().top  ) {
      $("#toggle i").css('color','#fff'); }
   

  });
});  



